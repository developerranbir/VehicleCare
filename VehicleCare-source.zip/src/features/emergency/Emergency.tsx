import { copy } from "../../lib/i18n";
import { useState } from "react";
import { Phone, Plus, Trash2, ShieldCheck, AlertTriangle } from "lucide-react";
import { useApp } from "../../lib/store";
import { id } from "../../lib/model";
import { PageHeading, Empty, useT, Confirm } from "../../components/shared";
import { Button } from "../../components/ui/button";
import { Dialog } from "../../components/ui/dialog";
export function Emergency() {
  const { data, commit } = useApp();
  const t = useT();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState(data.settings.breakdownNotes);
  const [saved, setSaved] = useState(false);
  const [remove, setRemove] = useState<string | null>(null);
  const contacts = data.settings.emergencyContacts;
  return (
    <>
      <PageHeading
        title={t("emergency")}
        description={copy(
          "The people and information you need, available on this device even offline.",
        )}
      />
      <div className="notice">
        <AlertTriangle size={22} />
        <span>
          {copy(
            "If there is immediate danger, contact your local emergency services. This basic checklist does not replace professional assistance or guarantee safety.",
          )}
        </span>
      </div>
      <div className="settings-grid">
        <div className="card">
          <h2>{copy("Emergency contacts")}</h2>
          {contacts.length ? (
            <div className="record-list">
              {contacts.map((c) => (
                <div className="activity-row" key={c.id}>
                  <span className="activity-icon">
                    <Phone size={19} />
                  </span>
                  <div>
                    <strong>{c.name}</strong>
                    <span className="small muted">{c.phone}</span>
                  </div>
                  {/^[+\d\s()-]+$/.test(c.phone) && (
                    <a
                      className="text-link"
                      href={`tel:${c.phone.replace(/[^+\d]/g, "")}`}
                    >
                      {copy("Call")}
                    </a>
                  )}
                  <button
                    className="icon-button danger"
                    aria-label={`Delete ${c.name}`}
                    onClick={() => setRemove(c.id)}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <Empty
              title={copy("Keep help close")}
              description={copy(
                "Save a family member, insurer, or roadside-assistance contact.",
              )}
            />
          )}
          <form
            className="form-grid"
            onSubmit={(e) => {
              e.preventDefault();
              if (
                commit((s) => {
                  s.settings.emergencyContacts.push({
                    id: id(),
                    name: name.trim(),
                    phone: phone.trim(),
                  });
                })
              ) {
                setName("");
                setPhone("");
              }
            }}
          >
            <div className="field">
              <label htmlFor="contact-name">{copy("Contact name")}</label>
              <input
                id="contact-name"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="field">
              <label htmlFor="contact-phone">{copy("Phone number")}</label>
              <input
                id="contact-phone"
                required
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            <div className="field-full">
              <Button>
                <Plus size={16} />
                {copy("Add contact")}
              </Button>
            </div>
          </form>
        </div>
        <div className="card">
          <h2>{copy("Breakdown notes")}</h2>
          <p className="muted">
            {copy(
              "Policy numbers, assistance details, or directions someone may need.",
            )}
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSaved(
                commit((s) => {
                  s.settings.breakdownNotes = notes;
                }),
              );
            }}
          >
            <div className="field">
              <label htmlFor="breakdown-notes">{copy("Your notes")}</label>
              <textarea
                id="breakdown-notes"
                value={notes}
                onChange={(e) => {
                  setNotes(e.target.value);
                  setSaved(false);
                }}
                rows={7}
                maxLength={4000}
              />
            </div>
            <Button>{copy("Save notes")}</Button>
            {saved && (
              <span role="status" className="small teal">
                {" "}
                {copy("Saved")}
              </span>
            )}
          </form>
        </div>
      </div>
      <div className="card">
        <div className="section-heading">
          <ShieldCheck className="teal" />
          <h2>{copy("Basic breakdown checklist")}</h2>
        </div>
        <ol className="breakdown-list">
          <li>
            <strong>{copy("Move out of traffic if it is safe.")}</strong>
            <p>
              {copy(
                "Stop in a safe location and switch on hazard lights. Follow local road rules.",
              )}
            </p>
          </li>
          <li>
            <strong>{copy("Assess your surroundings.")}</strong>
            <p>
              {copy(
                "Keep yourself and passengers away from moving traffic. Do not attempt repairs in an unsafe location.",
              )}
            </p>
          </li>
          <li>
            <strong>{copy("Call for suitable help.")}</strong>
            <p>
              {copy(
                "Use your saved assistance contact, insurer, or local emergency services as appropriate.",
              )}
            </p>
          </li>
          <li>
            <strong>{copy("Share your location and vehicle details.")}</strong>
            <p>
              {copy(
                "Describe the issue and any visible hazards. Follow instructions from qualified assistance personnel.",
              )}
            </p>
          </li>
          <li>
            <strong>
              {copy(
                "Avoid opening hot components or touching damaged electrical systems.",
              )}
            </strong>
            <p>
              {copy(
                "Wait for qualified help when unsure, especially with high-voltage electric-vehicle components.",
              )}
            </p>
          </li>
        </ol>
      </div>
      <Dialog
        open={!!remove}
        onOpenChange={() => setRemove(null)}
        title={copy("Delete emergency contact")}
      >
        <Confirm
          title={copy("Remove this saved contact?")}
          description={copy("You can add the contact again later.")}
          confirmLabel={copy("Delete contact")}
          onCancel={() => setRemove(null)}
          onConfirm={() => {
            commit((s) => {
              s.settings.emergencyContacts =
                s.settings.emergencyContacts.filter((c) => c.id !== remove);
            });
            setRemove(null);
          }}
        />
      </Dialog>
    </>
  );
}
