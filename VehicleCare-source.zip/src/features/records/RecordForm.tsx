import { copy } from "../../lib/i18n";
import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useApp } from "../../lib/store";
import {
  type Collection,
  type Entry,
  entrySchema,
  dateSchema,
  id,
  today,
  validateEntry,
} from "../../lib/model";
import { displayToKm, kmToDisplay } from "../../lib/calculations";
import { useT } from "../../components/shared";
import { Button } from "../../components/ui/button";
import { configs, type Field } from "./config";

export function RecordForm({
  kind,
  entry,
  onDone,
}: {
  kind: Collection;
  entry?: Entry;
  onDone: () => void;
}) {
  const { data, saveEntry } = useApp();
  const t = useT();
  const [error, setError] = useState("");
  const cfg = configs[kind];
  const fields: Field[] = [
    { key: "vehicleId", label: "vehicle", type: "select", required: true },
    { key: "title", label: "title", required: true },
    { key: "date", label: "date", type: "date", required: true },
    ...cfg.fields,
    ...(["fuelLogs", "chargingLogs", "services", "expenses"].includes(kind)
      ? [{ key: "tripId", label: "trip", type: "select" } as Field]
      : []),
    { key: "notes", label: "notes", type: "textarea" },
  ];
  const shape: Record<string, z.ZodString> = {};
  const defaults: Record<string, string> = {
    vehicleId:
      entry?.vehicleId ||
      data.settings.selectedVehicleId ||
      data.vehicles.find((v) => !v.archived)?.id ||
      "",
    title: entry?.title || "",
    date: entry?.date || today(),
    fullTank: entry?.fullTank === false ? "false" : "true",
    warningDays: String(entry?.warningDays ?? data.settings.warningDays),
    warningKm: String(
      kmToDisplay(
        entry?.warningKm ?? data.settings.warningKm,
        data.settings.distanceUnit,
      ),
    ),
    category: entry?.category ?? "Other",
    renewalType: entry?.renewalType ?? "Custom",
    status: entry?.status ?? "Unchecked",
  };
  for (const field of fields) {
    let validator = z.string().max(4000);
    if (field.required)
      validator = validator.min(1, `${t(field.label)} is required`);
    let validation = validator;
    if (field.type === "number")
      validation = validator.refine(
        (v) =>
          (!v && !field.required) ||
          (v.trim() !== "" &&
            Number.isFinite(Number(v)) &&
            Number(v) >= (field.min ?? 0)),
        "Enter a valid non-negative number",
      );
    if (field.type === "date")
      validation = validator.refine(
        (v) => (!v && !field.required) || dateSchema.safeParse(v).success,
        "Enter a valid date",
      );
    shape[field.key] = validation;
    if (entry) {
      const value = entry[field.key as keyof Entry];
      if (value !== undefined && !Array.isArray(value))
        defaults[field.key] =
          typeof value === "number"
            ? String(
                field.money
                  ? value / 100
                  : field.distance
                    ? Number(
                        kmToDisplay(value, data.settings.distanceUnit).toFixed(
                          5,
                        ),
                      )
                    : value,
              )
            : String(value);
    } else if (!(field.key in defaults)) defaults[field.key] = "";
  }
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<Record<string, string>>({
    defaultValues: defaults,
    resolver: zodResolver(z.object(shape)),
  });
  const selected = useWatch({ control, name: "vehicleId" });
  const submit = handleSubmit((values) => {
    try {
      const raw: Record<string, unknown> = { ...entry, id: entry?.id ?? id() };
      for (const field of fields) {
        const value = values[field.key];
        raw[field.key] =
          field.type === "number"
            ? value === ""
              ? undefined
              : field.money
                ? Math.round(Number(value) * 100)
                : field.distance
                  ? displayToKm(Number(value), data.settings.distanceUnit)
                  : Number(value)
            : field.type === "checkbox"
              ? value === "true"
              : value === "" && field.type === "date"
                ? undefined
                : value;
      }
      if (
        raw.tripId &&
        !data.trips.some(
          (trip) => trip.id === raw.tripId && trip.vehicleId === raw.vehicleId,
        )
      )
        raw.tripId = "";
      const parsed = validateEntry(kind, entrySchema.parse(raw));
      if (saveEntry(kind, parsed)) onDone();
      else setError(useApp.getState().error ?? "Could not save");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Check the form values");
    }
  });
  return (
    <form onSubmit={submit} className="form-grid">
      {fields.map((field) => {
        const label = `${t(field.label)}${field.distance ? ` (${data.settings.distanceUnit})` : field.money ? ` (${data.settings.currency})` : ""}`;
        let options =
          field.options?.map((value) => ({ value, label: copy(value) })) ?? [];
        if (field.key === "vehicleId")
          options = data.vehicles
            .filter((v) => !v.archived || v.id === entry?.vehicleId)
            .map((v) => ({ value: v.id, label: v.name }));
        if (field.key === "tripId")
          options = [
            { value: "", label: copy("No linked trip") },
            ...data.trips
              .filter((trip) => trip.vehicleId === selected)
              .map((trip) => ({ value: trip.id, label: trip.title })),
          ];
        return (
          <div
            key={field.key}
            className={`field ${field.type === "textarea" ? "field-full" : ""}`}
          >
            <label htmlFor={`entry-${field.key}`}>
              {label}
              {field.required && <span className="required"> *</span>}
            </label>
            {field.type === "select" ? (
              <select id={`entry-${field.key}`} {...register(field.key)}>
                {field.required && <option value="">{copy("Select…")}</option>}
                {options.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            ) : field.type === "textarea" ? (
              <textarea
                id={`entry-${field.key}`}
                rows={3}
                {...register(field.key)}
              />
            ) : field.type === "checkbox" ? (
              <select id={`entry-${field.key}`} {...register(field.key)}>
                <option value="true">{copy("Full tank")}</option>
                <option value="false">{copy("Partial fill")}</option>
              </select>
            ) : (
              <input
                id={`entry-${field.key}`}
                type={field.type ?? "text"}
                inputMode={field.type === "number" ? "decimal" : undefined}
                step={field.type === "number" ? "any" : undefined}
                min={field.type === "number" ? (field.min ?? 0) : undefined}
                {...register(field.key)}
              />
            )}{" "}
            {errors[field.key] && (
              <span role="alert" className="field-error">
                {String(errors[field.key]?.message)}
              </span>
            )}
          </div>
        );
      })}
      {kind === "fuelLogs" && (
        <p className="form-note field-full">
          {copy(
            "Efficiency needs two full tanks. Intermediate partial fills are included.",
          )}
        </p>
      )}
      {kind === "chargingLogs" && (
        <p className="form-note field-full">
          {copy(
            "Energy purchased does not necessarily equal energy consumed while driving.",
          )}
        </p>
      )}
      {kind === "expenses" && (
        <p className="form-note field-full">
          {copy(
            "Only record independent costs here. Fuel, charging, and service logs already contribute to spending.",
          )}
        </p>
      )}
      {kind === "checklistEntries" && (
        <p className="form-note field-full">
          {copy("Manual inspection notes are not a mechanical diagnosis.")}
        </p>
      )}
      {error && (
        <p role="alert" className="field-error field-full">
          {error}
        </p>
      )}
      <div className="dialog-actions field-full">
        <Button type="button" variant="outline" onClick={onDone}>
          {t("cancel")}
        </Button>
        <Button type="submit">{t("save")}</Button>
      </div>
    </form>
  );
}
