import { copy } from "../../lib/i18n";
import { useState } from "react";
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  Fuel,
  Zap,
  Wrench,
  CalendarClock,
  Receipt,
  Route,
  ClipboardCheck,
  Download,
  Check,
  RefreshCw,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useApp } from "../../lib/store";
import {
  type Collection,
  type Entry,
  entrySchema,
  id,
  today,
} from "../../lib/model";
import {
  formatDate,
  formatDistance,
  formatMoney,
  fuelEconomy,
  formatEfficiency,
  ledger,
  maintenanceStatus,
  renewalStatus,
} from "../../lib/calculations";
import { exportICS, exportCSV } from "../../lib/export";
import { Button } from "../../components/ui/button";
import { Dialog } from "../../components/ui/dialog";
import {
  PageHeading,
  Empty,
  Badge,
  Confirm,
  useT,
} from "../../components/shared";
import { configs } from "./config";
import { RecordForm } from "./RecordForm";
const icons = {
  fuelLogs: Fuel,
  chargingLogs: Zap,
  services: Wrench,
  maintenanceRules: CalendarClock,
  expenses: Receipt,
  renewals: CalendarClock,
  trips: Route,
  checklistEntries: ClipboardCheck,
};
export function RecordsPage({ kind }: { kind: Collection }) {
  const { data, removeEntry, commit } = useApp();
  const t = useT();
  const cfg = configs[kind];
  const Icon = icons[kind];
  const [edit, setEdit] = useState<Entry | null | undefined>(undefined);
  const [deletion, setDeletion] = useState<Entry | null>(null);
  const [complete, setComplete] = useState<Entry | null>(null);
  const [renew, setRenew] = useState<Entry | null>(null);
  const [search, setSearch] = useState("");
  const [ledgerView, setLedgerView] = useState(false);
  const [visibleCount, setVisibleCount] = useState(50);
  const filtered = data[kind]
    .filter(
      (e) =>
        (!data.settings.selectedVehicleId ||
          e.vehicleId === data.settings.selectedVehicleId) &&
        `${e.title} ${e.notes} ${e.location}`
          .toLowerCase()
          .includes(search.toLowerCase()),
    )
    .sort((a, b) =>
      kind === "renewals"
        ? a.dueDate!.localeCompare(b.dueDate!)
        : b.date.localeCompare(a.date),
    );
  const active = data.vehicles.filter((v) => !v.archived);
  const allCosts = ledger(data).filter(
    (e) =>
      !data.settings.selectedVehicleId ||
      e.vehicleId === data.settings.selectedVehicleId,
  );
  const amount = (e: Entry) =>
    kind === "services" ? e.partsCost + e.labourCost + e.miscCost : e.cost;
  const total = filtered.reduce((sum, e) => sum + amount(e), 0);
  const economy = data.vehicles
    .filter(
      (v) =>
        !data.settings.selectedVehicleId ||
        v.id === data.settings.selectedVehicleId,
    )
    .flatMap((v) =>
      fuelEconomy(data.fuelLogs.filter((e) => e.vehicleId === v.id)),
    );
  const avg = economy.length
    ? economy.reduce((s, e) => s + e.distance, 0) /
      economy.reduce((s, e) => s + e.litres, 0)
    : null;
  return (
    <>
      <PageHeading
        eyebrow="KEEP THE JOURNEY GOING"
        title={t(cfg.label)}
        description={copy(cfg.description)}
        action={
          <Button disabled={!active.length} onClick={() => setEdit(null)}>
            <Plus size={17} />
            {`${copy("Add")} ${copy(cfg.singular.toLowerCase())}`}
          </Button>
        }
      />
      {!active.length && (
        <div className="notice">
          {copy("Add or restore a vehicle to create records.")}{" "}
          <Link to="/garage/new">{t("addVehicle")} ↗</Link>
        </div>
      )}
      <div className="mini-stats">
        <div>
          <span className="muted small">{copy("Recorded entries")}</span>
          <strong>{filtered.length}</strong>
        </div>
        <div>
          <span className="muted small">
            {copy(
              kind === "fuelLogs"
                ? "Full-tank efficiency"
                : kind === "trips"
                  ? "Recorded trip distance"
                  : kind === "maintenanceRules" || kind === "renewals"
                    ? "Needs attention"
                    : "Total recorded cost",
            )}
          </span>
          <strong>
            {kind === "fuelLogs"
              ? avg === null
                ? copy("Not enough data")
                : formatEfficiency(avg, data.settings)
              : kind === "trips"
                ? formatDistance(
                    filtered.reduce(
                      (s, e) => s + e.endOdometer! - e.startOdometer!,
                      0,
                    ),
                    data.settings,
                  )
                : kind === "maintenanceRules"
                  ? filtered.filter(
                      (e) =>
                        maintenanceStatus(
                          e,
                          data.vehicles.find((v) => v.id === e.vehicleId)!,
                        ).status !== "On track",
                    ).length
                  : kind === "renewals"
                    ? filtered.filter(
                        (e) => renewalStatus(e).status !== "On track",
                      ).length
                    : formatMoney(total, data.settings)}
          </strong>
        </div>
        <div>
          <span className="muted small">{copy("Your data")}</span>
          <strong className="teal">{copy("Local & private")}</strong>
        </div>
      </div>
      {kind === "chargingLogs" && (
        <p className="notice">
          {copy(
            "These figures describe energy charged and charging expenditure. Purchased energy is not a measurement of driving consumption.",
          )}
        </p>
      )}
      {kind === "expenses" && (
        <div className="tabs">
          <button
            className={!ledgerView ? "selected" : ""}
            onClick={() => setLedgerView(false)}
          >
            {copy("Independent expenses")}
          </button>
          <button
            className={ledgerView ? "selected" : ""}
            onClick={() => setLedgerView(true)}
          >
            {copy("All spending ledger")}
          </button>
          <Button variant="ghost" onClick={() => exportCSV(data)}>
            <Download size={16} />
            {copy("CSV")}
          </Button>
        </div>
      )}
      <div className="card record-card">
        <div className="section-heading">
          <h2>
            {kind === "expenses" && ledgerView
              ? "Unified spending ledger"
              : `${t(cfg.label)} records`}
          </h2>
          <div className="search-field">
            <Search size={17} />
            <input
              aria-label={t("search")}
              placeholder={t("search")}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
        {ledgerView && kind === "expenses" ? (
          allCosts.filter((e) =>
            e.title.toLowerCase().includes(search.toLowerCase()),
          ).length ? (
            <div className="record-list">
              {allCosts
                .filter((e) =>
                  e.title.toLowerCase().includes(search.toLowerCase()),
                )
                .slice(0, visibleCount)
                .map((e) => (
                  <div className="record-row" key={e.id}>
                    <span className="record-icon">
                      <Receipt size={20} />
                    </span>
                    <div className="record-main">
                      <strong>{e.title}</strong>
                      <span className="small muted">
                        {data.vehicles.find((v) => v.id === e.vehicleId)?.name}{" "}
                        · {formatDate(e.date, data.settings)} · {e.category}
                      </span>
                    </div>
                    <strong>{formatMoney(e.amount, data.settings)}</strong>
                  </div>
                ))}
            </div>
          ) : (
            <Empty
              title={t("noRecords")}
              description={copy(
                "Your fuel, charging, service, and independent expense costs will appear here.",
              )}
            />
          )
        ) : filtered.length ? (
          <div className="record-list">
            {filtered.slice(0, visibleCount).map((entry) => {
              const vehicle = data.vehicles.find(
                (v) => v.id === entry.vehicleId,
              )!;
              const status =
                kind === "maintenanceRules"
                  ? maintenanceStatus(entry, vehicle)
                  : kind === "renewals"
                    ? renewalStatus(entry)
                    : null;
              return (
                <div className="record-row" key={entry.id}>
                  <span className="record-icon">
                    <Icon size={20} />
                  </span>
                  <div className="record-main">
                    <strong>{entry.title}</strong>
                    <span className="small muted">
                      {vehicle.name} · {formatDate(entry.date, data.settings)}
                      {entry.odometer !== undefined
                        ? ` · ${formatDistance(entry.odometer, data.settings)}`
                        : ""}
                    </span>
                    {kind === "fuelLogs" && (
                      <span className="small muted">
                        {entry.litres} L ·{" "}
                        {copy(entry.fullTank ? "Full tank" : "Partial fill")}{" "}
                        {entry.location && `· ${entry.location}`}
                      </span>
                    )}
                    {kind === "chargingLogs" && (
                      <span className="small muted">
                        {entry.kwh} {copy("kWh ·")}{" "}
                        {entry.location || "Location not recorded"}
                      </span>
                    )}
                    {kind === "services" && (
                      <span className="small muted">{entry.tasks}</span>
                    )}
                    {kind === "maintenanceRules" && (
                      <span className="small muted">
                        {maintenanceStatus(entry, vehicle).dueDate
                          ? `Due ${formatDate(maintenanceStatus(entry, vehicle).dueDate!, data.settings)}`
                          : ""}
                        {maintenanceStatus(entry, vehicle).dueOdometer !==
                        undefined
                          ? ` · At ${formatDistance(maintenanceStatus(entry, vehicle).dueOdometer!, data.settings)}`
                          : ""}
                      </span>
                    )}
                    {kind === "renewals" && (
                      <span className="small muted">
                        {copy("Expires")}{" "}
                        {formatDate(entry.dueDate!, data.settings)} ·{" "}
                        {entry.history.length} {copy("past renewals")}
                      </span>
                    )}
                    {kind === "trips" && (
                      <span className="small muted">
                        {formatDistance(
                          entry.endOdometer! - entry.startOdometer!,
                          data.settings,
                        )}{" "}
                        {copy("· Linked expenses:")}{" "}
                        {formatMoney(
                          ledger(data)
                            .filter((e) => e.tripId === entry.id)
                            .reduce((s, e) => s + e.amount, 0),
                          data.settings,
                        )}
                      </span>
                    )}
                    {entry.notes && (
                      <span className="small muted record-notes">
                        {entry.notes}
                      </span>
                    )}
                    {kind === "renewals" && entry.history.length > 0 && (
                      <details className="renewal-history">
                        <summary>
                          {copy("Renewal history")} ({entry.history.length})
                        </summary>
                        {entry.history
                          .slice()
                          .reverse()
                          .map((history, index) => (
                            <p key={index}>
                              {formatDate(history.date, data.settings)} ·{" "}
                              {copy("Previous expiry")}:{" "}
                              {formatDate(
                                history.previousDueDate,
                                data.settings,
                              )}{" "}
                              · {formatMoney(history.cost, data.settings)}
                            </p>
                          ))}
                      </details>
                    )}
                    {kind === "checklistEntries" && entry.completedDate && (
                      <span className="small muted">
                        {copy("Last checked")}:{" "}
                        {formatDate(entry.completedDate, data.settings)}
                      </span>
                    )}
                  </div>
                  <div className="record-value">
                    {status ? (
                      <Badge status={status.status} />
                    ) : kind === "checklistEntries" ? (
                      <Badge status={entry.status} />
                    ) : kind === "trips" ? (
                      <span />
                    ) : (
                      <strong>
                        {formatMoney(amount(entry), data.settings)}
                      </strong>
                    )}
                  </div>
                  <div className="record-actions">
                    {kind === "maintenanceRules" && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setComplete(entry)}
                      >
                        <Check size={14} />
                        {copy("Complete")}
                      </Button>
                    )}
                    {kind === "renewals" && (
                      <>
                        <button
                          className="icon-button"
                          title={copy("Download calendar event")}
                          aria-label={`Calendar ${entry.title}`}
                          onClick={() => exportICS(entry, vehicle.name)}
                        >
                          <Download size={17} />
                        </button>
                        <button
                          className="icon-button"
                          title={copy("Renew")}
                          aria-label={`Renew ${entry.title}`}
                          onClick={() => setRenew(entry)}
                        >
                          <RefreshCw size={17} />
                        </button>
                      </>
                    )}
                    {kind === "checklistEntries" && (
                      <button
                        className="icon-button"
                        aria-label={`Mark ${entry.title} OK`}
                        onClick={() =>
                          commit((s) => {
                            const item = s.checklistEntries.find(
                              (e) => e.id === entry.id,
                            )!;
                            item.status = "OK";
                            item.completedDate = today();
                          })
                        }
                      >
                        <Check size={17} />
                      </button>
                    )}
                    <button
                      className="icon-button"
                      aria-label={`Edit ${entry.title}`}
                      onClick={() => setEdit(entry)}
                    >
                      <Pencil size={17} />
                    </button>
                    <button
                      className="icon-button danger"
                      aria-label={`Delete ${entry.title}`}
                      onClick={() => setDeletion(entry)}
                    >
                      <Trash2 size={17} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <Empty
            title={search ? "No matching records" : t("noRecords")}
            description={
              kind === "fuelLogs"
                ? "Add your first fill-up. Efficiency appears after two consistent full-tank readings."
                : `Add a ${cfg.singular.toLowerCase()} to start building your vehicle’s story.`
            }
            action={
              !search && active.length ? (
                <Button variant="outline" onClick={() => setEdit(null)}>
                  <Plus size={16} />
                  {`${copy("Add")} ${copy(cfg.singular.toLowerCase())}`}
                </Button>
              ) : undefined
            }
          />
        )}
        {(ledgerView && kind === "expenses"
          ? allCosts.filter((e) =>
              e.title.toLowerCase().includes(search.toLowerCase()),
            ).length
          : filtered.length) > visibleCount && (
          <div className="load-more">
            <Button
              variant="outline"
              onClick={() => setVisibleCount((count) => count + 50)}
            >
              {copy("Show more records")}
            </Button>
            <span className="small muted">
              {copy("Showing")} {visibleCount} {copy("records")}
            </span>
          </div>
        )}
      </div>
      <Dialog
        open={edit !== undefined}
        onOpenChange={(open) => {
          if (!open) setEdit(undefined);
        }}
        title={`${copy(edit ? "Edit" : "Add")} ${copy(cfg.singular.toLowerCase())}`}
        wide
      >
        {edit !== undefined && (
          <RecordForm
            key={edit?.id ?? "new"}
            kind={kind}
            entry={edit ?? undefined}
            onDone={() => setEdit(undefined)}
          />
        )}
      </Dialog>
      <Dialog
        open={!!deletion}
        onOpenChange={() => setDeletion(null)}
        title={copy("Delete record")}
      >
        <Confirm
          title={`Delete “${deletion?.title}”?`}
          description={copy(
            "This removes the record from this browser. Export a backup first if you might need it later.",
          )}
          confirmLabel={copy("Delete record")}
          onCancel={() => setDeletion(null)}
          onConfirm={() => {
            if (deletion) removeEntry(kind, deletion.id);
            setDeletion(null);
          }}
        />
      </Dialog>
      <Dialog
        open={!!complete}
        onOpenChange={() => setComplete(null)}
        title={copy("Complete maintenance & record service")}
        description={copy(
          "A saved service resets both the date and distance intervals.",
        )}
        wide
      >
        {complete && (
          <RecordForm
            kind="services"
            entry={entrySchema.parse({
              id: id(),
              vehicleId: complete.vehicleId,
              title: complete.title,
              date: today(),
              odometer: data.vehicles.find((v) => v.id === complete.vehicleId)!
                .odometer,
              tasks: complete.title,
              maintenanceRuleId: complete.id,
            })}
            onDone={() => setComplete(null)}
          />
        )}
      </Dialog>
      <Dialog
        open={!!renew}
        onOpenChange={() => setRenew(null)}
        title={copy("Record renewal")}
      >
        {renew && <RenewalForm entry={renew} onDone={() => setRenew(null)} />}
      </Dialog>
    </>
  );
}
function RenewalForm({ entry, onDone }: { entry: Entry; onDone: () => void }) {
  const { data, commit } = useApp();
  const [date, setDate] = useState("");
  const [cost, setCost] = useState("0");
  const [error, setError] = useState("");
  return (
    <form
      className="form-grid"
      onSubmit={(e) => {
        e.preventDefault();
        if (date <= entry.dueDate!) {
          setError("New expiry must be later than the previous expiry.");
          return;
        }
        if (
          commit((s) => {
            const renewal = s.renewals.find((r) => r.id === entry.id)!;
            const amount = Math.round(Number(cost) * 100);
            renewal.history.push({
              date: today(),
              previousDueDate: renewal.dueDate!,
              cost: amount,
            });
            renewal.dueDate = date;
            if (amount > 0)
              s.expenses.push(
                entrySchema.parse({
                  id: id(),
                  vehicleId: entry.vehicleId,
                  title: `${entry.title} renewal`,
                  date: today(),
                  cost: amount,
                  category:
                    entry.renewalType === "Insurance" ? "Insurance" : "Other",
                }),
              );
          })
        )
          onDone();
        else setError(useApp.getState().error ?? "Could not renew");
      }}
    >
      <div className="field field-full">
        <label htmlFor="renewal-date">{copy("New expiry date")}</label>
        <input
          id="renewal-date"
          type="date"
          required
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>
      <div className="field field-full">
        <label htmlFor="renewal-cost">
          {copy("Cost (")}
          {data.settings.currency})
        </label>
        <input
          id="renewal-cost"
          type="number"
          step="0.01"
          min="0"
          required
          value={cost}
          onChange={(e) => setCost(e.target.value)}
        />
      </div>
      <p className="form-note field-full">
        {copy(
          "A non-zero renewal cost creates one independent expense. History is retained without adding a second ledger entry.",
        )}
      </p>
      {error && (
        <p role="alert" className="field-error field-full">
          {error}
        </p>
      )}
      <div className="dialog-actions field-full">
        <Button variant="outline" type="button" onClick={onDone}>
          {copy("Cancel")}
        </Button>
        <Button>{copy("Save renewal")}</Button>
      </div>
    </form>
  );
}
