import type { Collection } from "../../lib/model";
import type { Label } from "../../lib/i18n";
export type Field = {
  key: string;
  label: Label;
  type?: "text" | "number" | "date" | "select" | "textarea" | "checkbox";
  required?: boolean;
  options?: string[];
  money?: boolean;
  distance?: boolean;
  min?: number;
};
export const configs: Record<
  Collection,
  { label: Label; singular: string; description: string; fields: Field[] }
> = {
  fuelLogs: {
    label: "fuel",
    singular: "Fuel entry",
    description: "Every fill-up, with full-tank-to-full-tank efficiency.",
    fields: [
      {
        key: "odometer",
        label: "odometer",
        type: "number",
        required: true,
        distance: true,
      },
      {
        key: "litres",
        label: "litres",
        type: "number",
        required: true,
        min: 0.01,
      },
      {
        key: "cost",
        label: "cost",
        type: "number",
        required: true,
        money: true,
      },
      { key: "fullTank", label: "fullTank", type: "checkbox" },
      { key: "location", label: "location" },
    ],
  },
  chargingLogs: {
    label: "charging",
    singular: "Charging session",
    description: "Track energy purchased and what it costs to charge.",
    fields: [
      { key: "kwh", label: "kwh", type: "number", required: true, min: 0.01 },
      {
        key: "cost",
        label: "cost",
        type: "number",
        required: true,
        money: true,
      },
      { key: "odometer", label: "odometer", type: "number", distance: true },
      { key: "location", label: "location" },
    ],
  },
  services: {
    label: "services",
    singular: "Service record",
    description:
      "A complete care history, from small repairs to major services.",
    fields: [
      {
        key: "odometer",
        label: "odometer",
        type: "number",
        required: true,
        distance: true,
      },
      { key: "tasks", label: "tasks", type: "textarea", required: true },
      { key: "partsCost", label: "partsCost", type: "number", money: true },
      { key: "labourCost", label: "labourCost", type: "number", money: true },
      { key: "miscCost", label: "miscCost", type: "number", money: true },
      { key: "location", label: "location" },
    ],
  },
  maintenanceRules: {
    label: "maintenance",
    singular: "Maintenance schedule",
    description:
      "Stay a step ahead. A combined schedule is due when either interval is reached.",
    fields: [
      { key: "intervalDays", label: "intervalDays", type: "number", min: 1 },
      {
        key: "intervalKm",
        label: "intervalKm",
        type: "number",
        distance: true,
        min: 0.01,
      },
      { key: "baselineDate", label: "baselineDate", type: "date" },
      {
        key: "baselineOdometer",
        label: "baselineOdometer",
        type: "number",
        distance: true,
      },
      { key: "warningDays", label: "warningDays", type: "number" },
      { key: "warningKm", label: "warningKm", type: "number", distance: true },
      { key: "lastCompletedDate", label: "lastCompletedDate", type: "date" },
      {
        key: "lastCompletedOdometer",
        label: "lastCompletedOdometer",
        type: "number",
        distance: true,
      },
    ],
  },
  expenses: {
    label: "expenses",
    singular: "Expense",
    description:
      "Tolls, parking, accessories, and the little costs along the way.",
    fields: [
      {
        key: "category",
        label: "category",
        type: "select",
        options: [
          "Toll",
          "Parking",
          "Cleaning",
          "Accessories",
          "Insurance",
          "Fuel",
          "Charging",
          "Service",
          "Other",
        ],
        required: true,
      },
      {
        key: "cost",
        label: "cost",
        type: "number",
        money: true,
        required: true,
      },
      { key: "location", label: "location" },
    ],
  },
  renewals: {
    label: "renewals",
    singular: "Renewal",
    description:
      "Keep insurance, certificates, and warranties in good standing.",
    fields: [
      {
        key: "renewalType",
        label: "renewalType",
        type: "select",
        options: ["Insurance", "PUC", "Warranty", "Custom"],
      },
      { key: "dueDate", label: "dueDate", type: "date", required: true },
      { key: "warningDays", label: "warningDays", type: "number" },
    ],
  },
  trips: {
    label: "trips",
    singular: "Trip",
    description: "Keep a journal of your journeys and their linked expenses.",
    fields: [
      {
        key: "startOdometer",
        label: "startOdometer",
        type: "number",
        required: true,
        distance: true,
      },
      {
        key: "endOdometer",
        label: "endOdometer",
        type: "number",
        required: true,
        distance: true,
      },
    ],
  },
  checklistEntries: {
    label: "checklists",
    singular: "Inspection item",
    description: "Simple manual checks for more mindful vehicle care.",
    fields: [
      {
        key: "status",
        label: "status",
        type: "select",
        options: ["OK", "Attention", "Unchecked"],
      },
      { key: "completedDate", label: "completedDate", type: "date" },
    ],
  },
};
export const routeCollection: Record<string, Collection> = {
  fuel: "fuelLogs",
  charging: "chargingLogs",
  services: "services",
  maintenance: "maintenanceRules",
  expenses: "expenses",
  renewals: "renewals",
  trips: "trips",
  checklists: "checklistEntries",
};
