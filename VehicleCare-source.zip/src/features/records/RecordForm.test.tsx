import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { RecordForm } from "./RecordForm";
import { useApp } from "../../lib/store";
import { demoSnapshot } from "../../lib/demo";
import { STORAGE_KEY } from "../../lib/model";
import { labels } from "../../lib/i18n";
beforeEach(() => {
  localStorage.clear();
  useApp.setState({
    data: demoSnapshot(),
    raw: null,
    error: null,
    blocked: false,
    dirty: false,
    conflict: false,
  });
});
describe("accessible record forms", () => {
  it("does not persist form keystrokes before submission", () => {
    const spy = vi.spyOn(Storage.prototype, "setItem");
    render(<RecordForm kind="expenses" onDone={() => {}} />);
    fireEvent.change(screen.getByLabelText("Title *"), {
      target: { value: "Draft only" },
    });
    expect(spy).not.toHaveBeenCalled();
    expect(
      useApp.getState().data.expenses.some((e) => e.title === "Draft only"),
    ).toBe(false);
    spy.mockRestore();
  });
  it("has labelled inputs and field-level errors", async () => {
    render(<RecordForm kind="fuelLogs" onDone={() => {}} />);
    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    await waitFor(() =>
      expect(screen.getAllByRole("alert").length).toBeGreaterThan(0),
    );
    expect(screen.getByLabelText("Litres *")).toBeVisible();
  });
  it("commits a valid independent expense and persists it", async () => {
    const done = vi.fn();
    render(<RecordForm kind="expenses" onDone={done} />);
    fireEvent.change(screen.getByLabelText("Title *"), {
      target: { value: "Parking charge" },
    });
    fireEvent.change(screen.getByLabelText("Cost (INR) *"), {
      target: { value: "125.50" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    await waitFor(() => expect(done).toHaveBeenCalled());
    expect(useApp.getState().data.expenses.at(-1)?.cost).toBe(12550);
    expect(localStorage.getItem(STORAGE_KEY)).toContain("Parking charge");
  });
  it("exposes Hindi form labels and translations for every label", () => {
    useApp.getState().commit((s) => {
      s.settings.language = "hi";
    });
    render(<RecordForm kind="fuelLogs" onDone={() => {}} />);
    expect(screen.getByLabelText("लीटर *")).toBeVisible();
    expect(Object.keys(labels.hi).sort()).toEqual(
      Object.keys(labels.en).sort(),
    );
  });
  it("keeps changes in memory when a write fails", async () => {
    const spy = vi
      .spyOn(Storage.prototype, "setItem")
      .mockImplementation(() => {
        throw new DOMException("Quota full", "QuotaExceededError");
      });
    const done = vi.fn();
    render(<RecordForm kind="expenses" onDone={done} />);
    fireEvent.change(screen.getByLabelText("Title *"), {
      target: { value: "Unpersisted" },
    });
    fireEvent.change(screen.getByLabelText("Cost (INR) *"), {
      target: { value: "50" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    await waitFor(() => expect(done).toHaveBeenCalled());
    expect(useApp.getState().dirty).toBe(true);
    expect(useApp.getState().error).toContain("Not saved");
    expect(useApp.getState().data.expenses.at(-1)?.title).toBe("Unpersisted");
    spy.mockRestore();
  });
  it("detects cross-tab changes while memory is dirty", () => {
    useApp.setState({ dirty: true });
    useApp.getState().receive(JSON.stringify(demoSnapshot()));
    expect(useApp.getState().conflict).toBe(true);
  });
});
