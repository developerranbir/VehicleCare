import { copy } from "../../lib/i18n";
import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ShieldCheck,
  Database,
  Download,
  Trash2,
  FlaskConical,
  ArrowUpRight,
  Moon,
  Sun,
  Monitor,
} from "lucide-react";
import { useApp } from "../../lib/store";
import { type Snapshot, collections } from "../../lib/model";
import { demoSnapshot } from "../../lib/demo";
import {
  formatDistance,
  kmToDisplay,
  displayToKm,
} from "../../lib/calculations";
import { PageHeading, Confirm, useT } from "../../components/shared";
import { Button } from "../../components/ui/button";
import { Dialog } from "../../components/ui/dialog";
import { NotificationSettings } from "./NotificationSettings";
export function Settings() {
  const { data, commit, importData, reset, dirty } = useApp();
  const t = useT();
  const settings = data.settings;
  const [confirm, setConfirm] = useState<"delete" | "demo" | "currency" | null>(
    null,
  );
  const [currency, setCurrency] = useState(settings.currency);
  const [days, setDays] = useState(String(settings.warningDays));
  const [km, setKm] = useState(
    String(kmToDisplay(settings.warningKm, settings.distanceUnit)),
  );
  const [saved, setSaved] = useState(false);
  const update = <K extends keyof Snapshot["settings"]>(
    key: K,
    value: Snapshot["settings"][K],
  ) =>
    commit((s) => {
      s.settings[key] = value;
    });
  const bytes = new Blob([JSON.stringify(data)]).size;
  const recordCount = collections.reduce((sum, k) => sum + data[k].length, 0);
  return (
    <>
      <PageHeading
        title={t("settings")}
        description={copy(
          "Make VehicleCare feel like yours, and keep your data in your hands.",
        )}
      />
      <div className="settings-grid">
        <NotificationSettings />
        <div className="card">
          <h2>{copy("Preferences")}</h2>
          <div className="settings-fields">
            <div className="field">
              <label htmlFor="language">{t("language")}</label>
              <select
                id="language"
                value={settings.language}
                onChange={(e) =>
                  update("language", e.target.value as "en" | "hi")
                }
              >
                <option value="en">{copy("English")}</option>
                <option value="hi">हिन्दी</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="currency">{t("currency")}</label>
              <select
                id="currency"
                value={settings.currency}
                onChange={(e) => {
                  setCurrency(e.target.value as typeof currency);
                  setConfirm("currency");
                }}
              >
                {["INR", "USD", "EUR", "GBP"].map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="unit">{t("distanceUnit")}</label>
              <select
                id="unit"
                value={settings.distanceUnit}
                onChange={(e) => {
                  const unit = e.target.value as "km" | "mi";
                  update("distanceUnit", unit);
                  setKm(
                    String(
                      Number(kmToDisplay(settings.warningKm, unit).toFixed(2)),
                    ),
                  );
                }}
              >
                <option value="km">{copy("Kilometres (km)")}</option>
                <option value="mi">{copy("Miles (mi)")}</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="default-vehicle">{copy("Default vehicle")}</label>
              <select
                id="default-vehicle"
                value={settings.selectedVehicleId}
                onChange={(e) => update("selectedVehicleId", e.target.value)}
              >
                <option value="">{t("allVehicles")}</option>
                {data.vehicles
                  .filter((v) => !v.archived)
                  .map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.name}
                    </option>
                  ))}
              </select>
            </div>
          </div>
          <h3 className="settings-subheading">{t("theme")}</h3>
          <div className="theme-options">
            {(
              [
                ["light", Sun],
                ["dark", Moon],
                ["system", Monitor],
              ] as const
            ).map(([theme, Icon]) => (
              <button
                key={theme}
                className={settings.theme === theme ? "selected" : ""}
                aria-pressed={settings.theme === theme}
                onClick={() => update("theme", theme)}
              >
                <Icon size={20} />
                {t(theme)}
              </button>
            ))}
          </div>
        </div>
        <div className="card">
          <h2>{copy("Maintenance reminders")}</h2>
          <p className="muted">
            {copy(
              "Defaults for new schedules. Existing schedules keep their own thresholds.",
            )}
          </p>
          <form
            className="form-grid"
            onSubmit={(e) => {
              e.preventDefault();
              const valid = commit((s) => {
                s.settings.warningDays = Number(days);
                s.settings.warningKm = displayToKm(
                  Number(km),
                  settings.distanceUnit,
                );
              });
              setSaved(valid);
            }}
          >
            <div className="field">
              <label htmlFor="warn-days">{t("warningDays")}</label>
              <input
                id="warn-days"
                type="number"
                min="0"
                max="3650"
                step="1"
                required
                value={days}
                onChange={(e) => {
                  setDays(e.target.value);
                  setSaved(false);
                }}
              />
            </div>
            <div className="field">
              <label htmlFor="warn-km">
                {t("warningKm")} ({settings.distanceUnit})
              </label>
              <input
                id="warn-km"
                type="number"
                min="0"
                step="any"
                required
                value={km}
                onChange={(e) => {
                  setKm(e.target.value);
                  setSaved(false);
                }}
              />
            </div>
            <div className="field-full">
              <Button type="submit">{copy("Save thresholds")}</Button>
              {saved && <span className="small teal">{copy("Saved")}</span>}
            </div>
          </form>
          <div className="notice">
            <ShieldCheck size={18} />
            <span>
              {copy(
                "Distance reminders use readings you enter. Web reminders appear while open; Android/iPhone date notifications are optional in Device notifications.",
              )}
            </span>
          </div>
        </div>
        <div className="card">
          <div className="section-heading">
            <h2>{copy("Storage & backup")}</h2>
            <Database size={20} className="teal" />
          </div>
          <dl className="detail-list">
            <dt>{copy("Snapshot size")}</dt>
            <dd>
              {(bytes / 1024).toFixed(1)} {copy("KB")}
            </dd>
            <dt>{copy("Vehicles / records")}</dt>
            <dd>
              {data.vehicles.length} / {recordCount}
            </dd>
            <dt>{copy("Revision")}</dt>
            <dd>{data.revision}</dd>
            <dt>{copy("Persistence")}</dt>
            <dd>{dirty ? "Unsaved changes in memory" : "Stored locally"}</dd>
            <dt>{copy("Canonical distance")}</dt>
            <dd>
              {copy("Kilometres (")}
              {formatDistance(1, settings)})
            </dd>
          </dl>
          <Button asChild>
            <Link to="/settings/backup">
              <Download size={17} />
              {t("backup")}
              <ArrowUpRight size={16} />
            </Link>
          </Button>
          <p className="small muted">
            {copy(
              "Storage capacity is browser-dependent. Export backups regularly.",
            )}
          </p>
        </div>
        <div className="card">
          <h2>{copy("Data controls")}</h2>
          <p className="muted">
            {copy(
              "Try a populated garage, or start fresh. These actions ask for confirmation.",
            )}
          </p>
          <div className="settings-actions">
            <Button variant="outline" onClick={() => setConfirm("demo")}>
              <FlaskConical size={17} />
              {copy("Add demo data")}
            </Button>
            <Button variant="destructive" onClick={() => setConfirm("delete")}>
              <Trash2 size={17} />
              {copy("Delete all data")}
            </Button>
          </div>
          <p className="small muted">
            {copy(
              "Demo data is merged with your records. It never overwrites your real vehicles.",
            )}
          </p>
        </div>
      </div>
      <Dialog
        open={confirm !== null}
        onOpenChange={() => setConfirm(null)}
        title={
          confirm === "delete"
            ? "Delete all data"
            : confirm === "currency"
              ? "Change currency"
              : "Add demo data"
        }
      >
        <Confirm
          title={
            confirm === "delete"
              ? "Erase all vehicles and records?"
              : confirm === "currency"
                ? "Reinterpret amounts in another currency?"
                : "Add an example garage?"
          }
          description={
            confirm === "delete"
              ? "This clears the complete snapshot, including emergency contacts and settings. Download a backup first."
              : confirm === "currency"
                ? "VehicleCare does not fetch exchange rates or convert money. Existing numeric amounts will be displayed in the selected currency."
                : "Two example vehicles and their care records will be added alongside your existing data."
          }
          confirmLabel={
            confirm === "delete"
              ? "Delete everything"
              : confirm === "currency"
                ? "Change currency"
                : "Add demo data"
          }
          onCancel={() => setConfirm(null)}
          onConfirm={() => {
            if (confirm === "delete") reset();
            else if (confirm === "demo") importData(demoSnapshot(), "merge");
            else if (confirm === "currency") update("currency", currency);
            setConfirm(null);
          }}
        />
      </Dialog>
    </>
  );
}
