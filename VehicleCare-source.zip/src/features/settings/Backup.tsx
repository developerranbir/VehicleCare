import { copy } from "../../lib/i18n";
import { useState } from "react";
import {
  Download,
  Upload,
  ShieldCheck,
  FileJson,
  AlertTriangle,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useApp } from "../../lib/store";
import {
  type Snapshot,
  MAX_BACKUP_BYTES,
  MAX_RECORDS,
  collections,
  today,
} from "../../lib/model";
import { download, exportCSV } from "../../lib/export";
import { createBackup, validateBackup } from "../../storage/backupService";
import { platform } from "../../platform/platform";
import { PageHeading, useT, Confirm } from "../../components/shared";
import { Button } from "../../components/ui/button";
import { Dialog } from "../../components/ui/dialog";
export function Backup() {
  const { data, raw, blocked, importData } = useApp();
  const t = useT();
  const [incoming, setIncoming] = useState<Snapshot | null>(null);
  const [mode, setMode] = useState<"merge" | "replace">("merge");
  const [confirm, setConfirm] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const count = (s: Snapshot) =>
    s.vehicles.length +
    collections.reduce((sum, key) => sum + s[key].length, 0);
  async function load(file?: File) {
    setSuccess("");
    setIncoming(null);
    setError("");
    if (!file) return;
    if (file.size > MAX_BACKUP_BYTES) {
      setError("Choose a backup smaller than 5 MB.");
      return;
    }
    try {
      const snapshot = validateBackup(await file.text());
      setIncoming(snapshot.data);
    } catch (err) {
      setError(
        `Backup is invalid. Existing data was not changed. ${err instanceof Error ? err.message : ""}`,
      );
    }
  }
  function apply() {
    if (incoming && importData(incoming, mode)) {
      setIncoming(null);
      setSuccess(
        useApp.getState().dirty
          ? "Import is in memory. Resolve the storage error and export a backup."
          : "Backup imported successfully.",
      );
    } else setError(useApp.getState().error ?? "Import failed.");
    setConfirm(false);
  }
  return (
    <>
      <Link className="back-link" to="/settings">
        ← {t("settings")}
      </Link>
      <PageHeading
        eyebrow="KEEP A COPY. KEEP CONTROL."
        title={t("backup")}
        description={copy(
          "Your device stores your records. A backup makes them portable.",
        )}
      />
      <div className="notice">
        <ShieldCheck size={20} />
        <div>
          <strong>{copy("Move your garage between devices")}</strong>
          <p>
            {copy(
              "Browsers, installed PWAs, and Android/iPhone apps can have separate storage. Export JSON here, save it outside VehicleCare, then choose that file in the destination app. Preview it and choose Merge or Replace.",
            )}
          </p>
        </div>
      </div>
      <div className="backup-grid">
        <div className="card">
          <span className="large-icon">
            <Download size={24} />
          </span>
          <h2>{copy("Export a complete backup")}</h2>
          <p className="muted">
            {copy(
              "All vehicles, records, settings, contacts, and renewal history in a validated JSON file.",
            )}
          </p>
          <div className="backup-summary">
            <strong>{data.vehicles.length}</strong>
            <span>{copy("vehicles")}</span>
            <strong>{count(data) - data.vehicles.length}</strong>
            <span>{copy("records")}</span>
          </div>
          <Button
            onClick={() =>
              download(createBackup(data), `vehiclecare-backup-${today()}.json`)
            }
          >
            <FileJson size={17} />
            {copy(
              platform.native() ? "Share JSON backup" : "Download JSON backup",
            )}
          </Button>
          <Button variant="outline" onClick={() => exportCSV(data)}>
            <Download size={16} />
            {copy("Export spending CSV")}
          </Button>
          {blocked && raw && (
            <Button
              variant="outline"
              onClick={() =>
                download(
                  raw,
                  `vehiclecare-original-${today()}.txt`,
                  "text/plain",
                )
              }
            >
              {copy("Download original unreadable data")}
            </Button>
          )}
        </div>
        <div className="card">
          <span className="large-icon">
            <Upload size={24} />
          </span>
          <h2>{copy("Restore from a backup")}</h2>
          <p className="muted">
            {copy(
              "Choose a VehicleCare JSON file. We’ll check it before changing anything.",
            )}
          </p>
          <label className="upload-zone" htmlFor="backup-file">
            <Upload size={25} />
            <strong>{copy("Choose a JSON backup")}</strong>
            <span className="small muted">
              {copy("Up to 5 MB ·")} {MAX_RECORDS.toLocaleString()}{" "}
              {copy("records")}
            </span>
            <input
              id="backup-file"
              type="file"
              accept=".json,application/json"
              onChange={(e) => {
                void load(e.target.files?.[0]);
                e.target.value = "";
              }}
            />
          </label>
          {error && (
            <p className="field-error" role="alert">
              {error}
            </p>
          )}
          {success && (
            <p className="teal" role="status">
              {success}
            </p>
          )}
        </div>
      </div>
      {incoming && (
        <div className="card import-preview">
          <div className="section-heading">
            <h2>{copy("Import preview")}</h2>
            <ShieldCheck className="teal" />
          </div>
          <p>
            {incoming.vehicles.length} {copy("vehicles and")}{" "}
            {count(incoming) - incoming.vehicles.length}{" "}
            {copy("records passed validation. Created")}{" "}
            {new Date(incoming.createdAt).toLocaleDateString()}.
          </p>
          <div className="import-options">
            <label>
              <input
                type="radio"
                name="import-mode"
                checked={mode === "merge"}
                onChange={() => setMode("merge")}
              />
              <span>
                <strong>{copy("Merge into my garage")}</strong>
                <span className="small muted">
                  {copy(
                    "Keep existing settings and records. Colliding IDs are remapped, including linked records. Importing the same backup twice adds two copies.",
                  )}
                </span>
              </span>
            </label>
            <label>
              <input
                type="radio"
                name="import-mode"
                checked={mode === "replace"}
                onChange={() => setMode("replace")}
              />
              <span>
                <strong>{copy("Replace all local data")}</strong>
                <span className="small muted">
                  {copy(
                    "Use the backup’s vehicles, records, and preferences. Existing records are removed.",
                  )}
                </span>
              </span>
            </label>
          </div>
          <div className="notice">
            {copy("After")} {mode}:{" "}
            {mode === "merge" ? count(data) + count(incoming) : count(incoming)}{" "}
            {copy("total records.")}{" "}
            {mode === "merge"
              ? "Current currency and distance preference are retained. All imported amounts are interpreted in the current currency; use Replace if currencies differ."
              : "Export your current data before replacing it."}
          </div>
          <Button onClick={() => setConfirm(true)}>
            {copy("Import")} {mode === "merge" ? "and merge" : "and replace"}
          </Button>
        </div>
      )}
      <div className="notice">
        <AlertTriangle size={20} />
        <div>
          <strong>{copy("Local storage is not a guaranteed backup.")}</strong>
          <p>
            {copy(
              "Clearing browser or app data, uninstalling the app, private browsing, storage eviction, or losing this device can remove your records. Save backups outside the app regularly and keep files private on shared devices.",
            )}
          </p>
        </div>
      </div>
      <Dialog
        open={confirm}
        onOpenChange={setConfirm}
        title={copy("Confirm backup import")}
      >
        <Confirm
          title={
            mode === "replace"
              ? "Replace all existing data?"
              : "Merge these records?"
          }
          description={
            mode === "replace"
              ? "This replaces the complete local snapshot. Download your current backup before continuing."
              : "Incoming records will be added and colliding IDs remapped. Current settings remain in place."
          }
          confirmLabel={mode === "replace" ? "Replace data" : "Merge data"}
          onCancel={() => setConfirm(false)}
          onConfirm={apply}
        />
      </Dialog>
    </>
  );
}
