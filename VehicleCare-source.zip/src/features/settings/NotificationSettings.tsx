import { useState } from "react";
import { Bell } from "lucide-react";
import { platform } from "../../platform/platform";
import { notificationService } from "../../platform/notificationService";
import { useRuntime } from "../../platform/runtime";
import { useApp } from "../../lib/store";
import { copy } from "../../lib/i18n";
import { Button } from "../../components/ui/button";
export function NotificationSettings() {
  const { data, commit } = useApp();
  const runtime = useRuntime((s) => s.reminders);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const native = platform.available("LocalNotifications");
  async function toggle() {
    setBusy(true);
    setError("");
    try {
      const enabled = data.settings.nativeRemindersEnabled;
      if (!enabled) {
        const permission = await notificationService.requestPermission();
        if (permission.display !== "granted") {
          setError(
            copy(
              "Notification permission was not granted. You can enable it in system settings and try again.",
            ),
          );
          return;
        }
      }
      if (
        !commit((s) => {
          s.settings.nativeRemindersEnabled = !enabled;
        })
      )
        throw new Error(useApp.getState().error ?? "Could not save preference");
      const reminders = await notificationService.sync(useApp.getState().data);
      useRuntime.setState({ reminders });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Reminder settings failed");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="card" id="notifications">
      <div className="section-heading">
        <h2>{copy("Device notifications")}</h2>
        <Bell size={22} className="teal" />
      </div>
      {native ? (
        <>
          <p className="muted">
            {copy(
              "Optional offline date reminders at approximately 9 AM local time. Notifications may show vehicle names on your lock screen. Enabling asks for system permission.",
            )}
          </p>
          <Button
            variant={
              data.settings.nativeRemindersEnabled ? "outline" : "default"
            }
            disabled={busy}
            onClick={() => {
              void toggle();
            }}
          >
            {copy(
              busy
                ? "Updating…"
                : data.settings.nativeRemindersEnabled
                  ? "Disable device reminders"
                  : "Enable device reminders",
            )}
          </Button>
          <p className="small muted">
            {copy("Permission")}: {runtime.permission} · {runtime.scheduled}{" "}
            {copy("scheduled")}
            {runtime.omitted > 0
              ? ` · ${runtime.omitted} ${copy("later reminders will be scheduled as earlier reminders expire")}`
              : ""}
          </p>
          <p className="small muted">
            {copy(
              "Android timing is inexact. Focus modes, battery restrictions, force-stopping, or system settings may delay or prevent delivery. Past notification times are not replayed. The app keeps at most 60 pending reminders.",
            )}
          </p>
        </>
      ) : (
        <p className="muted">
          {copy(
            "Web and PWA reminders appear while the app is open. Use calendar export for document dates. Device notifications are available in the Android and iOS apps.",
          )}
        </p>
      )}
      {(error || runtime.error) && (
        <p className="field-error" role="alert">
          {error || runtime.error}
        </p>
      )}
    </div>
  );
}
