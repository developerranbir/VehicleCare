import { copy } from "../../lib/i18n";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Car,
  ShieldCheck,
  WifiOff,
  ArrowRight,
  Download,
  Check,
} from "lucide-react";
import { useApp } from "../../lib/store";
import { demoSnapshot } from "../../lib/demo";
import { useT } from "../../components/shared";
import { Button } from "../../components/ui/button";
import { VehicleArt } from "../../components/shared";
export function Onboarding() {
  const { data, commit, importData } = useApp();
  const t = useT();
  const navigate = useNavigate();
  const [step, setStep] = useState(false);
  const demo = demoSnapshot().vehicles[0];
  return (
    <main className="onboarding">
      <div className="onboarding-brand">
        <span className="brand-icon">
          <Car size={23} />
        </span>
        <strong>
          {copy("Vehicle")}
          <span>{copy("Care")}</span>
        </strong>
        <span className="local-pill">
          <ShieldCheck size={14} />
          {copy("Private by design")}
        </span>
      </div>
      <div className="welcome-grid">
        <section className="welcome-content">
          <div className="eyebrow">
            <span className="tiny-dot" />
            {copy("A LITTLE CARE GOES A LONG WAY")}
          </div>
          <h1>{t("welcome")}</h1>
          <p className="welcome-description">{t("welcomeText")}</p>
          {!step ? (
            <>
              <div className="welcome-actions">
                <Button onClick={() => setStep(true)}>
                  {t("getStarted")}
                  <ArrowRight size={18} />
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    if (importData(demoSnapshot(), "merge"))
                      navigate("/dashboard");
                  }}
                >
                  {t("demo")}
                </Button>
              </div>
              <button
                className="text-link"
                onClick={() => {
                  commit((s) => {
                    s.settings.onboarded = true;
                  });
                  navigate("/settings/backup");
                }}
              >
                <Download size={16} />
                {copy("Already have a backup? Import it")}
              </button>
            </>
          ) : (
            <div className="welcome-preferences">
              <h2>{copy("Let’s make it yours")}</h2>
              <div className="form-grid">
                <div className="field">
                  <label htmlFor="welcome-currency">{t("currency")}</label>
                  <select
                    id="welcome-currency"
                    value={data.settings.currency}
                    onChange={(e) =>
                      commit((s) => {
                        s.settings.currency = e.target
                          .value as typeof s.settings.currency;
                      })
                    }
                  >
                    {["INR", "USD", "EUR", "GBP"].map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <label htmlFor="welcome-unit">{t("distanceUnit")}</label>
                  <select
                    id="welcome-unit"
                    value={data.settings.distanceUnit}
                    onChange={(e) =>
                      commit((s) => {
                        s.settings.distanceUnit = e.target.value as "km" | "mi";
                      })
                    }
                  >
                    <option value="km">{copy("Kilometres")}</option>
                    <option value="mi">{copy("Miles")}</option>
                  </select>
                </div>
                <div className="field">
                  <label htmlFor="welcome-language">{t("language")}</label>
                  <select
                    id="welcome-language"
                    value={data.settings.language}
                    onChange={(e) =>
                      commit((s) => {
                        s.settings.language = e.target.value as "en" | "hi";
                      })
                    }
                  >
                    <option value="en">{copy("English")}</option>
                    <option value="hi">हिन्दी</option>
                  </select>
                </div>
              </div>
              <Button
                onClick={() => {
                  commit((s) => {
                    s.settings.onboarded = true;
                  });
                  navigate("/garage/new");
                }}
              >
                {copy("Add my first vehicle")}
                <ArrowRight size={17} />
              </Button>
              <Button
                variant="ghost"
                onClick={() => {
                  commit((s) => {
                    s.settings.onboarded = true;
                  });
                  navigate("/dashboard");
                }}
              >
                {copy("I’ll add a vehicle later")}
              </Button>
            </div>
          )}
          <div className="welcome-privacy">
            <ShieldCheck size={24} />
            <div>
              <strong>{t("privacy")}</strong>
              <p>{t("privacyText")}</p>
              <span className="small muted">
                {copy(
                  "Keep backups. Clearing browser data can remove your records.",
                )}
              </span>
            </div>
          </div>
        </section>
        <section
          className="welcome-visual"
          aria-label={copy("VehicleCare vehicle illustration")}
        >
          <div className="visual-orbit" />
          <div className="visual-label">
            <span className="teal">
              <Check size={16} />
            </span>
            {copy("Less worry. More open roads.")}
          </div>
          <div className="welcome-car">
            <VehicleArt vehicle={demo} />
          </div>
          <div className="visual-status">
            <span className="large-icon">
              <WrenchIcon />
            </span>
            <div>
              <strong>{copy("Every service. Every journey.")}</strong>
              <p className="small muted">
                {copy("A clear picture of your vehicle’s care.")}
              </p>
            </div>
            <Check size={20} className="teal" />
          </div>
          <div className="visual-offline">
            <WifiOff size={19} />
            <strong>{copy("Works offline")}</strong>
            <span className="small muted">
              {copy("Ready wherever life takes you")}
            </span>
          </div>
        </section>
      </div>
      <footer className="welcome-footer">
        <span>{copy("VehicleCare · Your Vehicle. Your Care.")}</span>
        <span>{copy("100% local. No account needed.")}</span>
      </footer>
    </main>
  );
}
function WrenchIcon() {
  return <Car size={22} />;
}
