import { copy } from "../../lib/i18n";
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import {
  Car,
  Plus,
  ArrowLeft,
  Archive,
  RotateCcw,
  Pencil,
  Gauge,
  CalendarDays,
  Fuel,
  CheckCircle2,
} from "lucide-react";
import { useApp } from "../../lib/store";
import { type Vehicle, id, vehicleSchema } from "../../lib/model";
import {
  displayToKm,
  formatDate,
  formatDistance,
  formatMoney,
  kmToDisplay,
  ledger,
} from "../../lib/calculations";
import {
  PageHeading,
  VehicleCard,
  AddVehicleCard,
  Empty,
  useT,
  VehicleArt,
  Confirm,
} from "../../components/shared";
import { Button } from "../../components/ui/button";
import { Dialog } from "../../components/ui/dialog";
export function Garage() {
  const { data } = useApp();
  const t = useT();
  const [archived, setArchived] = useState(false);
  const vehicles = data.vehicles.filter((v) => v.archived === archived);
  return (
    <>
      <PageHeading
        eyebrow="YOUR PERSONAL FLEET"
        title={t("garage")}
        description={copy(
          "A home for every vehicle, and everything that keeps it running.",
        )}
        action={
          <Button asChild>
            <Link to="/garage/new">
              <Plus size={17} />
              {t("addVehicle")}
            </Link>
          </Button>
        }
      />
      <div className="tabs">
        <button
          className={!archived ? "selected" : ""}
          onClick={() => setArchived(false)}
        >
          {t("active")}{" "}
          <span>{data.vehicles.filter((v) => !v.archived).length}</span>
        </button>
        <button
          className={archived ? "selected" : ""}
          onClick={() => setArchived(true)}
        >
          {t("archived")}{" "}
          <span>{data.vehicles.filter((v) => v.archived).length}</span>
        </button>
      </div>
      {!vehicles.length && archived ? (
        <Empty
          title={copy("No archived vehicles")}
          description={copy(
            "Archived vehicles keep all their records and can be restored anytime.",
          )}
        />
      ) : (
        <div className="garage-grid">
          {vehicles.map((v) => (
            <VehicleCard key={v.id} vehicle={v} />
          ))}
          {!archived && <AddVehicleCard />}
        </div>
      )}
      <div className="privacy-strip">
        <CheckCircle2 size={18} />
        <span>
          {copy("Private by design. Your garage lives on this device.")}
        </span>
        <Link to="/settings/backup">
          {copy("Keep a backup")}
          <span>↗</span>
        </Link>
      </div>
    </>
  );
}
export function VehicleForm() {
  const { vehicleId } = useParams();
  const { data, saveVehicle, commit } = useApp();
  const existing = data.vehicles.find((v) => v.id === vehicleId);
  const t = useT();
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const [correction, setCorrection] = useState<Vehicle | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<Record<string, string>>({
    defaultValues: existing
      ? {
          ...Object.fromEntries(
            Object.entries(existing).map(([k, v]) => [k, String(v)]),
          ),
          odometer: String(
            Number(
              kmToDisplay(
                existing.odometer,
                data.settings.distanceUnit,
              ).toFixed(5),
            ),
          ),
          purchaseCost: String(existing.purchaseCost / 100),
        }
      : {
          name: "",
          make: "",
          model: "",
          year: String(new Date().getFullYear()),
          registration: "",
          type: "Car",
          fuelType: "Petrol",
          odometer: "0",
          purchaseDate: "",
          purchaseCost: "",
          notes: "",
          color: "teal",
        },
  });
  if (vehicleId && !existing)
    return (
      <Empty
        title={copy("Vehicle not found")}
        description={copy(
          "This vehicle may have been removed by an imported backup.",
        )}
        action={
          <Button asChild>
            <Link to="/garage">{copy("Back to garage")}</Link>
          </Button>
        }
      />
    );
  const finish = (vehicle: Vehicle, allow = false) => {
    if (saveVehicle(vehicle, allow)) {
      commit((s) => {
        s.settings.onboarded = true;
      });
      navigate(`/garage/${vehicle.id}`);
    } else setError(useApp.getState().error ?? "Could not save");
  };
  const submit = handleSubmit((values) => {
    try {
      const vehicle = vehicleSchema.parse({
        ...values,
        id: existing?.id ?? id(),
        year: Number(values.year),
        odometer: displayToKm(
          Number(values.odometer),
          data.settings.distanceUnit,
        ),
        purchaseCost: Math.round(Number(values.purchaseCost || 0) * 100),
        archived: existing?.archived ?? false,
      });
      if (existing && vehicle.odometer < existing.odometer)
        setCorrection(vehicle);
      else finish(vehicle);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Check your values");
    }
  });
  const fields = [
    ["name", t("name"), "text", true],
    ["registration", t("registration"), "text", false],
    ["make", t("make"), "text", true],
    ["model", t("model"), "text", true],
    ["year", t("year"), "number", true],
    [
      "odometer",
      `${t("odometer")} (${data.settings.distanceUnit})`,
      "number",
      true,
    ],
    ["purchaseDate", t("purchaseDate"), "date", false],
    [
      "purchaseCost",
      `${t("purchaseCost")} (${data.settings.currency})`,
      "number",
      false,
    ],
  ] as const;
  return (
    <>
      <Link className="back-link" to="/garage">
        <ArrowLeft size={16} /> {t("garage")}
      </Link>
      <PageHeading
        title={existing ? `${t("edit")} ${existing.name}` : t("addVehicle")}
        description={copy(
          "Give your vehicle a place in your garage. You can update these details anytime.",
        )}
      />
      <div className="card form-card">
        <div className="section-heading">
          <span className="section-icon">
            <Car size={21} />
          </span>
          <div>
            <h2>{copy("Vehicle details")}</h2>
            <p className="small muted">
              {copy("A few details to get you started")}
            </p>
          </div>
        </div>
        <form onSubmit={submit} className="form-grid">
          {fields.map(([key, label, type, required]) => (
            <div className="field" key={key}>
              <label htmlFor={`vehicle-${key}`}>
                {label}
                {required ? " *" : ""}
              </label>
              <input
                id={`vehicle-${key}`}
                type={type}
                inputMode={
                  type === "number"
                    ? key === "year"
                      ? "numeric"
                      : "decimal"
                    : undefined
                }
                min={
                  type === "number" ? (key === "year" ? 1900 : 0) : undefined
                }
                max={key === "year" ? 2100 : undefined}
                step={
                  key === "year" ? "1" : type === "number" ? "any" : undefined
                }
                {...register(key, {
                  required: required ? "This field is required" : false,
                  validate:
                    type === "number"
                      ? (v) =>
                          (v === "" && !required) ||
                          (Number.isFinite(Number(v)) && Number(v) >= 0) ||
                          "Enter a valid number"
                      : undefined,
                })}
              />
              {errors[key] && (
                <span className="field-error" role="alert">
                  {String(errors[key]?.message)}
                </span>
              )}
            </div>
          ))}
          {[
            ["type", t("type"), ["Car", "Motorcycle", "Scooter", "Other"]],
            [
              "fuelType",
              t("fuelType"),
              ["Petrol", "Diesel", "Electric", "Hybrid", "CNG", "Other"],
            ],
            ["color", "Card colour", ["teal", "blue", "amber", "violet"]],
          ].map(([key, label, options]) => (
            <div className="field" key={String(key)}>
              <label htmlFor={`vehicle-${key}`}>{String(label)}</label>
              <select id={`vehicle-${key}`} {...register(String(key))}>
                {(options as string[]).map((option) => (
                  <option key={option} value={option}>
                    {copy(option)}
                  </option>
                ))}
              </select>
            </div>
          ))}
          <div className="field field-full">
            <label htmlFor="vehicle-notes">{t("notes")}</label>
            <textarea id="vehicle-notes" rows={3} {...register("notes")} />
          </div>
          {error && (
            <p role="alert" className="field-error field-full">
              {error}
            </p>
          )}
          <div className="dialog-actions field-full">
            <Button
              variant="outline"
              type="button"
              onClick={() => navigate("/garage")}
            >
              {t("cancel")}
            </Button>
            <Button type="submit">
              {existing ? t("save") : t("addVehicle")}
            </Button>
          </div>
        </form>
      </div>
      <Dialog
        open={!!correction}
        onOpenChange={() => setCorrection(null)}
        title={copy("Confirm odometer correction")}
      >
        <Confirm
          title={copy("Reduce the current reading?")}
          description={copy(
            "Only correct a mistaken reading. A value below a recorded fuel, service, charging, or trip reading will be rejected.",
          )}
          confirmLabel={copy("Confirm correction")}
          onCancel={() => setCorrection(null)}
          onConfirm={() => {
            if (correction) finish(correction, true);
            setCorrection(null);
          }}
        />
      </Dialog>
    </>
  );
}
export function VehicleDetail() {
  const { vehicleId } = useParams();
  const { data, commit } = useApp();
  const v = data.vehicles.find((v) => v.id === vehicleId);
  const [confirm, setConfirm] = useState(false);
  const t = useT();
  if (!v)
    return (
      <Empty
        title={copy("Vehicle not found")}
        description={copy("Return to your garage to choose a vehicle.")}
        action={
          <Button asChild>
            <Link to="/garage">{copy("My garage")}</Link>
          </Button>
        }
      />
    );
  const costs = ledger(data).filter((e) => e.vehicleId === v.id);
  return (
    <>
      <Link className="back-link" to="/garage">
        <ArrowLeft size={16} />
        {t("garage")}
      </Link>
      <PageHeading
        title={v.name}
        description={`${v.year} ${v.make} ${v.model} · ${v.registration || "No registration saved"}`}
        action={
          <Button variant="outline" asChild>
            <Link to={`/garage/${v.id}/edit`}>
              <Pencil size={16} />
              {t("edit")}
            </Link>
          </Button>
        }
      />
      <div className="detail-grid">
        <div className="card">
          <VehicleArt vehicle={v} />
          <div className="detail-metrics">
            <div>
              <Gauge />
              <span>{t("odometer")}</span>
              <strong>{formatDistance(v.odometer, data.settings)}</strong>
            </div>
            <div>
              <Fuel />
              <span>{t("fuelType")}</span>
              <strong>{v.fuelType}</strong>
            </div>
            <div>
              <CalendarDays />
              <span>{t("purchaseDate")}</span>
              <strong>
                {v.purchaseDate
                  ? formatDate(v.purchaseDate, data.settings)
                  : copy("Not recorded")}
              </strong>
            </div>
          </div>
        </div>
        <div className="card">
          <h2>{copy("Ownership details")}</h2>
          <dl className="detail-list">
            <dt>{copy("Purchase price")}</dt>
            <dd>
              {v.purchaseCost
                ? formatMoney(v.purchaseCost, data.settings)
                : copy("Not recorded")}
            </dd>
            <dt>{copy("Total recorded expenses")}</dt>
            <dd>
              {formatMoney(
                costs.reduce((sum, e) => sum + e.amount, 0),
                data.settings,
              )}
            </dd>
            <dt>{copy("Status")}</dt>
            <dd>{v.archived ? t("archived") : t("active")}</dd>
          </dl>
          <p className="muted">{v.notes || copy("No notes added.")}</p>
          <Button variant="outline" onClick={() => setConfirm(true)}>
            {v.archived ? <RotateCcw size={16} /> : <Archive size={16} />}{" "}
            {v.archived ? t("restore") : t("archive")}
          </Button>
        </div>
      </div>
      <div className="card">
        <div className="section-heading">
          <h2>{copy("Vehicle activity")}</h2>
          <Button variant="ghost" asChild>
            <Link to="/expenses">{copy("View ledger ↗")}</Link>
          </Button>
        </div>
        {costs.length ? (
          <div className="activity-list">
            {costs.slice(0, 10).map((e) => (
              <div className="activity-row" key={e.id}>
                <span className="activity-icon">
                  <Fuel size={19} />
                </span>
                <div>
                  <strong>{e.title}</strong>
                  <span className="small muted">
                    {formatDate(e.date, data.settings)} · {e.category}
                  </span>
                </div>
                <strong>{formatMoney(e.amount, data.settings)}</strong>
              </div>
            ))}
          </div>
        ) : (
          <Empty
            title={t("noRecords")}
            description={copy(
              "Fuel, charging, service, and expense entries appear here.",
            )}
          />
        )}
      </div>
      <Dialog
        open={confirm}
        onOpenChange={setConfirm}
        title={v.archived ? t("restore") : t("archive")}
      >
        <Confirm
          title={
            v.archived ? "Bring this vehicle back?" : "Archive this vehicle?"
          }
          description={copy(
            "All records stay available. You can restore an archived vehicle at any time.",
          )}
          onCancel={() => setConfirm(false)}
          onConfirm={() => {
            commit((s) => {
              s.vehicles.find((vehicle) => vehicle.id === v.id)!.archived =
                !v.archived;
              if (s.settings.selectedVehicleId === v.id)
                s.settings.selectedVehicleId = "";
            });
            setConfirm(false);
          }}
        />
      </Dialog>
    </>
  );
}
