import { copy } from "../../lib/i18n";
import { Link } from "react-router-dom";
import {
  Car,
  Wallet,
  Bell,
  Fuel,
  Plus,
  ArrowUpRight,
  Zap,
  Wrench,
  ShieldCheck,
  CalendarDays,
  ArrowRight,
} from "lucide-react";
import { useApp } from "../../lib/store";
import {
  formatDate,
  formatDistance,
  formatMoney,
  fuelEconomy,
  formatEfficiency,
  ledger,
  maintenanceStatus,
  renewalStatus,
} from "../../lib/calculations";
import { today } from "../../lib/model";
import {
  PageHeading,
  VehicleCard,
  Empty,
  Badge,
  useT,
} from "../../components/shared";
import { Button } from "../../components/ui/button";
import { CostChart, CategoryChart } from "../reports/Charts";
export function Dashboard() {
  const { data } = useApp();
  const t = useT();
  const selected = data.settings.selectedVehicleId;
  const vehicles = data.vehicles.filter(
    (v) => !v.archived && (!selected || v.id === selected),
  );
  const costs = ledger(data).filter(
    (e) => !selected || e.vehicleId === selected,
  );
  const month = today().slice(0, 7);
  const monthly = costs
    .filter((e) => e.date.startsWith(month))
    .reduce((sum, e) => sum + e.amount, 0);
  const fuel = vehicles.flatMap((v) =>
    fuelEconomy(data.fuelLogs.filter((e) => e.vehicleId === v.id)),
  );
  const efficiency = fuel.length
    ? fuel.reduce((s, e) => s + e.distance, 0) /
      fuel.reduce((s, e) => s + e.litres, 0)
    : null;
  const maintenance = data.maintenanceRules
    .filter((e) => vehicles.some((v) => v.id === e.vehicleId))
    .map((e) => ({
      entry: e,
      ...maintenanceStatus(
        e,
        vehicles.find((v) => v.id === e.vehicleId)!,
      ),
    }))
    .filter((e) => e.status !== "On track");
  const renewals = data.renewals
    .filter((e) => vehicles.some((v) => v.id === e.vehicleId))
    .map((e) => ({ entry: e, ...renewalStatus(e) }))
    .filter((e) => e.status !== "On track");
  const reminders = [
    ...maintenance.map((e) => ({
      ...e,
      kind: "maintenance",
      detail: e.dueDate
        ? formatDate(e.dueDate, data.settings)
        : `At ${formatDistance(e.dueOdometer!, data.settings)}`,
    })),
    ...renewals.map((e) => ({
      ...e,
      kind: "renewals",
      detail: formatDate(e.entry.dueDate!, data.settings),
    })),
  ].sort(
    (a, b) => Number(b.status === "Overdue") - Number(a.status === "Overdue"),
  );
  return (
    <>
      <PageHeading
        eyebrow={new Intl.DateTimeFormat(
          data.settings.language === "hi" ? "hi-IN" : "en-IN",
          { weekday: "long", day: "numeric", month: "long" },
        ).format(new Date())}
        title={t("greeting")}
        description={t("dashboardSubtitle")}
        action={
          <Button asChild>
            <Link to="/garage/new">
              <Plus size={17} />
              {t("addVehicle")}
            </Link>
          </Button>
        }
      />
      <div className="stats-grid">
        <Stat
          icon={Car}
          label={t("vehicles")}
          value={String(vehicles.length)}
          detail="Ready for the road"
          color="teal"
        />
        <Stat
          icon={Wallet}
          label={t("totalSpent")}
          value={formatMoney(monthly, data.settings)}
          detail="From all recorded costs"
          color="blue"
        />
        <Stat
          icon={Bell}
          label={t("dueSoon")}
          value={String(reminders.length)}
          detail={
            reminders.length
              ? "Upcoming care & renewals"
              : "Everything is looking good"
          }
          color="amber"
        />
        <Stat
          icon={Fuel}
          label={t("efficiency")}
          value={
            efficiency === null
              ? "—"
              : formatEfficiency(efficiency, data.settings)
          }
          detail={
            efficiency === null
              ? "Needs two full-tank readings"
              : "Across valid full-tank intervals"
          }
          color="violet"
        />
      </div>
      <div className="section-heading outside">
        <div>
          <h2>{t("garage")}</h2>
          <p className="small muted">
            {copy("A little attention goes a long way.")}
          </p>
        </div>
        <Link className="text-link" to="/garage">
          {t("viewAll")} <ArrowUpRight size={16} />
        </Link>
      </div>
      {vehicles.length ? (
        <div className="dashboard-vehicles">
          {vehicles.slice(0, 3).map((v) => (
            <VehicleCard key={v.id} vehicle={v} />
          ))}
        </div>
      ) : (
        <div className="card">
          <Empty
            title={t("emptyGarage")}
            description={t("emptyGarageText")}
            action={
              <Button asChild>
                <Link to="/garage/new">
                  <Plus size={16} />
                  {t("addVehicle")}
                </Link>
              </Button>
            }
          />
        </div>
      )}
      <div className="dashboard-middle">
        <div className="card spending-card">
          <div className="section-heading">
            <div>
              <h2>{copy("Spending overview")}</h2>
              <p className="small muted">
                {copy("The bigger picture, one month at a time")}
              </p>
            </div>
            <span className="subtle-label">{copy("Last 6 months")}</span>
          </div>
          <CostChart items={costs} settings={data.settings} />
        </div>
        <div className="card attention-card">
          <div className="section-heading">
            <div>
              <h2>{copy("On the horizon")}</h2>
              <p className="small muted">
                {copy("A heads-up for what’s next")}
              </p>
            </div>
            <CalendarDays className="muted" size={20} />
          </div>
          {reminders.length ? (
            <div className="reminder-list">
              {reminders.slice(0, 3).map((r) => (
                <Link
                  key={r.entry.id}
                  to={`/${r.kind}`}
                  className="reminder-row"
                >
                  <span
                    className={`reminder-icon ${r.kind === "renewals" ? "blue" : "amber"}`}
                  >
                    {r.kind === "renewals" ? (
                      <ShieldCheck size={18} />
                    ) : (
                      <Wrench size={18} />
                    )}
                  </span>
                  <div>
                    <strong>{r.entry.title}</strong>
                    <span className="small muted">
                      {
                        data.vehicles.find((v) => v.id === r.entry.vehicleId)
                          ?.name
                      }{" "}
                      · {r.detail}
                    </span>
                    <Badge status={r.status} />
                  </div>
                  <ArrowRight size={16} />
                </Link>
              ))}
            </div>
          ) : (
            <Empty
              title={copy("Room to enjoy the journey")}
              description={copy(
                "No upcoming alerts. Add care schedules and expiry dates to see reminders here.",
              )}
            />
          )}
          <Link to="/maintenance" className="card-bottom-link">
            {copy("View maintenance planner")}
            <ArrowRight size={15} />
          </Link>
        </div>
      </div>
      <div className="dashboard-bottom">
        <div className="card">
          <div className="section-heading">
            <div>
              <h2>{t("recent")}</h2>
              <p className="small muted">
                {copy("The latest in your vehicle’s story")}
              </p>
            </div>
            <Link className="text-link" to="/expenses">
              {t("viewAll")} <ArrowUpRight size={16} />
            </Link>
          </div>
          {costs.length ? (
            <div className="activity-list">
              {costs.slice(0, 4).map((e) => (
                <Link
                  key={e.id}
                  to={`/${e.source === "fuelLogs" ? "fuel" : e.source === "chargingLogs" ? "charging" : e.source}`}
                  className="activity-row"
                >
                  <span
                    className={`activity-icon ${e.category === "Charging" ? "blue" : e.category === "Service" ? "amber" : ""}`}
                  >
                    {e.category === "Fuel" ? (
                      <Fuel size={19} />
                    ) : e.category === "Charging" ? (
                      <Zap size={19} />
                    ) : e.category === "Service" ? (
                      <Wrench size={19} />
                    ) : (
                      <Wallet size={19} />
                    )}
                  </span>
                  <div>
                    <strong>{e.title}</strong>
                    <span className="small muted">
                      {data.vehicles.find((v) => v.id === e.vehicleId)?.name} ·{" "}
                      {formatDate(e.date, data.settings)}
                    </span>
                  </div>
                  <strong>{formatMoney(e.amount, data.settings)}</strong>
                </Link>
              ))}
            </div>
          ) : (
            <Empty
              title={t("noRecords")}
              description={copy(
                "Your spending activity will appear as you add records.",
              )}
            />
          )}
        </div>
        <div className="card">
          <div className="section-heading">
            <div>
              <h2>{copy("Where it goes")}</h2>
              <p className="small muted">{copy("Your spending by category")}</p>
            </div>
          </div>
          <CategoryChart items={costs} settings={data.settings} />
        </div>
      </div>
      <div className="care-banner">
        <span>
          <ShieldCheck size={24} />
        </span>
        <div>
          <strong>
            {copy("Care for your vehicle. Keep your data yours.")}
          </strong>
          <p>
            {copy(
              "Saved locally, available offline. A regular backup keeps you in control.",
            )}
          </p>
        </div>
        <Button variant="outline" asChild>
          <Link to="/settings/backup">
            {copy("Back up my data")}
            <ArrowUpRight size={15} />
          </Link>
        </Button>
      </div>
    </>
  );
}
function Stat({
  icon: Icon,
  label,
  value,
  detail,
  color,
}: {
  icon: typeof Car;
  label: string;
  value: string;
  detail: string;
  color: string;
}) {
  return (
    <div className="stat-card">
      <div className="stat-top">
        <span className="small muted">{label}</span>
        <span className={`stat-icon ${color}`}>
          <Icon size={18} />
        </span>
      </div>
      <strong className="stat-value">{value}</strong>
      <span className="stat-detail">{copy(detail)}</span>
    </div>
  );
}
