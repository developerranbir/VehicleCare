import { Link } from "react-router-dom";
import {
  Fuel,
  Zap,
  Wrench,
  CalendarClock,
  Wallet,
  ShieldCheck,
  Route,
  ChartNoAxesCombined,
  ClipboardCheck,
  Phone,
  Settings,
  Download,
  Info,
  ChevronRight,
} from "lucide-react";
import { PageHeading, useT } from "../../components/shared";
import type { Label } from "../../lib/i18n";
import { copy } from "../../lib/i18n";
export function More() {
  const t = useT();
  const links: [string, Label, typeof Fuel][] = [
    ["fuel", "fuel", Fuel],
    ["charging", "charging", Zap],
    ["services", "services", Wrench],
    ["maintenance", "maintenance", CalendarClock],
    ["expenses", "expenses", Wallet],
    ["renewals", "renewals", ShieldCheck],
    ["trips", "trips", Route],
    ["reports", "reports", ChartNoAxesCombined],
    ["checklists", "checklists", ClipboardCheck],
    ["emergency", "emergency", Phone],
    ["settings", "settings", Settings],
    ["settings/backup", "backup", Download],
    ["about", "about", Info],
  ];
  return (
    <>
      <PageHeading
        title={copy("More")}
        description={copy("All your vehicle tools, one tap away.")}
      />
      <div className="more-grid">
        {links.map(([path, label, Icon]) => (
          <Link className="more-link card" key={path} to={`/${path}`}>
            <span className="record-icon">
              <Icon size={23} />
            </span>
            <strong>{t(label)}</strong>
            <ChevronRight size={19} />
          </Link>
        ))}
      </div>
    </>
  );
}
