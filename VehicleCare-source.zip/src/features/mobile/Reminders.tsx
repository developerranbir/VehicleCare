import { Link } from "react-router-dom";
import { Bell, Wrench, ShieldCheck, ChevronRight } from "lucide-react";
import { useApp } from "../../lib/store";
import {
  formatDate,
  formatDistance,
  maintenanceStatus,
  renewalStatus,
} from "../../lib/calculations";
import { PageHeading, Badge, Empty } from "../../components/shared";
import { copy } from "../../lib/i18n";
import { Button } from "../../components/ui/button";
export function Reminders() {
  const data = useApp((s) => s.data);
  const vehicles = data.vehicles.filter(
    (v) =>
      !v.archived &&
      (!data.settings.selectedVehicleId ||
        v.id === data.settings.selectedVehicleId),
  );
  const rules = data.maintenanceRules
    .filter((r) => vehicles.some((v) => v.id === r.vehicleId))
    .map((r) => {
      const vehicle = vehicles.find((v) => v.id === r.vehicleId)!;
      const status = maintenanceStatus(r, vehicle);
      return {
        id: r.id,
        title: r.title,
        vehicle: vehicle.name,
        status: status.status,
        detail: [
          status.dueDate ? formatDate(status.dueDate, data.settings) : "",
          status.dueOdometer !== undefined
            ? formatDistance(status.dueOdometer, data.settings)
            : "",
        ]
          .filter(Boolean)
          .join(" · "),
        path: "/maintenance",
        icon: Wrench,
      };
    });
  const renewals = data.renewals
    .filter((r) => vehicles.some((v) => v.id === r.vehicleId))
    .map((r) => ({
      id: r.id,
      title: r.title,
      vehicle: vehicles.find((v) => v.id === r.vehicleId)!.name,
      status: renewalStatus(r).status,
      detail: formatDate(r.dueDate!, data.settings),
      path: "/renewals",
      icon: ShieldCheck,
    }));
  const entries = [...rules, ...renewals].sort(
    (a, b) =>
      ({ Overdue: 0, Upcoming: 1, "On track": 2 })[
        a.status as "Overdue" | "Upcoming" | "On track"
      ] -
      { Overdue: 0, Upcoming: 1, "On track": 2 }[
        b.status as "Overdue" | "Upcoming" | "On track"
      ],
  );
  return (
    <>
      <PageHeading
        title={copy("Reminders")}
        description={copy(
          "Upcoming care and documents, based on your saved dates and readings.",
        )}
        action={
          <Button variant="outline" asChild>
            <Link to="/settings#notifications">
              <Bell size={18} />
              {copy("Notification settings")}
            </Link>
          </Button>
        }
      />
      <div className="notice">
        {copy(
          "Distance reminders use readings you enter. VehicleCare does not monitor your odometer automatically.",
        )}{" "}
        <Link to="/settings#notifications">
          {copy("Notification settings")} ↗
        </Link>
      </div>
      <div className="card">
        {entries.length ? (
          entries.map(({ icon: Icon, ...e }) => (
            <Link key={e.id} to={e.path} className="record-row">
              <span className="record-icon">
                <Icon size={22} />
              </span>
              <div className="record-main">
                <strong>{e.title}</strong>
                <span className="small muted">
                  {e.vehicle} · {e.detail}
                </span>
              </div>
              <Badge status={e.status} />
              <ChevronRight size={19} />
            </Link>
          ))
        ) : (
          <Empty
            title={copy("Nothing scheduled yet")}
            description={copy(
              "Add a maintenance schedule or document expiry to see reminders here.",
            )}
            action={
              <Button asChild>
                <Link to="/maintenance">{copy("Plan maintenance")}</Link>
              </Button>
            }
          />
        )}
      </div>
    </>
  );
}
