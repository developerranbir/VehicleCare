import { copy } from "../../lib/i18n";
import { useState } from "react";
import { Download } from "lucide-react";
import { useApp } from "../../lib/store";
import {
  ledger,
  formatMoney,
  fuelEconomy,
  formatEfficiency,
  recordedDistance,
  kmToDisplay,
  formatDate,
} from "../../lib/calculations";
import { PageHeading, Empty, useT } from "../../components/shared";
import { Button } from "../../components/ui/button";
import {
  CostChart,
  CategoryChart,
  ComparisonChart,
  EfficiencyChart,
} from "./Charts";
import { exportCSV } from "../../lib/export";
export function Reports() {
  const { data } = useApp();
  const t = useT();
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const selected = data.settings.selectedVehicleId;
  const costs = ledger(data).filter(
    (e) =>
      (!selected || e.vehicleId === selected) &&
      (!from || e.date >= from) &&
      (!to || e.date <= to),
  );
  const total = costs.reduce((s, e) => s + e.amount, 0);
  const allDistance = recordedDistance(data, selected || undefined);
  const vehicles = data.vehicles.filter((v) => !selected || v.id === selected);
  const efficiency = vehicles
    .flatMap((v) =>
      fuelEconomy(data.fuelLogs.filter((e) => e.vehicleId === v.id)).map(
        (e) => ({ ...e, vehicle: v.name, vehicleId: v.id }),
      ),
    )
    .filter((e) => (!from || e.date >= from) && (!to || e.date <= to));
  const services = data.services.filter(
    (e) =>
      (!selected || e.vehicleId === selected) &&
      (!from || e.date >= from) &&
      (!to || e.date <= to),
  );
  return (
    <>
      <PageHeading
        eyebrow="A CLEARER PICTURE"
        title={t("reports")}
        description={copy(
          "Understand the costs and care behind every journey.",
        )}
        action={
          <Button variant="outline" onClick={() => exportCSV(data)}>
            <Download size={17} />
            {copy("Export full ledger")}
          </Button>
        }
      />
      <div className="card report-filters">
        <div className="field">
          <label htmlFor="report-from">{copy("From date")}</label>
          <input
            id="report-from"
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
          />
        </div>
        <div className="field">
          <label htmlFor="report-to">{copy("To date")}</label>
          <input
            id="report-to"
            type="date"
            min={from}
            value={to}
            onChange={(e) => setTo(e.target.value)}
          />
        </div>
        <Button
          variant="ghost"
          onClick={() => {
            setFrom("");
            setTo("");
          }}
        >
          {copy("Reset dates")}
        </Button>
      </div>
      <div className="mini-stats">
        <div>
          <span className="muted small">{copy("Recorded spending")}</span>
          <strong>{formatMoney(total, data.settings)}</strong>
        </div>
        <div>
          <span className="muted small">{copy("Transactions")}</span>
          <strong>{costs.length}</strong>
        </div>
        <div>
          <span className="muted small">
            {copy("Recorded cost /")} {data.settings.distanceUnit}{" "}
            {copy("(all time)")}
          </span>
          <strong>
            {allDistance
              ? `${formatMoney(
                  ledger(data)
                    .filter((e) => !selected || e.vehicleId === selected)
                    .reduce((s, e) => s + e.amount, 0) /
                    kmToDisplay(allDistance, data.settings.distanceUnit),
                  data.settings,
                )}/${data.settings.distanceUnit}`
              : copy("Unavailable")}
          </strong>
        </div>
      </div>
      <p className="form-note">
        {copy(
          "Cost per distance uses all recorded costs and the span between recorded odometers for each vehicle. It is an incomplete ownership estimate, not a fuel-consumption measurement.",
        )}
      </p>
      <div className="dashboard-middle">
        <div className="card">
          <h2>{copy("Monthly costs")}</h2>
          <CostChart
            items={costs}
            settings={data.settings}
            from={from}
            to={to}
          />
        </div>
        <div className="card">
          <h2>{copy("Category distribution")}</h2>
          <CategoryChart items={costs} settings={data.settings} />
        </div>
      </div>
      <div className="dashboard-middle">
        <div className="card">
          <h2>{copy("Vehicle comparison")}</h2>
          {costs.length ? (
            <ComparisonChart
              data={vehicles.map((v) => ({
                name: v.name,
                cost:
                  costs
                    .filter((e) => e.vehicleId === v.id)
                    .reduce((s, e) => s + e.amount, 0) / 100,
              }))}
              settings={data.settings}
            />
          ) : (
            <Empty
              title={copy("Nothing to compare yet")}
              description={copy(
                "Record costs for your vehicles to compare them.",
              )}
            />
          )}
        </div>
        <div className="card">
          <h2>{copy("Fuel efficiency")}</h2>
          <p className="small muted">{copy("Latest 12 measured intervals")}</p>
          {efficiency.length > 0 && (
            <EfficiencyChart
              points={efficiency.map((e) => ({
                date: e.date,
                vehicle: e.vehicle,
                vehicleId: e.vehicleId,
                value: e.kmPerLitre,
                litres: e.litres,
              }))}
              settings={data.settings}
            />
          )}
          {efficiency.length ? (
            <div className="record-list">
              {efficiency
                .slice()
                .sort((a, b) => b.date.localeCompare(a.date))
                .slice(0, 12)
                .map((e, i) => (
                  <div className="activity-row" key={i}>
                    <div>
                      <strong>{e.vehicle}</strong>
                      <span className="small muted">
                        {formatDate(e.date, data.settings)} · {e.litres} L
                      </span>
                    </div>
                    <strong>
                      {formatEfficiency(e.kmPerLitre, data.settings, 2)}
                    </strong>
                  </div>
                ))}
            </div>
          ) : (
            <Empty
              title={copy("More fill-ups, better insight")}
              description={copy(
                "Record two full tanks with consistent odometers. Partial fills between them are included.",
              )}
            />
          )}
        </div>
      </div>
      <div className="card">
        <h2>{copy("Service cost history")}</h2>
        <p className="small muted">
          {copy(
            "Latest 20 service records. View the full history in Service history.",
          )}
        </p>
        {services.length ? (
          <div className="record-list">
            {services
              .sort((a, b) => b.date.localeCompare(a.date))
              .slice(0, 20)
              .map((e) => (
                <div className="activity-row" key={e.id}>
                  <div>
                    <strong>{e.title}</strong>
                    <span className="small muted">
                      {data.vehicles.find((v) => v.id === e.vehicleId)?.name} ·{" "}
                      {formatDate(e.date, data.settings)}
                    </span>
                  </div>
                  <strong>
                    {formatMoney(
                      e.partsCost + e.labourCost + e.miscCost,
                      data.settings,
                    )}
                  </strong>
                </div>
              ))}
          </div>
        ) : (
          <Empty
            title={copy("No service history yet")}
            description={copy(
              "Your completed service records will appear here.",
            )}
          />
        )}
      </div>
    </>
  );
}
