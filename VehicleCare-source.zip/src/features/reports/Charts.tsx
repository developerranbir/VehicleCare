import { copy } from "../../lib/i18n";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  LineChart,
  Line,
} from "recharts";
import {
  format,
  subMonths,
  parseISO,
  addMonths,
  differenceInCalendarMonths,
} from "date-fns";
import {
  type LedgerItem,
  formatMoney,
  kmToDisplay,
  formatDate,
} from "../../lib/calculations";
import { type Snapshot } from "../../lib/model";
import { Empty } from "../../components/shared";
const colours = [
  "#0d9488",
  "#71c9bd",
  "#93a8df",
  "#f0c478",
  "#bdace2",
  "#84bbd2",
  "#d3dee3",
];
export function monthlyCosts(
  items: LedgerItem[],
  language: "en" | "hi" = "en",
  from?: string,
  to?: string,
) {
  const end = to ? parseISO(to) : new Date();
  const start = from ? parseISO(from) : subMonths(end, 5);
  return Array.from(
    { length: Math.max(1, differenceInCalendarMonths(end, start) + 1) },
    (_, i) => {
      const date = addMonths(start, i);
      const month = format(date, "yyyy-MM");
      return {
        month: new Intl.DateTimeFormat(language === "hi" ? "hi-IN" : "en-IN", {
          month: "short",
          ...(from || to ? { year: "2-digit" as const } : {}),
        }).format(date),
        cost:
          items
            .filter((e) => e.date.startsWith(month))
            .reduce((sum, e) => sum + e.amount, 0) / 100,
      };
    },
  );
}
export function CostChart({
  items,
  settings,
  from,
  to,
}: {
  items: LedgerItem[];
  settings: Snapshot["settings"];
  from?: string;
  to?: string;
}) {
  if (!items.length)
    return (
      <Empty
        title={copy("Your spending story starts here")}
        description={copy(
          "Add a fuel, charging, service, or expense record to see monthly costs.",
        )}
      />
    );
  return (
    <div
      className="chart"
      role="img"
      aria-label={`${copy("Recorded monthly spending")}. ${monthlyCosts(
        items,
        settings.language,
        from,
        to,
      )
        .map(
          (row) =>
            `${row.month}: ${formatMoney(Math.round(row.cost * 100), settings)}`,
        )
        .join("; ")}`}
    >
      <ResponsiveContainer width="100%" height={235}>
        <AreaChart
          data={monthlyCosts(items, settings.language, from, to)}
          margin={{ left: 0, right: 10, top: 20, bottom: 0 }}
        >
          <defs>
            <linearGradient id="costGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0d9488" stopOpacity={0.2} />
              <stop offset="100%" stopColor="#0d9488" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid
            vertical={false}
            stroke="var(--line)"
            strokeDasharray="3 5"
          />
          <XAxis
            dataKey="month"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "var(--muted)", fontSize: 11 }}
            dy={8}
          />
          <YAxis
            width={53}
            axisLine={false}
            tickLine={false}
            tick={{ fill: "var(--muted)", fontSize: 10 }}
            tickFormatter={(v: number) =>
              v >= 1000 ? `${(v / 1000).toFixed(0)}k` : String(v)
            }
          />
          <Tooltip
            contentStyle={{
              background: "var(--card)",
              border: "1px solid var(--line)",
              borderRadius: 10,
            }}
            formatter={(value) => formatMoney(Number(value) * 100, settings)}
          />
          <Area
            isAnimationActive={false}
            type="monotone"
            dataKey="cost"
            stroke="#0d9488"
            strokeWidth={2.5}
            fill="url(#costGradient)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
export function CategoryChart({
  items,
  settings,
}: {
  items: LedgerItem[];
  settings: Snapshot["settings"];
}) {
  const categories = [...new Set(items.map((e) => e.category))]
    .map((name) => ({
      name,
      value: items
        .filter((e) => e.category === name)
        .reduce((s, e) => s + e.amount, 0),
    }))
    .filter((e) => e.value > 0)
    .sort((a, b) => b.value - a.value);
  if (!categories.length)
    return (
      <Empty
        title={copy("No spending to compare")}
        description={copy("Your categories appear when costs are recorded.")}
      />
    );
  return (
    <div className="category-chart">
      <div role="img" aria-label={copy("Spending by category")}>
        <ResponsiveContainer width="100%" height={165}>
          <PieChart>
            <Pie
              isAnimationActive={false}
              data={categories}
              dataKey="value"
              nameKey="name"
              innerRadius={53}
              outerRadius={73}
              paddingAngle={4}
              stroke="none"
            >
              {categories.map((c, i) => (
                <Cell key={c.name} fill={colours[i % colours.length]} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                background: "var(--card)",
                border: "1px solid var(--line)",
                borderRadius: 10,
              }}
              formatter={(value) => formatMoney(Number(value), settings)}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="chart-legend">
        {categories.map((c, i) => (
          <div key={c.name}>
            <span>
              <i style={{ background: colours[i % colours.length] }} />
              {copy(c.name)}
            </span>
            <strong>{formatMoney(c.value, settings)}</strong>
          </div>
        ))}
      </div>
    </div>
  );
}
export function ComparisonChart({
  data,
  settings,
}: {
  data: { name: string; cost: number }[];
  settings: Snapshot["settings"];
}) {
  return (
    <div
      className="chart"
      role="img"
      aria-label={`${copy("Recorded spending by vehicle")}. ${data.map((row) => `${row.name}: ${formatMoney(Math.round(row.cost * 100), settings)}`).join("; ")}`}
    >
      <ResponsiveContainer width="100%" height={230}>
        <BarChart data={data}>
          <CartesianGrid vertical={false} stroke="var(--line)" />
          <XAxis dataKey="name" tick={{ fill: "var(--muted)", fontSize: 11 }} />
          <YAxis tick={{ fill: "var(--muted)", fontSize: 11 }} />
          <Tooltip
            formatter={(v) => formatMoney(Number(v) * 100, settings)}
            contentStyle={{ background: "var(--card)" }}
          />
          <Bar
            isAnimationActive={false}
            dataKey="cost"
            fill="#0d9488"
            radius={[5, 5, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
export function EfficiencyChart({
  points,
  settings,
}: {
  points: {
    date: string;
    vehicle: string;
    vehicleId: string;
    value: number;
    litres: number;
  }[];
  settings: Snapshot["settings"];
}) {
  const vehicles = [...new Set(points.map((p) => p.vehicleId))];
  const dates = [...new Set(points.map((p) => p.date))].sort();
  const data = dates.map((date) => {
    const row: Record<string, string | number> = { date };
    for (const [index, vehicle] of vehicles.entries()) {
      const values = points.filter(
        (p) => p.date === date && p.vehicleId === vehicle,
      );
      if (values.length)
        row[`series${index}`] = kmToDisplay(
          values.reduce((s, p) => s + p.value * p.litres, 0) /
            values.reduce((s, p) => s + p.litres, 0),
          settings.distanceUnit,
        );
    }
    return row;
  });
  return (
    <div
      className="chart"
      role="img"
      aria-label={`${copy("Fuel efficiency")}. ${points.map((p) => `${p.vehicle}, ${formatDate(p.date, settings)}: ${kmToDisplay(p.value, settings.distanceUnit).toFixed(2)} ${settings.distanceUnit}/L`).join("; ")}`}
    >
      <ResponsiveContainer width="100%" height={220}>
        <LineChart
          data={data}
          margin={{ top: 20, right: 10, left: 0, bottom: 5 }}
        >
          <CartesianGrid stroke="var(--line)" strokeDasharray="3 5" />
          <XAxis
            dataKey="date"
            tickFormatter={(v) => formatDate(String(v), settings)}
            tick={{ fill: "var(--muted)", fontSize: 10 }}
          />
          <YAxis width={40} tick={{ fill: "var(--muted)", fontSize: 10 }} />
          <Tooltip
            labelFormatter={(value) => formatDate(String(value), settings)}
            formatter={(value) =>
              `${Number(value).toFixed(2)} ${settings.distanceUnit}/L`
            }
            contentStyle={{
              background: "var(--card)",
              border: "1px solid var(--line)",
              borderRadius: 8,
            }}
          />
          {vehicles.map((vehicle, index) => (
            <Line
              key={vehicle}
              name={points.find((p) => p.vehicleId === vehicle)!.vehicle}
              dataKey={`series${index}`}
              stroke={colours[index % colours.length]}
              strokeWidth={2}
              dot={{ r: 4 }}
              isAnimationActive={false}
              connectNulls={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
      <p className="form-note">
        {copy(
          "Each point represents measured full-tank intervals. Different vehicles are shown separately.",
        )}
      </p>
    </div>
  );
}
