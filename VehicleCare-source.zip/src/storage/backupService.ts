import { z } from "zod";
import {
  type Snapshot,
  MAX_BACKUP_BYTES,
  parseSnapshot,
  snapshotSchema,
} from "../lib/model";
import manifest from "../../package.json" with { type: "json" };
export function createBackup(snapshot: Snapshot, now = new Date()) {
  const data = snapshotSchema.parse(snapshot);
  return JSON.stringify({
    ...data,
    exportedAt: now.toISOString(),
    applicationVersion: manifest.version,
  });
}
export function validateBackup(raw: string) {
  if (new Blob([raw]).size > MAX_BACKUP_BYTES)
    throw new Error("Backup exceeds the 5 MB limit");
  const data = parseSnapshot(raw);
  const metadata = z
    .object({
      exportedAt: z.iso.datetime().optional(),
      applicationVersion: z.string().min(1).max(64).optional(),
    })
    .parse(JSON.parse(raw));
  return { data, metadata };
}
