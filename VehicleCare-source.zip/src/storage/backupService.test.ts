import { describe, expect, it } from "vitest";
import { createBackup, validateBackup } from "./backupService";
import { demoSnapshot } from "../lib/demo";
import { MAX_BACKUP_BYTES } from "../lib/model";
describe("portable web/native JSON backups", () => {
  it("adds export metadata without changing the application snapshot", () => {
    const s = demoSnapshot(),
      before = structuredClone(s);
    const raw = createBackup(s, new Date("2026-10-13T09:00:00Z"));
    const backup = validateBackup(raw);
    expect(backup.metadata.exportedAt).toBe("2026-10-13T09:00:00.000Z");
    expect(backup.metadata.applicationVersion).toBe("1.0.0");
    expect(backup.data).toEqual(s);
    expect(s).toEqual(before);
  });
  it("accepts original version-1 backups without losing settings or records", () => {
    const legacy = JSON.parse(JSON.stringify(demoSnapshot()));
    delete legacy.settings.nativeRemindersEnabled;
    const result = validateBackup(JSON.stringify(legacy));
    expect(result.data.settings.nativeRemindersEnabled).toBe(false);
    expect(result.data.vehicles).toEqual(legacy.vehicles);
    expect(result.metadata).toEqual({});
  });
  it("rejects broken references, future schema, malformed metadata and oversize files", () => {
    const s = demoSnapshot();
    s.expenses[0].vehicleId = "missing";
    expect(() => validateBackup(JSON.stringify(s))).toThrow();
    expect(() =>
      validateBackup(JSON.stringify({ ...demoSnapshot(), schemaVersion: 99 })),
    ).toThrow();
    expect(() =>
      validateBackup(
        JSON.stringify({ ...demoSnapshot(), exportedAt: "not-a-date" }),
      ),
    ).toThrow();
    expect(() => validateBackup("x".repeat(MAX_BACKUP_BYTES + 1))).toThrow(
      "5 MB",
    );
  });
});
