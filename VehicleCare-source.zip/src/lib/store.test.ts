import { beforeEach, describe, expect, it, vi } from "vitest";
import { useApp } from "./store";
import { demoSnapshot } from "./demo";
import { emptySnapshot, entrySchema, id, STORAGE_KEY, today } from "./model";
beforeEach(() => {
  localStorage.clear();
  useApp.setState({
    data: demoSnapshot(),
    raw: null,
    error: null,
    blocked: false,
    dirty: false,
    conflict: false,
  });
});
describe("record transactions and recovery", () => {
  it("preserves the previous snapshot if a valid replacement cannot be written", () => {
    useApp.getState().commit(() => {});
    const before = structuredClone(useApp.getState().data);
    const raw = localStorage.getItem(STORAGE_KEY);
    const spy = vi
      .spyOn(Storage.prototype, "setItem")
      .mockImplementation(() => {
        throw new DOMException("Quota full", "QuotaExceededError");
      });
    expect(useApp.getState().importData(demoSnapshot(), "replace")).toBe(false);
    expect(useApp.getState().data).toEqual(before);
    expect(localStorage.getItem(STORAGE_KEY)).toBe(raw);
    spy.mockRestore();
  });
  it("saves and updates a vehicle without disturbing another vehicle", () => {
    const first = useApp.getState().data.vehicles[0];
    const second = useApp.getState().data.vehicles[1];
    expect(
      useApp.getState().saveVehicle({ ...first, name: "Updated name" }),
    ).toBe(true);
    expect(useApp.getState().data.vehicles[1]).toEqual(second);
    expect(
      JSON.parse(localStorage.getItem(STORAGE_KEY)!).vehicles[0].name,
    ).toBe("Updated name");
  });
  it("requires a controlled odometer correction and refuses readings below history", () => {
    const v = useApp.getState().data.vehicles[1];
    expect(
      useApp.getState().saveVehicle({ ...v, odometer: v.odometer - 10 }),
    ).toBe(false);
    expect(
      useApp.getState().saveVehicle({ ...v, odometer: v.odometer - 10 }, true),
    ).toBe(false);
    const s = emptySnapshot();
    s.vehicles = [{ ...v, odometer: 7000 }];
    useApp.setState({ data: s });
    expect(useApp.getState().saveVehicle({ ...v, odometer: 6500 }, true)).toBe(
      true,
    );
  });
  it("completes maintenance and service in one persisted transaction", () => {
    const rule = useApp.getState().data.maintenanceRules[0];
    const v = useApp.getState().data.vehicles[0];
    const service = entrySchema.parse({
      id: id(),
      vehicleId: v.id,
      title: "Completed oil service",
      date: today(),
      odometer: v.odometer,
      tasks: "Oil and filter",
      maintenanceRuleId: rule.id,
      partsCost: 10000,
      labourCost: 5000,
    });
    expect(useApp.getState().saveEntry("services", service)).toBe(true);
    const saved = useApp.getState().data;
    expect(saved.revision).toBe(1);
    expect(saved.maintenanceRules[0].lastCompletedDate).toBe(service.date);
    expect(saved.maintenanceRules[0].lastCompletedOdometer).toBe(
      service.odometer,
    );
    expect(saved.services.at(-1)?.id).toBe(service.id);
  });
  it("unlinks costs when a trip is removed", () => {
    const trip = useApp.getState().data.trips[0];
    const before = useApp.getState().data.expenses.length;
    useApp.getState().removeEntry("trips", trip.id);
    expect(useApp.getState().data.expenses).toHaveLength(before);
    expect(
      useApp.getState().data.expenses.every((e) => e.tripId !== trip.id),
    ).toBe(true);
  });
  it("preserves existing data when an invalid backup fails", () => {
    const before = structuredClone(useApp.getState().data);
    const invalid = demoSnapshot();
    invalid.vehicles[0].year = 0;
    expect(useApp.getState().importData(invalid, "replace")).toBe(false);
    expect(useApp.getState().data).toEqual(before);
    expect(localStorage.getItem(STORAGE_KEY)).toBeNull();
  });
  it("does not merge demo records over corrupted originals", () => {
    localStorage.setItem(STORAGE_KEY, "{bad");
    useApp.setState({ blocked: true, raw: "{bad", data: emptySnapshot() });
    expect(useApp.getState().importData(demoSnapshot(), "merge")).toBe(false);
    expect(localStorage.getItem(STORAGE_KEY)).toBe("{bad");
  });
  it("recovers corrupted storage through an explicit validated replacement", () => {
    localStorage.setItem(STORAGE_KEY, "{bad");
    useApp.setState({ blocked: true, raw: "{bad", data: emptySnapshot() });
    expect(useApp.getState().importData(demoSnapshot(), "replace")).toBe(true);
    expect(useApp.getState().blocked).toBe(false);
    expect(useApp.getState().data.vehicles).toHaveLength(2);
  });
  it("keeps data in memory if storage is unavailable and allows retry", () => {
    useApp.setState({
      blocked: true,
      raw: null,
      data: emptySnapshot(),
      error: "Unavailable",
    });
    expect(useApp.getState().saveVehicle(demoSnapshot().vehicles[0])).toBe(
      true,
    );
    expect(useApp.getState().dirty).toBe(true);
    useApp.getState().retry();
    expect(useApp.getState().blocked).toBe(false);
    expect(useApp.getState().dirty).toBe(false);
    expect(localStorage.getItem(STORAGE_KEY)).not.toBeNull();
  });
  it("preserves existing memory when importing into unavailable storage", () => {
    const before = structuredClone(useApp.getState().data);
    useApp.setState({
      blocked: true,
      raw: null,
      dirty: true,
      error: "Unavailable",
    });
    const spy = vi
      .spyOn(Storage.prototype, "getItem")
      .mockImplementation(() => {
        throw new DOMException("Unavailable", "SecurityError");
      });
    expect(useApp.getState().importData(demoSnapshot(), "replace")).toBe(false);
    expect(useApp.getState().data).toEqual(before);
    expect(useApp.getState().error).toContain("existing data preserved");
    spy.mockRestore();
  });
  it("refuses a recovery import if the unreadable original changed after preview", () => {
    useApp.setState({ blocked: true, raw: "{original", data: emptySnapshot() });
    localStorage.setItem(STORAGE_KEY, "{different");
    expect(useApp.getState().importData(demoSnapshot(), "replace")).toBe(false);
    expect(localStorage.getItem(STORAGE_KEY)).toBe("{different");
    expect(useApp.getState().conflict).toBe(true);
  });
  it("detects competing revisions rather than silently overwriting", () => {
    useApp.getState().commit((s) => {
      s.vehicles[0].name = "Local name";
    });
    const current = useApp.getState().data;
    const incoming = { ...structuredClone(current), writerId: "other" };
    incoming.vehicles[0].name = "Remote name";
    useApp.getState().receive(JSON.stringify(incoming));
    expect(useApp.getState().conflict).toBe(true);
    expect(useApp.getState().data.vehicles[0].name).toBe("Local name");
  });
  it("detects a conflict on retry and keeps memory intact", () => {
    useApp.setState({ dirty: true });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(demoSnapshot()));
    useApp.getState().retry();
    expect(useApp.getState().conflict).toBe(true);
    expect(useApp.getState().dirty).toBe(true);
  });
  it("continues revision numbering when explicitly keeping local data", () => {
    const incoming = { ...demoSnapshot(), revision: 20, writerId: "other" };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(incoming));
    useApp.setState({ conflict: true, dirty: true });
    useApp.getState().resolve("local");
    expect(useApp.getState().data.revision).toBe(21);
    expect(useApp.getState().conflict).toBe(false);
  });
});
