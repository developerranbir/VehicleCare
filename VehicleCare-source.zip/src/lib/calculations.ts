import { addDays, differenceInCalendarDays, parseISO, format } from "date-fns";
import { type Entry, type Snapshot, type Vehicle, today } from "./model";
export function fuelEconomy(logs: Entry[]) {
  const sorted = [...logs].sort(
    (a, b) =>
      a.date.localeCompare(b.date) ||
      (a.odometer === undefined || b.odometer === undefined
        ? 0
        : a.odometer - b.odometer),
  );
  const results: {
    date: string;
    kmPerLitre: number;
    distance: number;
    litres: number;
  }[] = [];
  let baseline: Entry | undefined;
  let litres = 0;
  let previous: number | undefined;
  let invalid = false;
  for (const log of sorted) {
    if (baseline) litres += log.litres ?? 0;
    if (
      log.odometer === undefined ||
      (previous !== undefined && log.odometer <= previous)
    )
      invalid = true;
    if (log.fullTank) {
      if (
        baseline &&
        !invalid &&
        log.odometer !== undefined &&
        baseline.odometer !== undefined &&
        log.odometer > baseline.odometer &&
        litres > 0
      )
        results.push({
          date: log.date,
          kmPerLitre: (log.odometer - baseline.odometer) / litres,
          distance: log.odometer - baseline.odometer,
          litres,
        });
      baseline = log;
      litres = 0;
      invalid = log.odometer === undefined;
    }
    previous = log.odometer;
  }
  return results;
}
export function maintenanceStatus(rule: Entry, vehicle: Vehicle, on = today()) {
  const dueDate = rule.intervalDays
    ? format(
        addDays(
          parseISO(rule.lastCompletedDate ?? rule.baselineDate!),
          rule.intervalDays,
        ),
        "yyyy-MM-dd",
      )
    : undefined;
  const dueOdometer = rule.intervalKm
    ? (rule.lastCompletedOdometer ?? rule.baselineOdometer ?? 0) +
      rule.intervalKm
    : undefined;
  const daysLeft = dueDate
    ? differenceInCalendarDays(parseISO(dueDate), parseISO(on))
    : undefined;
  const kmLeft =
    dueOdometer !== undefined ? dueOdometer - vehicle.odometer : undefined;
  const overdue =
    (daysLeft !== undefined && daysLeft <= 0) ||
    (kmLeft !== undefined && kmLeft <= 0);
  const upcoming =
    (daysLeft !== undefined && daysLeft <= rule.warningDays) ||
    (kmLeft !== undefined && kmLeft <= rule.warningKm);
  return {
    dueDate,
    dueOdometer,
    daysLeft,
    kmLeft,
    status: overdue ? "Overdue" : upcoming ? "Upcoming" : "On track",
  };
}
export function renewalStatus(entry: Entry, on = today()) {
  const days = differenceInCalendarDays(parseISO(entry.dueDate!), parseISO(on));
  return {
    days,
    status:
      days < 0
        ? "Overdue"
        : days <= entry.warningDays
          ? "Upcoming"
          : "On track",
  };
}
export type LedgerItem = {
  id: string;
  vehicleId: string;
  title: string;
  date: string;
  amount: number;
  category: string;
  source: string;
  tripId: string;
};
export function ledger(s: Snapshot): LedgerItem[] {
  return [
    ...s.fuelLogs.map((e) => ({
      ...e,
      amount: e.cost,
      category: "Fuel",
      source: "fuelLogs",
    })),
    ...s.chargingLogs.map((e) => ({
      ...e,
      amount: e.cost,
      category: "Charging",
      source: "chargingLogs",
    })),
    ...s.services.map((e) => ({
      ...e,
      amount: e.partsCost + e.labourCost + e.miscCost,
      category: "Service",
      source: "services",
    })),
    ...s.expenses.map((e) => ({ ...e, amount: e.cost, source: "expenses" })),
  ].sort((a, b) => b.date.localeCompare(a.date));
}
export function odometerWarning(
  s: Snapshot,
  vehicleId: string,
  date: string,
  reading: number,
  excludeId = "",
): string | null {
  const entries = [
    ...s.fuelLogs,
    ...s.chargingLogs,
    ...s.services,
    ...s.trips.flatMap((t) => [
      { ...t, odometer: t.startOdometer },
      { ...t, odometer: t.endOdometer },
    ]),
  ].filter(
    (e) =>
      e.vehicleId === vehicleId &&
      e.id !== excludeId &&
      e.odometer !== undefined,
  );
  if (
    entries.some(
      (e) =>
        (e.date < date && e.odometer! > reading) ||
        (e.date > date && e.odometer! < reading),
    )
  )
    return "This reading conflicts with an earlier or later dated odometer. Correct the affected records first.";
  return null;
}
export function recordedDistance(
  s: Snapshot,
  vehicleId?: string,
): number | null {
  const vehicles = s.vehicles.filter((v) => !vehicleId || v.id === vehicleId);
  let total = 0;
  let found = false;
  for (const v of vehicles) {
    const readings = [...s.fuelLogs, ...s.chargingLogs, ...s.services]
      .filter((e) => e.vehicleId === v.id && e.odometer !== undefined)
      .map((e) => e.odometer!);
    for (const t of s.trips.filter((t) => t.vehicleId === v.id))
      readings.push(t.startOdometer!, t.endOdometer!);
    if (readings.length >= 2 && Math.max(...readings) > Math.min(...readings)) {
      found = true;
      total += Math.max(...readings) - Math.min(...readings);
    }
  }
  return found ? total : null;
}
export const kmToDisplay = (km: number, unit: "km" | "mi") =>
  unit === "mi" ? km / 1.609344 : km;
export const formatEfficiency = (
  kmPerLitre: number,
  settings: Snapshot["settings"],
  digits = 1,
) =>
  `${new Intl.NumberFormat(settings.language === "hi" ? "hi-IN" : "en-IN", { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(kmToDisplay(kmPerLitre, settings.distanceUnit))} ${settings.distanceUnit}/L`;
export const displayToKm = (value: number, unit: "km" | "mi") =>
  unit === "mi" ? value * 1.609344 : value;
export const formatMoney = (minor: number, s: Snapshot["settings"]) =>
  new Intl.NumberFormat(s.language === "hi" ? "hi-IN" : "en-IN", {
    style: "currency",
    currency: s.currency,
    maximumFractionDigits: 2,
  }).format(minor / 100);
export const formatDistance = (km: number, s: Snapshot["settings"]) =>
  `${new Intl.NumberFormat(s.language === "hi" ? "hi-IN" : "en-IN", { maximumFractionDigits: 1 }).format(kmToDisplay(km, s.distanceUnit))} ${s.distanceUnit}`;
export const formatDate = (date: string, s: Snapshot["settings"]) =>
  new Intl.DateTimeFormat(s.language === "hi" ? "hi-IN" : "en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(parseISO(date));
