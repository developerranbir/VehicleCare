import { describe, expect, it } from "vitest";
import {
  fuelEconomy,
  ledger,
  maintenanceStatus,
  odometerWarning,
  recordedDistance,
  displayToKm,
  kmToDisplay,
  renewalStatus,
} from "./calculations";
import {
  entrySchema,
  emptySnapshot,
  snapshotSchema,
  parseSnapshot,
  validateEntry,
  MAX_BACKUP_BYTES,
} from "./model";
import { demoSnapshot } from "./demo";
import { csvCell } from "./export";
const fuel = (
  odometer: number,
  litres: number,
  fullTank: boolean,
  date = "2026-01-01",
) =>
  entrySchema.parse({
    id: String(odometer),
    vehicleId: "v",
    title: "Fill",
    date,
    odometer,
    litres,
    fullTank,
  });
describe("fuel economy", () => {
  it("includes partial fills but excludes the baseline fill", () => {
    const result = fuelEconomy([
      fuel(1000, 40, true),
      fuel(1200, 10, false),
      fuel(1500, 30, true),
    ]);
    expect(result).toHaveLength(1);
    expect(result[0].kmPerLitre).toBe(12.5);
    expect(result[0].litres).toBe(40);
  });
  it("returns missing values for insufficient records", () =>
    expect(fuelEconomy([fuel(100, 20, true)])).toEqual([]));
  it("rejects inconsistent readings and recovers at a new full tank", () => {
    expect(
      fuelEconomy([
        fuel(1000, 40, true, "2026-01-01"),
        fuel(900, 10, false, "2026-01-02"),
        fuel(1500, 30, true, "2026-01-03"),
        fuel(2000, 40, true, "2026-01-04"),
      ]),
    ).toEqual([
      { date: "2026-01-04", kmPerLitre: 12.5, distance: 500, litres: 40 },
    ]);
  });
  it("never substitutes a missing odometer", () => {
    const missing = { ...fuel(1200, 10, false), odometer: undefined };
    expect(
      fuelEconomy([fuel(1000, 30, true), missing, fuel(1500, 30, true)]),
    ).toEqual([]);
  });
});
describe("maintenance rules", () => {
  const vehicle = { ...demoSnapshot().vehicles[0], odometer: 1500 };
  const rule = entrySchema.parse({
    id: "r",
    vehicleId: vehicle.id,
    title: "Oil",
    date: "2026-01-01",
    baselineDate: "2026-01-01",
    baselineOdometer: 1000,
    intervalDays: 30,
    intervalKm: 1000,
    warningDays: 5,
    warningKm: 100,
  });
  it("calculates independent due conditions", () => {
    const status = maintenanceStatus(rule, vehicle, "2026-01-28");
    expect(status.dueDate).toBe("2026-01-31");
    expect(status.dueOdometer).toBe(2000);
    expect(status.status).toBe("Upcoming");
  });
  it("is due if either interval is reached", () => {
    expect(
      maintenanceStatus(rule, { ...vehicle, odometer: 2000 }, "2026-01-02")
        .status,
    ).toBe("Overdue");
    expect(maintenanceStatus(rule, vehicle, "2026-01-31").status).toBe(
      "Overdue",
    );
  });
  it("resets both intervals after completion", () => {
    const next = maintenanceStatus(
      { ...rule, lastCompletedDate: "2026-02-01", lastCompletedOdometer: 2100 },
      vehicle,
      "2026-02-02",
    );
    expect(next.dueDate).toBe("2026-03-03");
    expect(next.dueOdometer).toBe(3100);
    expect(next.status).toBe("On track");
  });
  it("supports only a distance condition", () => {
    expect(
      maintenanceStatus(
        { ...rule, intervalDays: undefined },
        vehicle,
        "2027-01-01",
      ).status,
    ).toBe("On track");
  });
  it("rejects rules without baselines or intervals", () => {
    expect(() =>
      validateEntry("maintenanceRules", {
        ...rule,
        baselineOdometer: undefined,
      }),
    ).toThrow("baselineOdometer");
    expect(() =>
      validateEntry("maintenanceRules", {
        ...rule,
        intervalDays: undefined,
        intervalKm: undefined,
      }),
    ).toThrow("interval");
  });
});
describe("ledger and references", () => {
  it("rejects imported odometers that conflict with chronological history or current readings", () => {
    const s = demoSnapshot();
    s.vehicles[0].odometer = 1;
    expect(snapshotSchema.safeParse(s).success).toBe(false);
    const other = demoSnapshot();
    other.fuelLogs[2].odometer = 1;
    expect(snapshotSchema.safeParse(other).success).toBe(false);
  });
  it("aggregates each original cost exactly once including linked trips", () => {
    const s = demoSnapshot();
    const expected =
      s.fuelLogs.reduce((n, e) => n + e.cost, 0) +
      s.chargingLogs.reduce((n, e) => n + e.cost, 0) +
      s.services.reduce(
        (n, e) => n + e.partsCost + e.labourCost + e.miscCost,
        0,
      ) +
      s.expenses.reduce((n, e) => n + e.cost, 0);
    expect(ledger(s).reduce((n, e) => n + e.amount, 0)).toBe(expected);
    expect(ledger(s)).toHaveLength(
      s.fuelLogs.length +
        s.chargingLogs.length +
        s.services.length +
        s.expenses.length,
    );
  });
  it("keeps independent vehicles separate", () => {
    const s = demoSnapshot();
    expect(
      ledger(s)
        .filter((e) => e.vehicleId === s.vehicles[0].id)
        .every((e) => e.vehicleId !== s.vehicles[1].id),
    ).toBe(true);
  });
  it("validates references and rejects duplicate IDs", () => {
    const s = demoSnapshot();
    s.fuelLogs[0].vehicleId = "missing";
    expect(snapshotSchema.safeParse(s).success).toBe(false);
    const other = demoSnapshot();
    other.vehicles[1].id = other.vehicles[0].id;
    expect(snapshotSchema.safeParse(other).success).toBe(false);
  });
  it("rejects cross-vehicle trip links and schedule links", () => {
    const s = demoSnapshot();
    s.chargingLogs[0].tripId = s.trips[0].id;
    expect(snapshotSchema.safeParse(s).success).toBe(false);
    const other = demoSnapshot();
    other.services[1].maintenanceRuleId = other.maintenanceRules[0].id;
    expect(snapshotSchema.safeParse(other).success).toBe(false);
  });
  it("detects chronological odometer inconsistencies", () => {
    const s = demoSnapshot();
    const v = s.vehicles[0];
    expect(odometerWarning(s, v.id, s.fuelLogs[2].date, 100)).toContain(
      "conflicts",
    );
    expect(odometerWarning(s, v.id, "2099-01-01", v.odometer + 10)).toBeNull();
  });
  it("returns unavailable rather than a fictitious recorded distance", () =>
    expect(recordedDistance(emptySnapshot())).toBeNull());
  it("stores km independently from the selected display unit", () => {
    expect(displayToKm(100, "mi")).toBeCloseTo(160.9344);
    expect(kmToDisplay(160.9344, "mi")).toBeCloseTo(100);
  });
  it("rejects impossible dates, money fractions, and oversized imports", () => {
    const s = demoSnapshot();
    s.fuelLogs[0].date = "2026-02-30";
    expect(snapshotSchema.safeParse(s).success).toBe(false);
    expect(() => parseSnapshot(" ".repeat(MAX_BACKUP_BYTES + 1))).toThrow(
      "5 MB",
    );
    expect(() =>
      validateEntry("expenses", { ...s.expenses[0], cost: 1.2 }),
    ).toThrow();
  });
  it("supports explicit version migration and rejects future versions", () => {
    const s = emptySnapshot();
    expect(
      parseSnapshot(JSON.stringify({ ...s, schemaVersion: 0 })).schemaVersion,
    ).toBe(1);
    expect(() =>
      parseSnapshot(JSON.stringify({ ...s, schemaVersion: 2 })),
    ).toThrow();
  });
  it("round-trips backup data including history and preferences", () => {
    const s = demoSnapshot();
    s.settings.language = "hi";
    expect(parseSnapshot(JSON.stringify(s))).toEqual(s);
  });
  it("escapes spreadsheet formulas and quotes", () => {
    expect(csvCell("=SUM(A1)")).toBe('"\'=SUM(A1)"');
    expect(csvCell(" @formula")).toBe('"\' @formula"');
    expect(csvCell('a"b')).toBe('"a""b"');
  });
  it("flags expiration on the correct calendar dates", () => {
    const e = entrySchema.parse({
      id: "x",
      vehicleId: "v",
      title: "Insurance",
      date: "2026-01-01",
      dueDate: "2026-02-01",
      warningDays: 7,
    });
    expect(renewalStatus(e, "2026-02-02").status).toBe("Overdue");
    expect(renewalStatus(e, "2026-01-29").status).toBe("Upcoming");
  });
});
