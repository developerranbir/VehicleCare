// English phrases are lookup keys; values entered by users are never translated.
export const hindiPhrases: Record<string, string> = {
  Confirm: "पुष्टि करें",
  "Delete everything": "सब कुछ मिटाएँ",
  "Change currency": "मुद्रा बदलें",
  "Erase all vehicles and records?": "सभी वाहन और रिकॉर्ड मिटाएँ?",
  "Reinterpret amounts in another currency?":
    "राशियों को दूसरी मुद्रा में दिखाएँ?",
  "Add an example garage?": "उदाहरण गैराज जोड़ें?",
  "This clears the complete snapshot, including emergency contacts and settings. Download a backup first.":
    "इससे आपातकालीन संपर्क और सेटिंग्स सहित पूरा डेटा मिट जाएगा। पहले बैकअप डाउनलोड करें।",
  "VehicleCare does not fetch exchange rates or convert money. Existing numeric amounts will be displayed in the selected currency.":
    "VehicleCare विनिमय दर नहीं लेता और राशि परिवर्तित नहीं करता। मौजूदा संख्याएँ चुनी गई मुद्रा में दिखाई देंगी।",
  "Two example vehicles and their care records will be added alongside your existing data.":
    "आपके मौजूदा डेटा के साथ दो उदाहरण वाहन और देखभाल रिकॉर्ड जुड़ेंगे।",
  "Replace all existing data?": "सभी मौजूदा डेटा बदलें?",
  "Merge these records?": "ये रिकॉर्ड मिलाएँ?",
  "Replace data": "डेटा बदलें",
  "Merge data": "डेटा मिलाएँ",
  "This replaces the complete local snapshot. Download your current backup before continuing.":
    "इससे पूरा स्थानीय डेटा बदल जाएगा। आगे बढ़ने से पहले वर्तमान बैकअप डाउनलोड करें।",
  "Incoming records will be added and colliding IDs remapped. Current settings remain in place.":
    "नए रिकॉर्ड जुड़ेंगे और एक जैसे ID बदले जाएँगे। वर्तमान सेटिंग्स बनी रहेंगी।",
  "Bring this vehicle back?": "इस वाहन को वापस लाएँ?",
  "Archive this vehicle?": "इस वाहन को संग्रहित करें?",
  "No matching records": "कोई मिलते हुए रिकॉर्ड नहीं",
  "Add your first fill-up. Efficiency appears after two consistent full-tank readings.":
    "पहला ईंधन रिकॉर्ड जोड़ें। दो संगत पूरे टैंक रिकॉर्ड के बाद दक्षता दिखाई देगी।",
  "Each point represents measured full-tank intervals. Different vehicles are shown separately.":
    "हर बिंदु मापे गए पूरे टैंक अंतराल दर्शाता है। अलग वाहनों के आँकड़े अलग दिखते हैं।",
  "Latest 12 measured intervals": "हाल के 12 मापे गए अंतराल",
  "Latest 20 service records. View the full history in Service history.":
    "हाल के 20 सर्विस रिकॉर्ड। पूरा विवरण सर्विस इतिहास में देखें।",
  "Show more records": "और रिकॉर्ड दिखाएँ",
  Showing: "दिखाए जा रहे",
  "Renewal history": "नवीनीकरण इतिहास",
  "Previous expiry": "पिछली समाप्ति",
  "Last checked": "पिछली जाँच",
  "(all time)": "(सभी समय)",
  "100% local. No account needed.": "पूरी तरह स्थानीय। खाते की ज़रूरत नहीं।",
  "A LITTLE CARE GOES A LONG WAY": "थोड़ी देखभाल से सफर बेहतर होता है",
  "A browser is not a guaranteed backup.":
    "ब्राउज़र में डेटा रहना सुरक्षित बैकअप की गारंटी नहीं है।",
  "A clear picture of your vehicle’s care.":
    "आपके वाहन की देखभाल का स्पष्ट विवरण।",
  "A few details to get you started": "शुरू करने के लिए कुछ जानकारी",
  "A heads-up for what’s next": "आने वाली ज़रूरतों की सूचना",
  "A home for every vehicle, and everything that keeps it running.":
    "हर वाहन और उसकी देखभाल के लिए एक जगह।",
  "A little attention goes a long way.": "थोड़ा ध्यान, बेहतर देखभाल।",
  "A non-zero renewal cost creates one independent expense. History is retained without adding a second ledger entry.":
    "नवीनीकरण का खर्च एक अलग व्यय बनता है। इतिहास सुरक्षित रहता है और दोहरा खर्च नहीं जुड़ता।",
  "A saved service resets both the date and distance intervals.":
    "सहेजी गई सर्विस से तारीख और दूरी, दोनों अंतराल दोबारा शुरू होते हैं।",
  Add: "जोड़ें",
  Edit: "बदलें",
  "Fuel entry": "ईंधन रिकॉर्ड",
  "Charging session": "चार्जिंग सत्र",
  "Service record": "सर्विस रिकॉर्ड",
  "Maintenance schedule": "रखरखाव योजना",
  Expense: "खर्च",
  Renewal: "नवीनीकरण",
  Trip: "यात्रा",
  "Inspection item": "जाँच का बिंदु",
  "Add a fuel, charging, service, or expense record to see monthly costs.":
    "मासिक खर्च देखने के लिए ईंधन, चार्जिंग, सर्विस या व्यय रिकॉर्ड जोड़ें।",
  "Add contact": "संपर्क जोड़ें",
  "Add demo data": "डेमो डेटा जोड़ें",
  "Add my first vehicle": "मेरा पहला वाहन जोड़ें",
  "Add or restore a vehicle to create records.":
    "रिकॉर्ड बनाने के लिए वाहन जोड़ें या वापस लाएँ।",
  After: "इसके बाद",
  "After the first complete online visit, cached screens and local data work offline.":
    "पहली पूरी ऑनलाइन यात्रा के बाद सहेजी गई स्क्रीन और स्थानीय डेटा ऑफलाइन काम करते हैं।",
  "All records stay available. You can restore an archived vehicle at any time.":
    "सभी रिकॉर्ड उपलब्ध रहते हैं। संग्रहित वाहन को कभी भी वापस ला सकते हैं।",
  "All spending ledger": "सभी खर्चों का लेखा",
  "All vehicles, records, settings, contacts, and renewal history in a validated JSON file.":
    "सभी वाहन, रिकॉर्ड, सेटिंग्स, संपर्क और नवीनीकरण इतिहास एक मान्य JSON फ़ाइल में।",
  "Already have a backup? Import it": "बैकअप मौजूद है? उसे आयात करें",
  "Archived vehicles keep all their records and can be restored anytime.":
    "संग्रहित वाहनों के सभी रिकॉर्ड सुरक्षित रहते हैं और उन्हें कभी भी वापस ला सकते हैं।",
  "Assess your surroundings.": "आसपास की स्थिति देखें।",
  "Avoid opening hot components or touching damaged electrical systems.":
    "गर्म पुर्जे न खोलें और क्षतिग्रस्त विद्युत प्रणाली को न छुएँ।",
  "Back to garage": "गैराज पर वापस जाएँ",
  "Back to overview": "सारांश पर वापस जाएँ",
  "Back up my data": "मेरा डेटा बैकअप करें",
  "Backup & recovery": "बैकअप और डेटा बहाली",
  "Basic breakdown checklist": "खराबी की सामान्य जाँच सूची",
  "Breakdown notes": "खराबी संबंधी नोट्स",
  Call: "कॉल करें",
  "Call for suitable help.": "उपयुक्त सहायता बुलाएँ।",
  Cancel: "रद्द करें",
  "Canonical distance": "संग्रहित दूरी की इकाई",
  "Care for your vehicle. Keep your data yours.":
    "वाहन की देखभाल करें। डेटा अपने पास रखें।",
  "Category distribution": "श्रेणी के अनुसार खर्च",
  "Checklists are manual inspections, and app-open reminders do not guarantee scheduled notifications while the app is closed. VehicleCare does not provide mechanical diagnoses or safety guarantees.":
    "जाँच सूची मैन्युअल निरीक्षण के लिए है। ऐप बंद होने पर तय समय की सूचना की गारंटी नहीं है। VehicleCare यांत्रिक निदान या सुरक्षा की गारंटी नहीं देता।",
  "Choose a JSON backup": "JSON बैकअप चुनें",
  "Choose a VehicleCare JSON file. We’ll check it before changing anything.":
    "VehicleCare की JSON फ़ाइल चुनें। डेटा बदलने से पहले इसकी जाँच होगी।",
  "Clearing site data, private browsing, storage limits, changing browsers, or losing this device can remove your records. Back up regularly and keep files private on shared devices.":
    "साइट डेटा मिटाने, निजी ब्राउज़िंग, स्टोरेज सीमा, ब्राउज़र बदलने या डिवाइस खोने से रिकॉर्ड हट सकते हैं। नियमित बैकअप लें और साझा डिवाइस पर फ़ाइलें निजी रखें।",
  Close: "बंद करें",
  Complete: "पूरा करें",
  "Complete maintenance & record service": "रखरखाव पूरा करके सर्विस सहेजें",
  "Confirm backup import": "बैकअप आयात की पुष्टि करें",
  "Confirm correction": "सुधार की पुष्टि करें",
  "Confirm odometer correction": "ओडोमीटर सुधार की पुष्टि करें",
  "Contact name": "संपर्क का नाम",
  "Cost (": "खर्च (",
  "Cost per distance uses all recorded costs and the span between recorded odometers for each vehicle. It is an incomplete ownership estimate, not a fuel-consumption measurement.":
    "प्रति दूरी खर्च सभी दर्ज खर्चों और वाहन के ओडोमीटर रिकॉर्ड के अंतर से निकलता है। यह स्वामित्व खर्च का अधूरा अनुमान है, ईंधन खपत का माप नहीं।",
  "Data controls": "डेटा नियंत्रण",
  "Default vehicle": "डिफ़ॉल्ट वाहन",
  "Defaults for new schedules. Existing schedules keep their own thresholds.":
    "नई योजनाओं के लिए डिफ़ॉल्ट सीमाएँ। पुरानी योजनाओं की सीमाएँ बनी रहती हैं।",
  "Delete all data": "सभी डेटा मिटाएँ",
  "Delete contact": "संपर्क हटाएँ",
  "Delete emergency contact": "आपातकालीन संपर्क हटाएँ",
  "Delete record": "रिकॉर्ड हटाएँ",
  "Demo data is merged with your records. It never overwrites your real vehicles.":
    "डेमो डेटा आपके रिकॉर्ड में जुड़ता है। आपके वास्तविक वाहन बदले नहीं जाते।",
  "Describe the issue and any visible hazards. Follow instructions from qualified assistance personnel.":
    "समस्या और दिख रहे खतरों का वर्णन करें। योग्य सहायता कर्मियों के निर्देश मानें।",
  "Dismiss install message": "इंस्टॉल संदेश बंद करें",
  "Dismiss update notice": "अपडेट सूचना बंद करें",
  "Download JSON backup": "JSON बैकअप डाउनलोड करें",
  "Download calendar event": "कैलेंडर घटना डाउनलोड करें",
  "Download original unreadable data": "मूल अपठनीय डेटा डाउनलोड करें",
  "Efficiency needs two full tanks. Intermediate partial fills are included.":
    "दक्षता के लिए दो पूरे टैंक रिकॉर्ड चाहिए। बीच में भरा गया आंशिक ईंधन भी शामिल होता है।",
  "Emergency contacts": "आपातकालीन संपर्क",
  "Energy purchased does not necessarily equal energy consumed while driving.":
    "खरीदी गई ऊर्जा और चलाते समय खर्च हुई ऊर्जा आवश्यक रूप से बराबर नहीं हैं।",
  "Every service. Every journey.": "हर सर्विस। हर सफर।",
  Expires: "समाप्ति",
  "Export a complete backup": "पूरा बैकअप निर्यात करें",
  "Export full ledger": "पूरा लेखा निर्यात करें",
  "Export spending CSV": "खर्च की CSV निर्यात करें",
  "Filter by vehicle": "वाहन के अनुसार छाँटें",
  "From date": "शुरू की तारीख",
  "Fuel economy uses consistent full-tank intervals and includes intermediate partial fills. Charging figures describe purchased energy, not driving consumption. Reports summarize recorded costs and may not represent your complete ownership cost.":
    "ईंधन दक्षता पूरे टैंक के संगत अंतराल से निकलती है और आंशिक भराव शामिल करती है। चार्जिंग आँकड़े खरीदी गई ऊर्जा बताते हैं, चलाने की खपत नहीं। रिपोर्ट दर्ज खर्चों का सार है, पूरे स्वामित्व खर्च का नहीं।",
  "Fuel efficiency": "ईंधन दक्षता",
  "Fuel, charging, service, and expense entries appear here.":
    "ईंधन, चार्जिंग, सर्विस और खर्च के रिकॉर्ड यहाँ दिखाई देंगे।",
  "Full tank": "पूरा टैंक",
  "Give your vehicle a place in your garage. You can update these details anytime.":
    "वाहन को अपने गैराज में जोड़ें। ये विवरण कभी भी बदल सकते हैं।",
  "Got it": "समझ गया",
  "Honest records, useful insight": "सटीक रिकॉर्ड, उपयोगी जानकारी",
  "If there is immediate danger, contact your local emergency services. This basic checklist does not replace professional assistance or guarantee safety.":
    "तत्काल खतरा होने पर स्थानीय आपातकालीन सेवाओं से संपर्क करें। यह सामान्य सूची पेशेवर सहायता का विकल्प या सुरक्षा की गारंटी नहीं है।",
  Import: "आयात करें",
  "Import preview": "आयात की समीक्षा",
  "Independent expenses": "अलग खर्च",
  "Install VehicleCare": "VehicleCare इंस्टॉल करें",
  "Install app": "ऐप इंस्टॉल करें",
  "I’ll add a vehicle later": "वाहन बाद में जोड़ूँगा",
  "Keep a backup": "बैकअप रखें",
  "Keep backups. Clearing browser data can remove your records.":
    "बैकअप रखें। ब्राउज़र डेटा मिटाने से रिकॉर्ड हट सकते हैं।",
  "Keep existing settings and records. Colliding IDs are remapped, including linked records. Importing the same backup twice adds two copies.":
    "मौजूदा सेटिंग्स और रिकॉर्ड रखें। एक जैसे ID और जुड़े रिकॉर्ड के ID बदले जाते हैं। एक बैकअप दो बार आयात करने पर दो प्रतियाँ जुड़ेंगी।",
  "Keep help close": "मदद पास रखें",
  "Keep this snapshot": "यह डेटा रखें",
  "Keep yourself and passengers away from moving traffic. Do not attempt repairs in an unsafe location.":
    "खुद को और यात्रियों को चल रहे ट्रैफ़िक से दूर रखें। असुरक्षित जगह पर मरम्मत न करें।",
  Kilometres: "किलोमीटर",
  "Kilometres (": "किलोमीटर (",
  "Kilometres (km)": "किलोमीटर (km)",
  "Last 6 months": "पिछले 6 महीने",
  "Less worry. More open roads.": "कम चिंता। बेहतर सफर।",
  "Let’s make it yours": "अपनी पसंद चुनें",
  "Load other tab": "दूसरे टैब का डेटा लें",
  "Loading your workspace…": "आपका कार्यक्षेत्र खुल रहा है…",
  "Local & private": "स्थानीय और निजी",
  "Made for a calmer journey": "बेहतर सफर के लिए बनाया गया",
  "Main navigation": "मुख्य नेविगेशन",
  "Maintenance reminders": "रखरखाव की सूचनाएँ",
  "Make VehicleCare feel like yours, and keep your data in your hands.":
    "VehicleCare को अपनी पसंद के अनुसार बनाएँ और डेटा अपने पास रखें।",
  "Make room for your next journey": "अपने अगले सफर के लिए जगह बनाएँ",
  "Manual inspection notes are not a mechanical diagnosis.":
    "मैन्युअल जाँच के नोट्स यांत्रिक निदान नहीं हैं।",
  "Merge into my garage": "मेरे गैराज में मिलाएँ",
  Miles: "मील",
  "Miles (mi)": "मील (mi)",
  "Mobile navigation": "मोबाइल नेविगेशन",
  "Monthly costs": "मासिक खर्च",
  More: "और",
  "More fill-ups, better insight": "अधिक रिकॉर्ड, बेहतर जानकारी",
  "Move out of traffic if it is safe.": "सुरक्षित हो तो ट्रैफ़िक से बाहर जाएँ।",
  "My garage": "मेरा गैराज",
  "New expiry date": "नई समाप्ति तारीख",
  "No account, backend, tracking, or vehicle-data upload. All business records live in this browser’s localStorage. Offline caching stores application assets only. Export backups regularly: clearing site data, private browsing, or losing your device can remove records.":
    "कोई खाता, बैकएंड, ट्रैकिंग या वाहन डेटा अपलोड नहीं है। रिकॉर्ड इस ब्राउज़र के localStorage में हैं। ऑफलाइन कैश में केवल ऐप की फ़ाइलें रहती हैं। नियमित बैकअप लें: साइट डेटा मिटाने, निजी ब्राउज़िंग या डिवाइस खोने से रिकॉर्ड हट सकते हैं।",
  "No archived vehicles": "कोई संग्रहित वाहन नहीं",
  "No cloud. No worries.": "क्लाउड के बिना। डेटा आपके पास।",
  "No service history yet": "अभी कोई सर्विस रिकॉर्ड नहीं",
  "No spending to compare": "तुलना के लिए खर्च नहीं",
  "No upcoming alerts. Add care schedules and expiry dates to see reminders here.":
    "अभी कोई आगामी सूचना नहीं है। सूचनाओं के लिए रखरखाव योजनाएँ और समाप्ति तारीखें जोड़ें।",
  "Nothing to compare yet": "अभी तुलना के लिए डेटा नहीं",
  "On the horizon": "आने वाली ज़रूरतें",
  "Only correct a mistaken reading. A value below a recorded fuel, service, charging, or trip reading will be rejected.":
    "केवल गलत रीडिंग सुधारें। दर्ज ईंधन, सर्विस, चार्जिंग या यात्रा रीडिंग से कम मान स्वीकार नहीं होगा।",
  "Only record independent costs here. Fuel, charging, and service logs already contribute to spending.":
    "यहाँ केवल अलग खर्च दर्ज करें। ईंधन, चार्जिंग और सर्विस रिकॉर्ड के खर्च पहले से शामिल हैं।",
  "Open navigation": "नेविगेशन खोलें",
  "Ownership details": "स्वामित्व विवरण",
  "Partial fill": "आंशिक भराव",
  Persistence: "डेटा संग्रहण",
  "Phone number": "फ़ोन नंबर",
  "Policy numbers, assistance details, or directions someone may need.":
    "पॉलिसी नंबर, सहायता विवरण या ज़रूरी निर्देश।",
  Preferences: "पसंद",
  "Private by design": "निजता को ध्यान में रखकर बनाया गया",
  "Private by design. Your garage lives in this browser.":
    "आपका निजी गैराज इसी ब्राउज़र में रहता है।",
  "Private, local, offline": "निजी, स्थानीय, ऑफलाइन",
  "Purchase price": "खरीद मूल्य",
  "Ready wherever life takes you": "हर सफर में आपके साथ",
  "Record costs for your vehicles to compare them.":
    "वाहनों की तुलना के लिए उनके खर्च दर्ज करें।",
  "Record renewal": "नवीनीकरण दर्ज करें",
  "Record two full tanks with consistent odometers. Partial fills between them are included.":
    "संगत ओडोमीटर के साथ दो पूरे टैंक दर्ज करें। बीच के आंशिक भराव शामिल होंगे।",
  "Recorded cost /": "दर्ज खर्च /",
  "Recorded entries": "दर्ज रिकॉर्ड",
  "Recorded spending": "दर्ज खर्च",
  "Recorded spending by vehicle": "वाहन के अनुसार दर्ज खर्च",
  "Recorded spending over the last six months": "पिछले छह महीनों के दर्ज खर्च",
  "Reduce the current reading?": "वर्तमान रीडिंग घटाएँ?",
  "Reminders appear while the app is open. VehicleCare does not send scheduled push notifications when closed.":
    "ऐप खुला होने पर सूचनाएँ दिखती हैं। बंद होने पर VehicleCare तय समय की पुश सूचना नहीं भेजता।",
  "Remove this saved contact?": "यह सहेजा गया संपर्क हटाएँ?",
  Renew: "नवीनीकरण करें",
  "Replace all local data": "सभी स्थानीय डेटा बदलें",
  "Reset dates": "तारीखें रीसेट करें",
  "Restore from a backup": "बैकअप से बहाल करें",
  "Retry saving": "फिर सहेजें",
  "Return to your garage to choose a vehicle.":
    "वाहन चुनने के लिए गैराज पर वापस जाएँ।",
  Revision: "संशोधन",
  "Room to enjoy the journey": "सफर का आनंद लें",
  "Save a family member, insurer, or roadside-assistance contact.":
    "परिवार, बीमा कंपनी या सड़क सहायता का संपर्क सहेजें।",
  "Save notes": "नोट्स सहेजें",
  "Save renewal": "नवीनीकरण सहेजें",
  "Save thresholds": "सीमाएँ सहेजें",
  Saved: "सहेजा गया",
  "Saved locally, available offline. A regular backup keeps you in control.":
    "स्थानीय रूप से सहेजा गया, ऑफलाइन उपलब्ध। नियमित बैकअप से डेटा आपके नियंत्रण में रहता है।",
  "Select…": "चुनें…",
  "Service cost history": "सर्विस खर्च का इतिहास",
  "Share your location and vehicle details.": "अपना स्थान और वाहन विवरण बताएँ।",
  "Skip to content": "सीधे मुख्य सामग्री पर जाएँ",
  "Snapshot size": "डेटा का आकार",
  "Spending by category": "श्रेणी के अनुसार खर्च",
  "Spending overview": "खर्च का सारांश",
  Status: "स्थिति",
  "Stop in a safe location and switch on hazard lights. Follow local road rules.":
    "सुरक्षित जगह पर रुकें और हैज़र्ड लाइट चालू करें। स्थानीय सड़क नियम मानें।",
  "Storage & backup": "स्टोरेज और बैकअप",
  "Storage capacity is browser-dependent. Export backups regularly.":
    "स्टोरेज क्षमता ब्राउज़र पर निर्भर है। नियमित बैकअप निर्यात करें।",
  "That road doesn’t lead anywhere": "यह पृष्ठ नहीं मिला",
  "The bigger picture, one month at a time": "हर महीने का पूरा विवरण",
  "The latest in your vehicle’s story": "आपके वाहन की हाल की गतिविधियाँ",
  "The people and information you need, available on this device even offline.":
    "ज़रूरी संपर्क और जानकारी इस डिवाइस पर ऑफलाइन भी उपलब्ध हैं।",
  "These figures describe energy charged and charging expenditure. Purchased energy is not a measurement of driving consumption.":
    "ये आँकड़े चार्ज की गई ऊर्जा और खर्च बताते हैं। खरीदी गई ऊर्जा चलाने की खपत का माप नहीं है।",
  "This page couldn’t be found. Your garage is still here.":
    "यह पृष्ठ नहीं मिला। आपका गैराज उपलब्ध है।",
  "This removes the record from this browser. Export a backup first if you might need it later.":
    "रिकॉर्ड इस ब्राउज़र से हट जाएगा। बाद में ज़रूरत हो सकती है तो पहले बैकअप लें।",
  "This vehicle may have been removed by an imported backup.":
    "बैकअप आयात करते समय यह वाहन हट गया हो सकता है।",
  "To date": "अंतिम तारीख",
  "Total recorded expenses": "कुल दर्ज खर्च",
  Transactions: "लेन-देन",
  "Try a populated garage, or start fresh. These actions ask for confirmation.":
    "डेमो गैराज देखें या नए सिरे से शुरू करें। इन कार्यों के लिए पुष्टि ज़रूरी है।",
  "Understand the costs and care behind every journey.":
    "हर सफर के खर्च और देखभाल को समझें।",
  "Up to 5 MB ·": "5 MB तक ·",
  Update: "अपडेट करें",
  "Use the backup’s vehicles, records, and preferences. Existing records are removed.":
    "बैकअप के वाहन, रिकॉर्ड और पसंद अपनाएँ। मौजूदा रिकॉर्ड हट जाएँगे।",
  "Use your browser’s Install app menu. On iPhone or iPad, open in Safari and choose Share → Add to Home Screen. Installation requires a secure HTTPS site or localhost.":
    "ब्राउज़र के ऐप इंस्टॉल विकल्प का उपयोग करें। iPhone या iPad पर Safari में Share → Add to Home Screen चुनें। इंस्टॉल करने के लिए HTTPS या localhost ज़रूरी है।",
  "Use your saved assistance contact, insurer, or local emergency services as appropriate.":
    "स्थिति के अनुसार सहेजे गए सहायता संपर्क, बीमा कंपनी या स्थानीय आपातकालीन सेवा से संपर्क करें।",
  "Vehicle activity": "वाहन की गतिविधि",
  "Vehicle comparison": "वाहनों की तुलना",
  "Vehicle details": "वाहन विवरण",
  "Vehicle not found": "वाहन नहीं मिला",
  "VehicleCare brings your garage, fuel and charging records, service history, maintenance plans, trips, checks, renewals, and spending together in one private workspace.":
    "VehicleCare आपके गैराज, ईंधन, चार्जिंग, सर्विस, रखरखाव, यात्रा, जाँच, नवीनीकरण और खर्च को एक निजी कार्यक्षेत्र में रखता है।",
  "VehicleCare vehicle illustration": "VehicleCare वाहन चित्र",
  "VehicleCare · Your Vehicle. Your Care.":
    "VehicleCare · आपका वाहन। आपकी देखभाल।",
  "Vehicles / records": "वाहन / रिकॉर्ड",
  "Version 1.0.0 · Built with free, open-source tools.":
    "संस्करण 1.0.0 · मुक्त, ओपन-सोर्स साधनों से बनाया गया।",
  "View ledger ↗": "लेखा देखें ↗",
  "View maintenance planner": "रखरखाव योजना देखें",
  WORKSPACE: "कार्यक्षेत्र",
  "Wait for qualified help when unsure, especially with high-voltage electric-vehicle components.":
    "संदेह होने पर योग्य मदद की प्रतीक्षा करें, विशेषकर इलेक्ट्रिक वाहन के उच्च-वोल्टेज पुर्जों के लिए।",
  "Where it goes": "खर्च कहाँ होता है",
  "Works offline": "ऑफलाइन काम करता है",
  Workspace: "कार्यक्षेत्र",
  "YOUR VEHICLE. YOUR CARE.": "आपका वाहन। आपकी देखभाल।",
  "You can add the contact again later.":
    "संपर्क बाद में दोबारा जोड़ सकते हैं।",
  "Your Vehicle. Your Care.": "आपका वाहन। आपकी देखभाल।",
  "Your browser stores your records. A backup makes them portable.":
    "ब्राउज़र आपके रिकॉर्ड रखता है। बैकअप से उन्हें दूसरे डिवाइस पर ले जा सकते हैं।",
  "Your categories appear when costs are recorded.":
    "खर्च दर्ज करने पर श्रेणियाँ दिखेंगी।",
  "Your completed service records will appear here.":
    "पूरी की गई सर्विस के रिकॉर्ड यहाँ दिखाई देंगे।",
  "Your data": "आपका डेटा",
  "Your data. Your device.": "आपका डेटा। आपका डिवाइस।",
  "Your fuel, charging, service, and independent expense costs will appear here.":
    "ईंधन, चार्जिंग, सर्विस और अलग खर्च यहाँ दिखेंगे।",
  "Your notes": "आपके नोट्स",
  "Your spending activity will appear as you add records.":
    "रिकॉर्ड जोड़ने पर खर्च की गतिविधि दिखाई देगी।",
  "Your spending by category": "श्रेणी के अनुसार आपका खर्च",
  "Your spending story starts here": "खर्च का हिसाब यहाँ शुरू होता है",
  "Your workspace": "आपका कार्यक्षेत्र",
  "past renewals": "पिछले नवीनीकरण",
  records: "रिकॉर्ड",
  "records passed validation. Created": "रिकॉर्ड मान्य हैं। बनाए गए",
  "total records.": "कुल रिकॉर्ड।",
  vehicles: "वाहन",
  "vehicles and": "वाहन और",
  "· Linked expenses:": "· जुड़े खर्च:",
  "Every fill-up, with full-tank-to-full-tank efficiency.":
    "हर भराव और पूरे टैंक के अंतराल से ईंधन दक्षता।",
  "Track energy purchased and what it costs to charge.":
    "खरीदी गई ऊर्जा और चार्जिंग का खर्च दर्ज करें।",
  "A complete care history, from small repairs to major services.":
    "छोटी मरम्मत से बड़ी सर्विस तक, पूरी देखभाल का इतिहास।",
  "Stay a step ahead. A combined schedule is due when either interval is reached.":
    "तैयार रहें। तारीख या दूरी में से कोई भी अंतराल पूरा होने पर संयुक्त योजना देय होती है।",
  "Tolls, parking, accessories, and the little costs along the way.":
    "टोल, पार्किंग, सामान और सफर के छोटे खर्च।",
  "Keep insurance, certificates, and warranties in good standing.":
    "बीमा, प्रमाणपत्र और वारंटी की समय पर देखभाल।",
  "Keep a journal of your journeys and their linked expenses.":
    "यात्राओं और उनसे जुड़े खर्चों का विवरण रखें।",
  "Simple manual checks for more mindful vehicle care.":
    "वाहन की बेहतर देखभाल के लिए आसान मैन्युअल जाँच।",
  "Ready for the road": "सफर के लिए तैयार",
  "From all recorded costs": "सभी दर्ज खर्चों से",
  "Upcoming care & renewals": "आगामी देखभाल और नवीनीकरण",
  "Everything is looking good": "अभी सब सही है",
  "Needs two full-tank readings": "दो पूरे टैंक रिकॉर्ड चाहिए",
  "Across valid full-tank intervals": "मान्य पूरे टैंक अंतराल से",
  "Full-tank efficiency": "पूरे टैंक की दक्षता",
  "Recorded trip distance": "दर्ज यात्रा दूरी",
  "Needs attention": "ध्यान ज़रूरी है",
  "Total recorded cost": "कुल दर्ज खर्च",
  "Not enough data": "पर्याप्त डेटा नहीं",
  Unavailable: "उपलब्ध नहीं",
  "On track": "सही समय पर",
  Upcoming: "जल्द देय",
  Overdue: "समय बीत चुका",
  OK: "ठीक",
  Attention: "ध्यान दें",
  Unchecked: "जाँचा नहीं",
  Fuel: "ईंधन",
  Charging: "चार्जिंग",
  Service: "सर्विस",
  Toll: "टोल",
  Parking: "पार्किंग",
  Cleaning: "सफाई",
  Accessories: "सामान",
  Insurance: "बीमा",
  Other: "अन्य",
  Car: "कार",
  Motorcycle: "मोटरसाइकिल",
  Scooter: "स्कूटर",
  Petrol: "पेट्रोल",
  Diesel: "डीज़ल",
  Electric: "इलेक्ट्रिक",
  Hybrid: "हाइब्रिड",
  Warranty: "वारंटी",
  Custom: "अन्य",
  "No linked trip": "कोई जुड़ी यात्रा नहीं",
  "No notes added.": "कोई नोट नहीं जोड़ा गया।",
  "Not recorded": "दर्ज नहीं है",
  "Stored locally": "स्थानीय रूप से सहेजा गया",
  "Unsaved changes in memory": "बिना सहेजे बदलाव मेमोरी में हैं",
  "A fresh version is ready": "नया संस्करण तैयार है",
  "Ready to go offline": "ऑफलाइन उपयोग के लिए तैयार",
  "Saved vehicle records are kept when the app updates.":
    "ऐप अपडेट होने पर वाहन रिकॉर्ड सुरक्षित रहते हैं।",
  "The app shell is cached on this device.":
    "ऐप की फ़ाइलें इस डिवाइस पर कैश हैं।",
  Offline: "ऑफलाइन",
  "You have unsaved changes": "आपके बदलाव अभी सहेजे नहीं गए",
  "Storage conflict": "स्टोरेज में टकराव",
  "Storage needs attention": "स्टोरेज पर ध्यान देना ज़रूरी है",
  Home: "होम",
  Garage: "गैराज",
  Reminders: "रिमाइंडर",
  "Add Fuel": "ईंधन जोड़ें",
  "Add Charging Session": "चार्जिंग जोड़ें",
  "Add Service": "सर्विस जोड़ें",
  "Add Expense": "खर्च जोड़ें",
  "Add Trip": "यात्रा जोड़ें",
  "Update Odometer": "ओडोमीटर अपडेट करें",
  "All your vehicle tools, one tap away.": "आपके वाहन के सभी टूल, एक टैप पर।",
  "Choose an action. You can select a vehicle in the form.":
    "एक विकल्प चुनें। फ़ॉर्म में वाहन चुन सकते हैं।",
  "Add your first vehicle to unlock tracking actions.":
    "ट्रैकिंग शुरू करने के लिए अपना पहला वाहन जोड़ें।",
  "Device notifications": "डिवाइस सूचनाएँ",
  "Enable device reminders": "डिवाइस रिमाइंडर चालू करें",
  "Disable device reminders": "डिवाइस रिमाइंडर बंद करें",
  "Updating…": "अपडेट हो रहा है…",
  Permission: "अनुमति",
  scheduled: "निर्धारित",
  "Share JSON backup": "JSON बैकअप साझा करें",
  "Move your garage between devices": "अपना गैराज दूसरे डिवाइस पर ले जाएँ",
  "Your device stores your records. A backup makes them portable.":
    "आपके रिकॉर्ड इस डिवाइस पर हैं। बैकअप से उन्हें दूसरे डिवाइस पर ले जा सकते हैं।",
  "Local storage is not a guaranteed backup.":
    "स्थानीय स्टोरेज भरोसेमंद बैकअप की गारंटी नहीं है।",
  "Browsers, installed PWAs, and Android/iPhone apps can have separate storage. Export JSON here, save it outside VehicleCare, then choose that file in the destination app. Preview it and choose Merge or Replace.":
    "ब्राउज़र, इंस्टॉल किए गए PWA और Android/iPhone ऐप का स्टोरेज अलग हो सकता है। यहाँ JSON निर्यात करें, VehicleCare के बाहर सहेजें और दूसरे ऐप में वही फ़ाइल चुनें। पूर्वावलोकन के बाद मर्ज या बदलें चुनें।",
  "Clearing browser or app data, uninstalling the app, private browsing, storage eviction, or losing this device can remove your records. Save backups outside the app regularly and keep files private on shared devices.":
    "ब्राउज़र या ऐप डेटा साफ़ करने, ऐप हटाने, निजी ब्राउज़िंग, स्टोरेज हटने या डिवाइस खोने से रिकॉर्ड मिट सकते हैं। नियमित रूप से ऐप के बाहर बैकअप सहेजें और साझा डिवाइस पर फ़ाइलें निजी रखें।",
  "Recorded monthly spending": "दर्ज मासिक खर्च",
  "Upcoming care and documents, based on your saved dates and readings.":
    "सहेजी गई तारीखों और रीडिंग के अनुसार आगामी देखभाल और दस्तावेज़।",
  "Notification settings": "सूचना सेटिंग्स",
  "Distance reminders use readings you enter. VehicleCare does not monitor your odometer automatically.":
    "दूरी के रिमाइंडर आपकी दर्ज रीडिंग पर निर्भर हैं। VehicleCare ओडोमीटर की निगरानी अपने-आप नहीं करता।",
  "Nothing scheduled yet": "अभी कोई योजना नहीं है",
  "Add a maintenance schedule or document expiry to see reminders here.":
    "यहाँ रिमाइंडर देखने के लिए देखभाल की योजना या दस्तावेज़ की समाप्ति जोड़ें।",
  "Plan maintenance": "देखभाल की योजना बनाएँ",
  "Optional offline date reminders at approximately 9 AM local time. Notifications may show vehicle names on your lock screen. Enabling asks for system permission.":
    "वैकल्पिक ऑफलाइन तारीख रिमाइंडर लगभग सुबह 9 बजे स्थानीय समय पर। लॉक स्क्रीन पर वाहन का नाम दिख सकता है। चालू करने पर सिस्टम अनुमति माँगी जाएगी।",
  "Notification permission was not granted. You can enable it in system settings and try again.":
    "सूचनाओं की अनुमति नहीं मिली। सिस्टम सेटिंग्स में अनुमति देकर फिर प्रयास कर सकते हैं।",
  "Web and PWA reminders appear while the app is open. Use calendar export for document dates. Device notifications are available in the Android and iOS apps.":
    "वेब और PWA रिमाइंडर ऐप खुले होने पर दिखते हैं। दस्तावेज़ की तारीखें कैलेंडर में निर्यात कर सकते हैं। डिवाइस सूचनाएँ Android और iOS ऐप में उपलब्ध हैं।",
  "Distance reminders use readings you enter. Web reminders appear while open; Android/iPhone date notifications are optional in Device notifications.":
    "दूरी के रिमाइंडर आपकी रीडिंग पर निर्भर हैं। वेब रिमाइंडर ऐप खुले होने पर दिखते हैं; Android/iPhone में तारीख की सूचनाएँ डिवाइस सूचनाओं से चालू कर सकते हैं।",
  "Private by design. Your garage lives on this device.":
    "निजता के लिए बनाया गया। आपका गैराज इसी डिवाइस पर है।",
  "I am correcting an incorrect current reading. A lower value than recorded history will be rejected.":
    "मैं गलत वर्तमान रीडिंग सुधार रहा हूँ। दर्ज इतिहास से कम मान स्वीकार नहीं होगा।",
};
export const normalizedHindi = Object.fromEntries(
  Object.entries(hindiPhrases).map(([key, value]) => [
    key.toLowerCase(),
    value,
  ]),
);
