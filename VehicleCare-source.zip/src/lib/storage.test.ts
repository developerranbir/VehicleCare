import { describe, expect, it } from "vitest";
import {
  loadStorage,
  mergeSnapshots,
  persist,
  type StoragePort,
} from "./storage";
import { demoSnapshot } from "./demo";
import { emptySnapshot, snapshotSchema, STORAGE_KEY } from "./model";
class MemoryStorage implements StoragePort {
  value: string | null = null;
  getItem() {
    return this.value;
  }
  setItem(_key: string, value: string) {
    this.value = value;
  }
}
describe("validated storage adapter", () => {
  it("loads empty storage and persists a revisioned snapshot", () => {
    const storage = new MemoryStorage();
    const loaded = loadStorage(storage);
    const saved = persist(storage, demoSnapshot(), loaded.raw, "tab-a");
    expect(saved.snapshot.revision).toBe(1);
    expect(saved.snapshot.writerId).toBe("tab-a");
    expect(loadStorage(storage).snapshot).toEqual(saved.snapshot);
  });
  it("preserves malformed storage without silently resetting it", () => {
    const storage = new MemoryStorage();
    storage.value = "{bad";
    const result = loadStorage(storage);
    expect(result.blocked).toBe(true);
    expect(result.raw).toBe("{bad");
    expect(storage.value).toBe("{bad");
    expect(result.error).toContain("preserved");
  });
  it("handles unavailable storage gracefully", () => {
    const storage: StoragePort = {
      getItem: () => {
        throw new Error("SecurityError");
      },
      setItem: () => {},
    };
    expect(loadStorage(storage).blocked).toBe(true);
    expect(loadStorage(storage).error).toContain("unavailable");
  });
  it("throws quota failures without changing the last saved data", () => {
    const storage = new MemoryStorage();
    const initial = persist(storage, emptySnapshot(), null, "a");
    storage.setItem = () => {
      throw new DOMException("Storage is full", "QuotaExceededError");
    };
    expect(() => persist(storage, demoSnapshot(), initial.raw, "a")).toThrow(
      "Storage is full",
    );
    expect(storage.value).toBe(initial.raw);
  });
  it("detects changes from another tab and prevents overwrite", () => {
    const storage = new MemoryStorage();
    const first = persist(storage, emptySnapshot(), null, "a");
    const external = persist(storage, demoSnapshot(), first.raw, "b");
    expect(() => persist(storage, emptySnapshot(), first.raw, "a")).toThrow(
      "Another tab",
    );
    expect(storage.value).toBe(external.raw);
  });
  it("remaps colliding IDs and all vehicle and trip links on merge", () => {
    const s = demoSnapshot();
    const merged = mergeSnapshots(s, s);
    expect(merged.vehicles).toHaveLength(4);
    expect(merged.trips).toHaveLength(2);
    expect(merged.vehicles[2].id).not.toBe(s.vehicles[0].id);
    const incoming = merged.expenses.at(-3)!;
    expect(incoming.tripId).toBe(merged.trips[1].id);
    expect(incoming.vehicleId).toBe(merged.vehicles[2].id);
    expect(snapshotSchema.safeParse(merged).success).toBe(true);
    expect(s.vehicles).toHaveLength(2);
  });
  it("rejects invalid merge before the source can be mutated", () => {
    const s = demoSnapshot();
    const invalid = demoSnapshot();
    invalid.expenses[0].vehicleId = "unknown";
    expect(() => mergeSnapshots(s, invalid)).toThrow();
    expect(s.vehicles).toHaveLength(2);
  });
  it("uses the required single storage key", () =>
    expect(STORAGE_KEY).toBe("vehiclecare:app:v1"));
});
