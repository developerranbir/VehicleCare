import { addDays, format } from "date-fns";
import { type Snapshot, emptySnapshot, id, entrySchema } from "./model";
export function demoSnapshot(): Snapshot {
  const s = emptySnapshot();
  const car = id(),
    ev = id();
  const date = (days: number) =>
    format(addDays(new Date(), days), "yyyy-MM-dd");
  s.settings.onboarded = true;
  s.vehicles = [
    {
      id: car,
      name: "Hyundai Creta",
      make: "Hyundai",
      model: "Creta SX",
      year: 2023,
      registration: "MH 02 FG 4821",
      type: "Car",
      fuelType: "Petrol",
      odometer: 24850,
      purchaseDate: "2023-05-16",
      purchaseCost: 168000000,
      notes:
        "Family car. Keep the tyre pressure at the manufacturer’s recommendation.",
      archived: false,
      color: "teal",
    },
    {
      id: ev,
      name: "Ather 450X",
      make: "Ather",
      model: "450X",
      year: 2024,
      registration: "MH 02 JK 9076",
      type: "Scooter",
      fuelType: "Electric",
      odometer: 6420,
      purchaseDate: "2024-08-22",
      purchaseCost: 15600000,
      notes: "Daily commute.",
      archived: false,
      color: "blue",
    },
  ];
  const entry = (
    vehicleId: string,
    title: string,
    days: number,
    extra: object,
  ) =>
    entrySchema.parse({
      id: id(),
      vehicleId,
      title,
      date: date(days),
      ...extra,
    });
  s.fuelLogs = [
    entry(car, "Full tank · IndianOil", -80, {
      odometer: 22200,
      litres: 38,
      cost: 400000,
      fullTank: true,
      location: "IndianOil, Andheri",
    }),
    entry(car, "Weekend top-up", -60, {
      odometer: 22540,
      litres: 15,
      cost: 157500,
      fullTank: false,
    }),
    entry(car, "Full tank · HP", -40, {
      odometer: 22980,
      litres: 36,
      cost: 378000,
      fullTank: true,
    }),
    entry(car, "Full tank · IndianOil", -20, {
      odometer: 23520,
      litres: 37,
      cost: 388500,
      fullTank: true,
    }),
    entry(car, "Full tank · IndianOil", -5, {
      odometer: 24100,
      litres: 40,
      cost: 420000,
      fullTank: true,
    }),
  ];
  s.chargingLogs = [
    entry(ev, "Home charging", -32, {
      odometer: 6000,
      kwh: 3.2,
      cost: 2560,
      location: "Home",
    }),
    entry(ev, "Ather Grid", -12, {
      odometer: 6210,
      kwh: 2.8,
      cost: 8500,
      location: "Andheri",
    }),
    entry(ev, "Home charging", -2, {
      odometer: 6420,
      kwh: 3.1,
      cost: 2480,
      location: "Home",
    }),
  ];
  s.services = [
    entry(car, "Scheduled service", -35, {
      odometer: 23100,
      tasks: "Engine oil, oil filter, brake inspection",
      partsCost: 320000,
      labourCost: 180000,
      miscCost: 50000,
      location: "Hyundai Service, Mumbai",
    }),
    entry(ev, "Brake inspection", -20, {
      odometer: 6100,
      tasks: "Brake pads inspected and adjusted",
      partsCost: 0,
      labourCost: 45000,
      miscCost: 0,
      location: "Ather Service",
    }),
  ];
  s.maintenanceRules = [
    entry(car, "Engine oil & filter", 0, {
      intervalDays: 180,
      intervalKm: 5000,
      baselineDate: date(-35),
      baselineOdometer: 23100,
      warningDays: 30,
      warningKm: 500,
    }),
    entry(car, "Tyre rotation", 0, {
      intervalKm: 5000,
      baselineOdometer: 20000,
      warningKm: 500,
    }),
    entry(ev, "Brake inspection", 0, {
      intervalDays: 90,
      intervalKm: 3000,
      baselineDate: date(-20),
      baselineOdometer: 6100,
      warningDays: 14,
      warningKm: 300,
    }),
  ];
  s.expenses = [
    entry(car, "Car wash", -3, { cost: 50000, category: "Cleaning" }),
    entry(car, "Bandra–Worli Sea Link", -7, { cost: 10000, category: "Toll" }),
    entry(car, "Annual insurance", -65, {
      cost: 1850000,
      category: "Insurance",
    }),
    entry(ev, "Parking", -1, { cost: 3000, category: "Parking" }),
  ];
  s.renewals = [
    entry(car, "Comprehensive insurance", 0, {
      dueDate: date(24),
      renewalType: "Insurance",
      warningDays: 30,
    }),
    entry(car, "Pollution certificate", 0, {
      dueDate: date(62),
      renewalType: "PUC",
      warningDays: 30,
    }),
    entry(ev, "Battery warranty", 0, {
      dueDate: date(365),
      renewalType: "Warranty",
      warningDays: 30,
    }),
  ];
  const trip = entry(car, "Weekend in Lonavala", -2, {
    startOdometer: 24580,
    endOdometer: 24850,
    notes: "Family weekend getaway.",
  });
  s.trips = [trip];
  s.expenses[1].tripId = trip.id;
  s.checklistEntries = [
    entry(car, "Tyre pressure", -3, { status: "OK", completedDate: date(-3) }),
    entry(car, "Windscreen washer fluid", -3, {
      status: "Attention",
      notes: "Top up before the next long drive.",
    }),
    entry(ev, "Lights & indicators", 0, { status: "Unchecked" }),
  ];
  s.settings.emergencyContacts = [
    {
      id: id(),
      name: "Family contact (example)",
      phone: "Replace with your contact",
    },
  ];
  s.updatedAt = new Date().toISOString();
  s.createdAt = new Date().toISOString();
  return s;
}
