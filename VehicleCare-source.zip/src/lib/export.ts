import { type Entry, type Snapshot, today } from "./model";
import { ledger } from "./calculations";
import { exportText, reportFileResult } from "../platform/fileService";
export async function download(
  content: string,
  filename: string,
  type = "application/json",
) {
  try {
    const result = await exportText(content, filename, type);
    reportFileResult(result);
    return result;
  } catch (error) {
    reportFileResult({
      error: `Export was not completed: ${error instanceof Error ? error.message : "File sharing failed"}`,
    });
    return null;
  }
}
export const csvCell = (value: string | number) => {
  let s = String(value);
  if (/^[\s]*[=+@-]/.test(s)) s = `'${s}`;
  return `"${s.replaceAll('"', '""')}"`;
};
export function exportCSV(snapshot: Snapshot) {
  const rows = [
    [
      "Date",
      "Vehicle",
      "Title",
      "Category",
      "Cost (minor units)",
      "Currency",
      "Trip",
    ],
    ...ledger(snapshot).map((e) => [
      e.date,
      snapshot.vehicles.find((v) => v.id === e.vehicleId)?.name ?? "",
      e.title,
      e.category,
      e.amount,
      snapshot.settings.currency,
      e.tripId,
    ]),
  ];
  download(
    "\uFEFF" + rows.map((row) => row.map(csvCell).join(",")).join("\r\n"),
    `vehiclecare-ledger-${today()}.csv`,
    "text/csv;charset=utf-8",
  );
}
const escapeICS = (s: string) =>
  s
    .replaceAll("\\", "\\\\")
    .replaceAll("\n", "\\n")
    .replaceAll(";", "\\;")
    .replaceAll(",", "\\,")
    .replaceAll("\r", "");
function fold(line: string) {
  const bytes = new TextEncoder();
  let result = "",
    part = "";
  for (const char of line) {
    if (bytes.encode(part + char).length > 73) {
      result += part + "\r\n ";
      part = "";
    }
    part += char;
  }
  return result + part;
}
export function exportICS(entry: Entry, vehicleName: string) {
  const date = entry.dueDate!.replaceAll("-", "");
  const next = new Date(`${entry.dueDate}T12:00:00Z`);
  next.setUTCDate(next.getUTCDate() + 1);
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//VehicleCare//Renewals//EN",
    "BEGIN:VEVENT",
    `UID:${escapeICS(entry.id)}@vehiclecare.local`,
    `DTSTAMP:${new Date()
      .toISOString()
      .replace(/[-:]/g, "")
      .replace(/\.\d{3}/, "")}`,
    `DTSTART;VALUE=DATE:${date}`,
    `DTEND;VALUE=DATE:${next.toISOString().slice(0, 10).replaceAll("-", "")}`,
    `SUMMARY:${escapeICS(entry.title)} — ${escapeICS(vehicleName)}`,
    `DESCRIPTION:${escapeICS(entry.notes)}`,
    "END:VEVENT",
    "END:VCALENDAR",
  ];
  download(
    lines.map(fold).join("\r\n") + "\r\n",
    `vehiclecare-${entry.title}.ics`,
    "text/calendar",
  );
}
