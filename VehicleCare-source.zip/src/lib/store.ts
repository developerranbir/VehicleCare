import { create } from "zustand";
import {
  collections,
  type Collection,
  type Entry,
  type Snapshot,
  type Vehicle,
  emptySnapshot,
  id,
  snapshotSchema,
  validateEntry,
  STORAGE_KEY,
} from "./model";
import { loadStorage, mergeSnapshots, persist } from "./storage";
import { odometerWarning } from "./calculations";
const writerId = id();
function browserStorage() {
  return window.localStorage;
}
const initial = (() => {
  try {
    return loadStorage(browserStorage());
  } catch {
    return {
      snapshot: emptySnapshot(),
      error: "Browser storage is unavailable. Changes stay in memory.",
      raw: null,
      blocked: true,
    };
  }
})();
interface AppState {
  data: Snapshot;
  error: string | null;
  raw: string | null;
  blocked: boolean;
  dirty: boolean;
  conflict: boolean;
  commit: (change: (s: Snapshot) => void) => boolean;
  retry: () => void;
  receive: (raw: string | null) => void;
  resolve: (mode: "remote" | "local") => void;
  saveVehicle: (v: Vehicle, correction?: boolean) => boolean;
  saveEntry: (kind: Collection, e: Entry) => boolean;
  removeEntry: (kind: Collection, entryId: string) => void;
  importData: (s: Snapshot, mode: "replace" | "merge") => boolean;
  reset: () => void;
}
export const useApp = create<AppState>((set, get) => ({
  data: initial.snapshot,
  error: initial.error,
  raw: initial.raw,
  blocked: initial.blocked,
  dirty: false,
  conflict: false,
  commit(change) {
    const state = get();
    if (state.conflict) {
      set({
        error: "Resolve the cross-tab conflict before making more changes.",
      });
      return false;
    }
    try {
      const data = structuredClone(state.data);
      change(data);
      snapshotSchema.parse(data);
      if (state.blocked) {
        set({ data, dirty: true, error: state.error });
        return true;
      }
      try {
        const saved = persist(browserStorage(), data, state.raw, writerId);
        set({
          data: saved.snapshot,
          raw: saved.raw,
          dirty: false,
          error: null,
        });
      } catch (error) {
        const message =
          error instanceof Error ? error.message : "Storage write failed";
        set({
          data,
          dirty: true,
          error: `Not saved to browser storage: ${message}`,
          conflict: message.startsWith("Another tab"),
        });
      }
      return true;
    } catch (error) {
      set({ error: error instanceof Error ? error.message : "Invalid data" });
      return false;
    }
  },
  retry() {
    const state = get();
    try {
      if (state.blocked && state.raw)
        throw new Error("Recover or replace the unreadable storage first.");
      const saved = persist(browserStorage(), state.data, state.raw, writerId);
      set({
        data: saved.snapshot,
        raw: saved.raw,
        dirty: false,
        error: null,
        blocked: false,
        conflict: false,
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Storage unavailable";
      set({
        error: message,
        conflict: message.startsWith("Another tab"),
      });
    }
  },
  receive(raw) {
    const state = get();
    if (raw === state.raw) return;
    if (state.dirty || state.blocked) {
      set({
        conflict: true,
        error:
          "Another tab changed storage while you have unsaved data. Choose which snapshot to keep.",
      });
      return;
    }
    try {
      const incoming = raw
        ? snapshotSchema.parse(JSON.parse(raw))
        : emptySnapshot();
      if (
        raw &&
        incoming.revision <= state.data.revision &&
        incoming.writerId !== state.data.writerId
      ) {
        set({
          conflict: true,
          dirty: true,
          error:
            "Concurrent tabs produced competing revisions. Your snapshot is kept in memory; choose which to keep or export a backup.",
        });
        return;
      }
      set({ data: incoming, raw, error: null, conflict: false });
    } catch {
      set({
        conflict: true,
        error:
          "Another tab wrote unreadable data. Your in-memory data has been preserved.",
      });
    }
  },
  resolve(mode) {
    try {
      const raw = browserStorage().getItem(STORAGE_KEY);
      if (mode === "remote") {
        const result = loadStorage(browserStorage());
        if (result.blocked)
          throw new Error(result.error ?? "Invalid external data");
        set({
          data: result.snapshot,
          raw,
          dirty: false,
          conflict: false,
          error: null,
          blocked: false,
        });
      } else {
        let revision = get().data.revision;
        try {
          if (raw)
            revision = Math.max(
              revision,
              snapshotSchema.parse(JSON.parse(raw)).revision,
            );
        } catch {
          /* User explicitly chose to replace unreadable external data. */
        }
        set({
          raw,
          conflict: false,
          blocked: false,
          data: { ...get().data, revision },
        });
        get().retry();
      }
    } catch (error) {
      set({
        error:
          error instanceof Error ? error.message : "Conflict resolution failed",
      });
    }
  },
  saveVehicle(v, correction = false) {
    const state = get();
    const previous = state.data.vehicles.find((r) => r.id === v.id);
    const readings = [
      ...state.data.fuelLogs,
      ...state.data.chargingLogs,
      ...state.data.services,
    ]
      .filter((e) => e.vehicleId === v.id)
      .flatMap((e) => (e.odometer === undefined ? [] : [e.odometer]));
    readings.push(
      ...state.data.trips
        .filter((t) => t.vehicleId === v.id)
        .map((t) => t.endOdometer!),
    );
    if (v.odometer < Math.max(0, ...readings)) {
      set({
        error:
          "Current odometer cannot be below a recorded reading. Correct the affected records first.",
      });
      return false;
    }
    if (previous && v.odometer < previous.odometer && !correction) {
      set({
        error: "Confirm the odometer correction to reduce the current reading.",
      });
      return false;
    }
    return get().commit((s) => {
      const index = s.vehicles.findIndex((r) => r.id === v.id);
      if (index === -1) s.vehicles.push(v);
      else s.vehicles[index] = v;
    });
  },
  saveEntry(kind, e) {
    try {
      validateEntry(kind, e);
      const readings =
        kind === "trips" ? [e.startOdometer, e.endOdometer] : [e.odometer];
      for (const reading of readings) {
        if (reading !== undefined) {
          const warning = odometerWarning(
            get().data,
            e.vehicleId,
            e.date,
            reading,
            e.id,
          );
          if (warning) throw new Error(warning);
        }
      }
      if (kind === "services" && e.maintenanceRuleId) {
        const rule = get().data.maintenanceRules.find(
          (r) => r.id === e.maintenanceRuleId,
        );
        if (
          rule &&
          !get().data.services.some((service) => service.id === e.id) &&
          (e.date < (rule.lastCompletedDate ?? rule.baselineDate ?? "") ||
            e.odometer! <
              (rule.lastCompletedOdometer ?? rule.baselineOdometer ?? 0))
        )
          throw new Error(
            "Completion must be at or after the maintenance baseline and last completion.",
          );
      }
      return get().commit((s) => {
        const index = s[kind].findIndex((r) => r.id === e.id);
        if (index === -1) s[kind].push(e);
        else s[kind][index] = e;
        if (kind !== "maintenanceRules" && kind !== "checklistEntries") {
          const vehicle = s.vehicles.find((v) => v.id === e.vehicleId)!;
          vehicle.odometer = Math.max(
            vehicle.odometer,
            ...readings.filter((v): v is number => v !== undefined),
          );
        }
        if (kind === "services" && e.maintenanceRuleId) {
          const rule = s.maintenanceRules.find(
            (r) => r.id === e.maintenanceRuleId,
          )!;
          if (
            e.date >= (rule.lastCompletedDate ?? rule.baselineDate ?? "") &&
            e.odometer! >=
              (rule.lastCompletedOdometer ?? rule.baselineOdometer ?? 0)
          ) {
            rule.lastCompletedDate = e.date;
            rule.lastCompletedOdometer = e.odometer;
          }
        }
      });
    } catch (error) {
      set({ error: error instanceof Error ? error.message : "Invalid entry" });
      return false;
    }
  },
  removeEntry(kind, entryId) {
    get().commit((s) => {
      s[kind] = s[kind].filter((e) => e.id !== entryId);
      if (kind === "trips")
        for (const key of collections)
          for (const e of s[key]) if (e.tripId === entryId) e.tripId = "";
      if (kind === "maintenanceRules")
        for (const e of s.services)
          if (e.maintenanceRuleId === entryId) e.maintenanceRuleId = "";
    });
  },
  importData(incoming, mode) {
    try {
      snapshotSchema.parse(incoming);
      const state = get();
      const data =
        mode === "merge"
          ? mergeSnapshots(state.data, incoming)
          : structuredClone(incoming);
      data.revision = state.data.revision;
      data.settings.onboarded = true;
      if (state.conflict)
        throw new Error("Resolve the cross-tab conflict before importing.");
      if (state.blocked) {
        if (state.raw && mode === "merge")
          throw new Error(
            "Original data is unreadable. Download it first, then restore a valid backup using Replace.",
          );
        const saved = persist(browserStorage(), data, state.raw, writerId);
        set({
          data: saved.snapshot,
          raw: saved.raw,
          blocked: false,
          error: null,
          dirty: false,
          conflict: false,
        });
        return true;
      }
      if (state.conflict)
        throw new Error("Resolve the cross-tab conflict before importing.");
      const saved = persist(browserStorage(), data, state.raw, writerId);
      set({
        data: saved.snapshot,
        raw: saved.raw,
        dirty: false,
        error: null,
        conflict: false,
      });
      return true;
    } catch (error) {
      set({
        error: `Import failed; existing data preserved. ${error instanceof Error ? error.message : "Storage unavailable."}`,
        conflict:
          get().conflict ||
          (error instanceof Error && error.message.startsWith("Another tab")),
      });
      return false;
    }
  },
  reset() {
    const data = emptySnapshot();
    if (get().importData(data, "replace"))
      get().commit((s) => {
        s.settings.onboarded = false;
      });
  },
}));
window.addEventListener("storage", (event) => {
  if (event.key === STORAGE_KEY || event.key === null) {
    try {
      useApp.getState().receive(browserStorage().getItem(STORAGE_KEY));
    } catch {
      useApp.setState({
        error:
          "Another tab changed storage, but it is now unavailable. Export your in-memory backup.",
        dirty: true,
      });
    }
  }
});
