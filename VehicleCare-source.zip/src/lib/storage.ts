import {
  type Snapshot,
  collections,
  emptySnapshot,
  id,
  parseSnapshot,
  STORAGE_KEY,
  MAX_BACKUP_BYTES,
  snapshotSchema,
} from "./model";
export interface StoragePort {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}
export type LoadResult = {
  snapshot: Snapshot;
  error: string | null;
  raw: string | null;
  blocked: boolean;
};
export function loadStorage(storage: StoragePort): LoadResult {
  let raw: string | null = null;
  try {
    raw = storage.getItem(STORAGE_KEY);
    return {
      snapshot: raw ? parseSnapshot(raw) : emptySnapshot(),
      error: null,
      raw,
      blocked: false,
    };
  } catch (error) {
    return {
      snapshot: emptySnapshot(),
      raw,
      blocked: true,
      error: raw
        ? "Saved data could not be read. Original data is preserved. Download it before replacing or restoring a valid backup."
        : `Browser storage is unavailable. Changes will stay in memory. ${error instanceof Error ? error.message : ""}`,
    };
  }
}
export function persist(
  storage: StoragePort,
  snapshot: Snapshot,
  expectedRaw: string | null,
  writerId: string,
): { snapshot: Snapshot; raw: string } {
  const current = storage.getItem(STORAGE_KEY);
  if (current !== expectedRaw)
    throw new Error(
      "Another tab changed your data. Resolve the conflict before saving.",
    );
  const next = snapshotSchema.parse({
    ...snapshot,
    revision: snapshot.revision + 1,
    updatedAt: new Date().toISOString(),
    writerId,
  });
  const raw = JSON.stringify(next);
  if (new Blob([raw]).size > MAX_BACKUP_BYTES)
    throw new Error(
      "Snapshot exceeds the supported 5 MB limit. Reduce records and retry saving.",
    );
  storage.setItem(STORAGE_KEY, raw);
  return { snapshot: next, raw };
}
export function mergeSnapshots(
  current: Snapshot,
  incoming: Snapshot,
): Snapshot {
  const next = structuredClone(current);
  const incomingCopy = structuredClone(incoming);
  const ids = new Set(
    [...current.vehicles, ...collections.flatMap((k) => current[k])].map(
      (r) => r.id,
    ),
  );
  const mapping = new Map<string, string>();
  for (const record of [
    ...incomingCopy.vehicles,
    ...collections.flatMap((k) => incomingCopy[k]),
  ]) {
    const newId = ids.has(record.id) ? id() : record.id;
    mapping.set(record.id, newId);
    ids.add(newId);
    record.id = newId;
  }
  for (const key of collections)
    for (const entry of incomingCopy[key]) {
      entry.vehicleId = mapping.get(entry.vehicleId)!;
      if (entry.tripId) entry.tripId = mapping.get(entry.tripId)!;
      if (entry.maintenanceRuleId)
        entry.maintenanceRuleId = mapping.get(entry.maintenanceRuleId)!;
    }
  next.vehicles.push(...incomingCopy.vehicles);
  for (const key of collections) next[key].push(...incomingCopy[key]);
  const contactIds = new Set(next.settings.emergencyContacts.map((c) => c.id));
  next.settings.emergencyContacts.push(
    ...incomingCopy.settings.emergencyContacts.map((c) => ({
      ...c,
      id: contactIds.has(c.id) ? id() : c.id,
    })),
  );
  next.settings.onboarded = true;
  return snapshotSchema.parse(next);
}
