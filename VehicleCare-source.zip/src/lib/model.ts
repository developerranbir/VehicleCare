import { z } from "zod";

export const STORAGE_KEY = "vehiclecare:app:v1";
export const MAX_BACKUP_BYTES = 5 * 1024 * 1024;
export const MAX_RECORDS = 20000;
export const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
let idSequence = 0;
export const id = () => {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  const entropy = globalThis.crypto?.getRandomValues
    ? Array.from(globalThis.crypto.getRandomValues(new Uint32Array(4)), (n) =>
        n.toString(36),
      ).join("")
    : `${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;
  return `local-${Date.now().toString(36)}-${++idSequence}-${entropy}`;
};
export const dateSchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine((v) => {
    const d = new Date(`${v}T12:00:00Z`);
    return !Number.isNaN(d.valueOf()) && d.toISOString().slice(0, 10) === v;
  }, "Enter a valid calendar date");
const text = z.string().max(4000);
const nonnegative = z.number().finite().nonnegative();
const money = nonnegative.int().max(Number.MAX_SAFE_INTEGER);
export const vehicleSchema = z.object({
  id: z.string().min(1),
  name: text.min(1),
  make: text.min(1),
  model: text.min(1),
  year: z.number().int().min(1900).max(2100),
  registration: text,
  type: z.enum(["Car", "Motorcycle", "Scooter", "Other"]),
  fuelType: z.enum(["Petrol", "Diesel", "Electric", "Hybrid", "CNG", "Other"]),
  odometer: nonnegative,
  purchaseDate: dateSchema.or(z.literal("")),
  purchaseCost: money,
  notes: text,
  archived: z.boolean(),
  color: z.enum(["teal", "blue", "amber", "violet"]).default("teal"),
});
export type Vehicle = z.infer<typeof vehicleSchema>;
export const entrySchema = z.object({
  id: z.string().min(1),
  vehicleId: z.string().min(1),
  title: text.min(1),
  date: dateSchema,
  notes: text.default(""),
  odometer: nonnegative.optional(),
  cost: money.default(0),
  tripId: z.string().default(""),
  litres: nonnegative.optional(),
  fullTank: z.boolean().default(true),
  location: text.default(""),
  kwh: nonnegative.optional(),
  tasks: text.default(""),
  partsCost: money.default(0),
  labourCost: money.default(0),
  miscCost: money.default(0),
  category: z
    .enum([
      "Fuel",
      "Charging",
      "Service",
      "Toll",
      "Parking",
      "Cleaning",
      "Accessories",
      "Insurance",
      "Other",
    ])
    .default("Other"),
  intervalDays: z.number().int().min(1).max(36500).optional(),
  intervalKm: z.number().positive().max(10000000).optional(),
  baselineDate: dateSchema.optional(),
  baselineOdometer: nonnegative.optional(),
  lastCompletedDate: dateSchema.optional(),
  lastCompletedOdometer: nonnegative.optional(),
  warningDays: z.number().int().nonnegative().max(3650).default(30),
  warningKm: nonnegative.default(500),
  maintenanceRuleId: z.string().default(""),
  dueDate: dateSchema.optional(),
  renewalType: z
    .enum(["Insurance", "PUC", "Warranty", "Custom"])
    .default("Custom"),
  history: z
    .array(
      z.object({ date: dateSchema, previousDueDate: dateSchema, cost: money }),
    )
    .max(1000)
    .default([]),
  startOdometer: nonnegative.optional(),
  endOdometer: nonnegative.optional(),
  status: z.enum(["OK", "Attention", "Unchecked"]).default("Unchecked"),
  completedDate: dateSchema.optional(),
});
export type Entry = z.infer<typeof entrySchema>;
export const collections = [
  "fuelLogs",
  "chargingLogs",
  "services",
  "maintenanceRules",
  "expenses",
  "renewals",
  "trips",
  "checklistEntries",
] as const;
export type Collection = (typeof collections)[number];
export function validateEntry(kind: Collection, value: unknown): Entry {
  const entry = entrySchema.parse(value);
  const requireValue = (key: keyof Entry) => {
    if (entry[key] === undefined || entry[key] === "")
      throw new Error(`${key} is required`);
  };
  if (kind === "fuelLogs") {
    requireValue("odometer");
    if (!entry.litres) throw new Error("Litres must be greater than zero");
  }
  if (kind === "chargingLogs" && !entry.kwh)
    throw new Error("Energy must be greater than zero");
  if (kind === "services") {
    requireValue("odometer");
    if (!entry.tasks.trim())
      throw new Error("Enter at least one completed task");
  }
  if (kind === "maintenanceRules") {
    if (!entry.intervalDays && !entry.intervalKm)
      throw new Error("Provide a date or distance interval");
    if (entry.intervalDays) requireValue("baselineDate");
    if (entry.intervalKm) requireValue("baselineOdometer");
    if (
      entry.lastCompletedDate &&
      entry.baselineDate &&
      entry.lastCompletedDate < entry.baselineDate
    )
      throw new Error("Last completion cannot be before the baseline date");
    if (
      entry.lastCompletedOdometer !== undefined &&
      entry.baselineOdometer !== undefined &&
      entry.lastCompletedOdometer < entry.baselineOdometer
    )
      throw new Error("Last completed odometer cannot be below the baseline");
  }
  if (kind === "renewals") requireValue("dueDate");
  if (kind === "trips") {
    requireValue("startOdometer");
    requireValue("endOdometer");
    if (entry.endOdometer! < entry.startOdometer!)
      throw new Error("Ending odometer must be at least the starting reading");
  }
  return entry;
}
const list = (kind: Collection) =>
  z.array(entrySchema).superRefine((entries, ctx) => {
    entries.forEach((entry, index) => {
      try {
        validateEntry(kind, entry);
      } catch (error) {
        ctx.addIssue({
          code: "custom",
          path: [index],
          message: error instanceof Error ? error.message : "Invalid record",
        });
      }
    });
  });
export const settingsSchema = z.object({
  language: z.enum(["en", "hi"]),
  currency: z.enum(["INR", "USD", "EUR", "GBP"]),
  distanceUnit: z.enum(["km", "mi"]),
  theme: z.enum(["light", "dark", "system"]),
  selectedVehicleId: z.string(),
  warningDays: z.number().int().min(0).max(3650),
  warningKm: nonnegative,
  onboarded: z.boolean(),
  nativeRemindersEnabled: z.boolean().default(false),
  emergencyContacts: z
    .array(z.object({ id: z.string(), name: text.min(1), phone: text.min(1) }))
    .max(100)
    .refine(
      (contacts) => new Set(contacts.map((c) => c.id)).size === contacts.length,
      "Contact IDs must be unique",
    ),
  breakdownNotes: text,
});
export const snapshotSchema = z
  .object({
    schemaVersion: z.literal(1),
    revision: z.number().int().nonnegative(),
    createdAt: z.iso.datetime(),
    updatedAt: z.iso.datetime(),
    writerId: z.string(),
    settings: settingsSchema,
    vehicles: z.array(vehicleSchema),
    fuelLogs: list("fuelLogs"),
    chargingLogs: list("chargingLogs"),
    services: list("services"),
    maintenanceRules: list("maintenanceRules"),
    expenses: list("expenses"),
    renewals: list("renewals"),
    trips: list("trips"),
    checklistEntries: list("checklistEntries"),
  })
  .superRefine((s, ctx) => {
    const allIds = new Set<string>();
    const vehicleIds = new Set(s.vehicles.map((v) => v.id));
    const tripVehicles = new Map(s.trips.map((e) => [e.id, e.vehicleId]));
    const maintenanceVehicles = new Map(
      s.maintenanceRules.map((e) => [e.id, e.vehicleId]),
    );
    const records = [...s.vehicles, ...collections.flatMap((k) => s[k])];
    if (records.length > MAX_RECORDS)
      ctx.addIssue({
        code: "custom",
        message: `Limit is ${MAX_RECORDS} records`,
      });
    records.forEach((record) => {
      if (allIds.has(record.id))
        ctx.addIssue({ code: "custom", message: `Duplicate ID: ${record.id}` });
      allIds.add(record.id);
    });
    for (const key of collections)
      for (const entry of s[key]) {
        if (!vehicleIds.has(entry.vehicleId))
          ctx.addIssue({
            code: "custom",
            path: [key],
            message: "Record references an unknown vehicle",
          });
        if (entry.tripId && tripVehicles.get(entry.tripId) !== entry.vehicleId)
          ctx.addIssue({
            code: "custom",
            path: [key],
            message: "Invalid trip reference",
          });
        if (
          entry.maintenanceRuleId &&
          maintenanceVehicles.get(entry.maintenanceRuleId) !== entry.vehicleId
        )
          ctx.addIssue({
            code: "custom",
            path: [key],
            message: "Invalid maintenance reference",
          });
      }
    for (const vehicle of s.vehicles) {
      const readings = [...s.fuelLogs, ...s.chargingLogs, ...s.services]
        .filter((e) => e.vehicleId === vehicle.id && e.odometer !== undefined)
        .map((e) => ({ date: e.date, km: e.odometer! }));
      for (const trip of s.trips.filter((e) => e.vehicleId === vehicle.id))
        readings.push(
          { date: trip.date, km: trip.startOdometer! },
          { date: trip.date, km: trip.endOdometer! },
        );
      const groups = new Map<string, number[]>();
      for (const reading of readings)
        groups.set(reading.date, [
          ...(groups.get(reading.date) ?? []),
          reading.km,
        ]);
      let previous = 0;
      for (const [, values] of [...groups].sort(([a], [b]) =>
        a.localeCompare(b),
      )) {
        if (Math.min(...values) < previous)
          ctx.addIssue({
            code: "custom",
            message: `Inconsistent chronological odometer for ${vehicle.name}`,
          });
        previous = Math.max(previous, ...values);
      }
      if (vehicle.odometer < previous)
        ctx.addIssue({
          code: "custom",
          message: `Current odometer is below a recorded reading for ${vehicle.name}`,
        });
    }
    if (
      s.settings.selectedVehicleId &&
      !vehicleIds.has(s.settings.selectedVehicleId)
    )
      ctx.addIssue({ code: "custom", message: "Selected vehicle is missing" });
  });
export type Snapshot = z.infer<typeof snapshotSchema>;
export const emptySnapshot = (): Snapshot => ({
  schemaVersion: 1,
  revision: 0,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  writerId: "",
  settings: {
    language: "en",
    currency: "INR",
    distanceUnit: "km",
    theme: "system",
    selectedVehicleId: "",
    warningDays: 30,
    warningKm: 500,
    onboarded: false,
    nativeRemindersEnabled: false,
    emergencyContacts: [],
    breakdownNotes: "",
  },
  vehicles: [],
  fuelLogs: [],
  chargingLogs: [],
  services: [],
  maintenanceRules: [],
  expenses: [],
  renewals: [],
  trips: [],
  checklistEntries: [],
});
export function parseSnapshot(raw: string): Snapshot {
  if (new Blob([raw]).size > MAX_BACKUP_BYTES)
    throw new Error("Backup exceeds the 5 MB limit");
  const data: unknown = JSON.parse(raw);
  if (
    typeof data === "object" &&
    data !== null &&
    "schemaVersion" in data &&
    data.schemaVersion === 0
  ) {
    // Explicit migration from the legacy version-0 snapshot; record units were already canonical.
    const legacy = data as Record<string, unknown>;
    return snapshotSchema.parse({
      ...emptySnapshot(),
      ...legacy,
      schemaVersion: 1,
      settings: { ...emptySnapshot().settings, ...(legacy.settings as object) },
    });
  }
  return snapshotSchema.parse(data);
}
