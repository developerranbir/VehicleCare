import { copy } from "./lib/i18n";
import { useEffect, useState, lazy, Suspense } from "react";
import {
  BrowserRouter,
  HashRouter,
  useNavigate,
  NavLink,
  Link,
  Route,
  Routes,
  useLocation,
} from "react-router-dom";
import {
  Car,
  LayoutDashboard,
  Fuel,
  Zap,
  Wrench,
  CalendarClock,
  Wallet,
  ShieldCheck,
  Route as RouteIcon,
  ChartNoAxesCombined,
  ClipboardCheck,
  Phone,
  Settings as SettingsIcon,
  Info,
  ChevronDown,
  Plus,
  WifiOff,
  Check,
  Menu,
  Download,
  X,
  AlertTriangle,
} from "lucide-react";
import { platform } from "./platform/platform";
import { useAppLifecycle } from "./platform/lifecycle";
import { useRuntime } from "./platform/runtime";
import { setNativeAppearance } from "./platform/nativeApp";
import { BottomNavigation } from "./components/mobile/BottomNavigation";
import { QuickActionSheet } from "./components/mobile/QuickActionSheet";
import { PwaStatus } from "./components/PwaStatus";
import { FileFeedback } from "./components/FileFeedback";
import { More } from "./features/mobile/More";
import { Reminders } from "./features/mobile/Reminders";
import { useApp } from "./lib/store";
import { type Label } from "./lib/i18n";
import { Button } from "./components/ui/button";
import { Dialog } from "./components/ui/dialog";
import { Empty, useT } from "./components/shared";
import { Garage, VehicleDetail, VehicleForm } from "./features/garage/Garage";
import { RecordsPage } from "./features/records/RecordsPage";
import { routeCollection } from "./features/records/config";
import { Onboarding } from "./features/onboarding/Onboarding";
import { Settings } from "./features/settings/Settings";
import { Backup } from "./features/settings/Backup";
import { Emergency } from "./features/emergency/Emergency";
const Dashboard = lazy(() =>
  import("./features/dashboard/Dashboard").then((m) => ({
    default: m.Dashboard,
  })),
);
const Reports = lazy(() =>
  import("./features/reports/Reports").then((m) => ({ default: m.Reports })),
);
const primary: [string, Label, typeof Car][] = [
  ["dashboard", "dashboard", LayoutDashboard],
  ["garage", "garage", Car],
  ["fuel", "fuel", Fuel],
  ["charging", "charging", Zap],
  ["services", "services", Wrench],
  ["maintenance", "maintenance", CalendarClock],
  ["expenses", "expenses", Wallet],
  ["renewals", "renewals", ShieldCheck],
  ["trips", "trips", RouteIcon],
  ["reports", "reports", ChartNoAxesCombined],
  ["checklists", "checklists", ClipboardCheck],
  ["emergency", "emergency", Phone],
];
type InstallEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
};
function Shell() {
  const { data, error, dirty, conflict, retry, resolve, blocked } = useApp();
  const t = useT();
  const location = useLocation();
  const navigate = useNavigate();
  useAppLifecycle();
  useRuntime((s) => s.now);
  const nativeError = useRuntime((s) => s.nativeError);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);
  const [quick, setQuick] = useState(false);
  const [offline, setOffline] = useState(!navigator.onLine);
  const [install, setInstall] = useState<InstallEvent | null>(null);
  const [installInfo, setInstallInfo] = useState(false);
  const [installMessage, setInstallMessage] = useState("");
  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      document.documentElement.dataset.theme =
        data.settings.theme === "system"
          ? media.matches
            ? "dark"
            : "light"
          : data.settings.theme;
      document.documentElement.lang = data.settings.language;
      void setNativeAppearance(
        document.documentElement.dataset.theme === "dark",
      ).catch((error) =>
        useRuntime.setState({
          nativeError: error instanceof Error ? error.message : String(error),
        }),
      );
    };
    apply();
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, [data.settings.theme, data.settings.language]);
  useEffect(() => {
    const onOnline = () => setOffline(!navigator.onLine);
    const onInstall = (event: Event) => {
      event.preventDefault();
      setInstall(event as InstallEvent);
    };
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOnline);
    window.addEventListener("beforeinstallprompt", onInstall);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOnline);
      window.removeEventListener("beforeinstallprompt", onInstall);
    };
  }, []);
  useEffect(() => {
    const warning = (event: BeforeUnloadEvent) => {
      if (useApp.getState().dirty) {
        event.preventDefault();
        event.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", warning);
    return () => window.removeEventListener("beforeunload", warning);
  }, []);
  const welcome =
    !data.settings.onboarded &&
    !blocked &&
    !["/about", "/settings/backup"].includes(location.pathname) &&
    !location.pathname.startsWith("/garage");
  const nav = (items: typeof primary) =>
    items.map(([path, label, Icon]) => (
      <NavLink
        key={path}
        to={`/${path}`}
        className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
      >
        <Icon size={18} />
        <span>{t(label)}</span>
        {path === "dashboard" && <span className="nav-active-dot" />}
      </NavLink>
    ));
  async function requestInstall() {
    if (install) {
      await install.prompt();
      const choice = await install.userChoice;
      setInstallMessage(
        choice.outcome === "accepted"
          ? "Installation requested."
          : "You can install later from your browser menu.",
      );
      setInstall(null);
    } else setInstallInfo(true);
  }
  return (
    <>
      <a className="skip-link" href="#main-content">
        {copy("Skip to content")}
      </a>
      {welcome ? (
        <Onboarding />
      ) : (
        <div className="app-shell">
          <aside className="sidebar">
            <Link className="brand" to="/dashboard">
              <span className="brand-icon">
                <Car size={23} />
              </span>
              <strong>
                {copy("Vehicle")}
                <span>{copy("Care")}</span>
              </strong>
            </Link>
            <p className="brand-tagline">{copy("YOUR VEHICLE. YOUR CARE.")}</p>
            <div className="sidebar-label">{copy("WORKSPACE")}</div>
            <nav aria-label={copy("Main navigation")}>{nav(primary)}</nav>
            <div className="sidebar-bottom">
              <nav aria-label={copy("Preferences")}>
                {nav([
                  ["settings", "settings", SettingsIcon],
                  ["about", "about", Info],
                ])}
              </nav>
              <div className="sidebar-local">
                <span>
                  <ShieldCheck size={19} />
                </span>
                <div>
                  <strong>{copy("Your data. Your device.")}</strong>
                  <p>{copy("No cloud. No worries.")}</p>
                </div>
                <Check size={14} />
              </div>
            </div>
          </aside>
          <div className="app-main">
            <header className="topbar">
              <div className="topbar-left">
                <button
                  className="icon-button mobile-menu"
                  aria-label={copy("Open navigation")}
                  onClick={() => navigate("/more")}
                >
                  <Menu size={21} />
                </button>
                <span className="breadcrumb">
                  {copy("Workspace")}
                  <span>/</span>{" "}
                  <strong>
                    {primary.find(([path]) =>
                      location.pathname.startsWith(`/${path}`),
                    )
                      ? t(
                          primary.find(([path]) =>
                            location.pathname.startsWith(`/${path}`),
                          )![1],
                        )
                      : location.pathname.includes("backup")
                        ? t("backup")
                        : t("settings")}
                  </strong>
                </span>
              </div>
              <div className="topbar-actions">
                <span className={`local-pill ${offline ? "offline" : ""}`}>
                  {offline ? (
                    <WifiOff size={14} />
                  ) : (
                    <span className="tiny-dot" />
                  )}
                  {dirty
                    ? copy("Unsaved changes in memory")
                    : blocked
                      ? copy("Storage needs attention")
                      : offline
                        ? copy("Offline")
                        : t("local")}
                </span>
                <div className="vehicle-select">
                  <Car size={16} />
                  <select
                    aria-label={copy("Filter by vehicle")}
                    value={data.settings.selectedVehicleId}
                    onChange={(e) =>
                      useApp.getState().commit((s) => {
                        s.settings.selectedVehicleId = e.target.value;
                      })
                    }
                  >
                    <option value="">{t("allVehicles")}</option>
                    {data.vehicles
                      .filter((v) => !v.archived)
                      .map((v) => (
                        <option value={v.id} key={v.id}>
                          {v.name}
                        </option>
                      ))}
                  </select>
                  <ChevronDown size={13} />
                </div>
                <Button
                  aria-label={t("quickAdd")}
                  onClick={() => {
                    setQuick(true);
                  }}
                >
                  <Plus size={17} />
                  <span>{t("quickAdd")}</span>
                </Button>
              </div>
            </header>
            <main id="main-content" className="content">
              {nativeError && (
                <div className="notice" role="alert">
                  Device integration: {nativeError}
                </div>
              )}
              {error && (
                <div className="storage-error" role="alert">
                  <AlertTriangle size={22} />
                  <div>
                    <strong>
                      {dirty
                        ? "You have unsaved changes"
                        : conflict
                          ? "Storage conflict"
                          : "Storage needs attention"}
                    </strong>
                    <p>{error}</p>
                    <div className="error-actions">
                      {conflict ? (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (
                                window.confirm(
                                  "Discard in-memory changes and load the other tab’s data?",
                                )
                              )
                                resolve("remote");
                            }}
                          >
                            {copy("Load other tab")}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (
                                window.confirm(
                                  "Overwrite the other tab’s changes with this snapshot? Export both first if needed.",
                                )
                              )
                                resolve("local");
                            }}
                          >
                            {copy("Keep this snapshot")}
                          </Button>
                        </>
                      ) : (!blocked || !useApp.getState().raw) && dirty ? (
                        <Button size="sm" variant="outline" onClick={retry}>
                          {copy("Retry saving")}
                        </Button>
                      ) : null}
                      <Button size="sm" variant="outline" asChild>
                        <Link to="/settings/backup">
                          {copy("Backup & recovery")}
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              <Suspense
                fallback={
                  <div className="loading" role="status">
                    {copy("Loading your workspace…")}
                  </div>
                }
              >
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/garage" element={<Garage />} />
                  <Route path="/garage/new" element={<VehicleForm />} />
                  <Route
                    path="/garage/:vehicleId"
                    element={<VehicleDetail />}
                  />
                  <Route
                    path="/garage/:vehicleId/edit"
                    element={<VehicleForm />}
                  />
                  {Object.entries(routeCollection).map(([path, key]) => (
                    <Route
                      path={`/${path}`}
                      key={path}
                      element={<RecordsPage key={key} kind={key} />}
                    />
                  ))}
                  <Route path="/reports" element={<Reports />} />
                  <Route path="/more" element={<More />} />
                  <Route path="/reminders" element={<Reminders />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/settings/backup" element={<Backup />} />
                  <Route path="/emergency" element={<Emergency />} />
                  <Route path="/about" element={<About />} />
                  <Route
                    path="*"
                    element={
                      <Empty
                        title={copy("That road doesn’t lead anywhere")}
                        description={copy(
                          "This page couldn’t be found. Your garage is still here.",
                        )}
                        action={
                          <Button asChild>
                            <Link to="/dashboard">
                              {copy("Back to overview")}
                            </Link>
                          </Button>
                        }
                      />
                    }
                  />
                </Routes>
              </Suspense>
              <footer className="app-footer">
                <span>
                  {copy("VehicleCare")}
                  <span>·</span>
                  {copy("Your Vehicle. Your Care.")}
                </span>
                {!platform.native() && (
                  <button
                    onClick={() => {
                      void requestInstall();
                    }}
                  >
                    <Download size={14} />
                    {copy("Install app")}
                  </button>
                )}
              </footer>
            </main>
          </div>
          <BottomNavigation onAdd={() => setQuick(true)} />
        </div>
      )}
      {welcome && error && (
        <div className="welcome-error storage-error" role="alert">
          {error}
          <Link to="/settings/backup">{copy("Backup & recovery")}</Link>
        </div>
      )}
      <QuickActionSheet open={quick} onOpenChange={setQuick} />
      {!platform.native() && <PwaStatus />}
      <FileFeedback />
      <Dialog
        open={installInfo}
        onOpenChange={setInstallInfo}
        title={copy("Install VehicleCare")}
      >
        <p className="muted">
          {copy(
            "Use your browser’s Install app menu. On iPhone or iPad, open in Safari and choose Share → Add to Home Screen. Installation requires a secure HTTPS site or localhost.",
          )}
        </p>
        <p className="muted">
          {copy(
            "After the first complete online visit, cached screens and local data work offline.",
          )}
        </p>
        <Button onClick={() => setInstallInfo(false)}>{copy("Got it")}</Button>
      </Dialog>
      {installMessage && (
        <div className="pwa-toast" role="status">
          {installMessage}
          <button
            className="icon-button"
            aria-label={copy("Dismiss install message")}
            onClick={() => setInstallMessage("")}
          >
            <X size={16} />
          </button>
        </div>
      )}
    </>
  );
}
function About() {
  return (
    <div className="card about-card">
      <span className="brand-icon">
        <Car size={32} />
      </span>
      <h1>{copy("VehicleCare")}</h1>
      <p className="welcome-description">{copy("Your Vehicle. Your Care.")}</p>
      <h2>{copy("Made for a calmer journey")}</h2>
      <p>
        {copy(
          "VehicleCare brings your garage, fuel and charging records, service history, maintenance plans, trips, checks, renewals, and spending together in one private workspace.",
        )}
      </p>
      <h2>{copy("Private, local, offline")}</h2>
      <p>
        {copy(
          "No account, backend, tracking, or automatic vehicle-data upload. Records stay on this device. Browsers, PWAs and native apps may have separate storage. Export backups outside the app regularly: clearing data, uninstalling, storage eviction or losing your device can remove records.",
        )}
      </p>
      <h2>{copy("Honest records, useful insight")}</h2>
      <p>
        {copy(
          "Fuel economy uses consistent full-tank intervals and includes intermediate partial fills. Charging figures describe purchased energy, not driving consumption. Reports summarize recorded costs and may not represent your complete ownership cost.",
        )}
      </p>
      <p>
        {copy(
          "Checklists are manual inspections. Optional Android/iPhone date notifications depend on system permission and delivery restrictions; mileage reminders use readings you enter. VehicleCare does not provide mechanical diagnoses or safety guarantees.",
        )}
      </p>
      <p className="small muted">
        {copy("Version 1.0.0 · Built with free, open-source tools.")}
      </p>
      <Button asChild>
        <Link to="/settings/backup">{copy("Keep a backup")}</Link>
      </Button>
    </div>
  );
}
export default function App() {
  const Router = platform.native() ? HashRouter : BrowserRouter;
  return (
    <Router>
      <Shell />
    </Router>
  );
}
