import { useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { App as NativeApp } from "@capacitor/app";
import { Keyboard } from "@capacitor/keyboard";
import { LocalNotifications } from "@capacitor/local-notifications";
import type { PluginListenerHandle } from "@capacitor/core";
import { useApp } from "../lib/store";
import { STORAGE_KEY, today } from "../lib/model";
import { platform } from "./platform";
import { useRuntime } from "./runtime";
import { notificationService } from "./notificationService";
import { dismissTopModal, backAction } from "./modalStack";
import { finishNativeLaunch, hideKeyboard } from "./nativeApp";
export function refreshSavedState() {
  const state = useApp.getState();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw === null && state.raw !== null) {
      useApp.setState({
        raw: null,
        dirty: true,
        error:
          "Saved storage is missing. Your in-memory data is preserved. Export a backup or retry saving.",
      });
    } else state.receive(raw);
  } catch {
    useApp.setState({
      dirty: true,
      error:
        "Storage is unavailable after resume. In-memory data is preserved; export a backup.",
    });
  }
}
export function useAppLifecycle() {
  const navigate = useNavigate();
  const location = useLocation();
  const latest = useRef({ navigate, path: location.pathname });
  useEffect(() => {
    latest.current = { navigate, path: location.pathname };
  }, [navigate, location.pathname]);
  useEffect(() => {
    let disposed = false;
    let syncTimer: ReturnType<typeof setTimeout> | undefined;
    const handles = new Set<PluginListenerHandle>();
    const fail = (error: unknown) => {
      if (!disposed)
        useRuntime.setState({
          nativeError: error instanceof Error ? error.message : String(error),
        });
    };
    const retain = async (promise: Promise<PluginListenerHandle>) => {
      const handle = await promise;
      if (disposed) await handle.remove();
      else handles.add(handle);
    };
    const sync = () => {
      if (syncTimer) clearTimeout(syncTimer);
      syncTimer = setTimeout(() => {
        if (disposed) return;
        void notificationService
          .sync(useApp.getState().data)
          .then((reminders) => {
            if (!disposed) useRuntime.setState({ reminders });
          });
      }, 200);
    };
    const resume = () => {
      if (disposed) return;
      refreshSavedState();
      useRuntime.getState().refresh();
      sync();
    };
    const visibility = () => {
      if (document.visibilityState === "visible") resume();
    };
    document.addEventListener("visibilitychange", visibility);
    const viewport = window.visualViewport;
    const resized = () => {
      if (platform.native()) return;
      const focused = document.activeElement;
      const typing =
        focused instanceof HTMLInputElement ||
        focused instanceof HTMLTextAreaElement;
      const open =
        !!viewport && typing && window.innerHeight - viewport.height > 150;
      useRuntime.setState({ keyboardOpen: open });
      document.documentElement.dataset.keyboard = open ? "open" : "closed";
    };
    viewport?.addEventListener("resize", resized);
    document.addEventListener("focusout", resized);
    let clockKey = `${today()}|${new Date().getTimezoneOffset()}`;
    const timer = setInterval(() => {
      useRuntime.getState().refresh();
      const key = `${today()}|${new Date().getTimezoneOffset()}`;
      if (key !== clockKey) {
        clockKey = key;
        sync();
      }
    }, 60000);
    const unsubscribe = useApp.subscribe((state, previous) => {
      if (state.data !== previous.data) sync();
    });
    if (platform.native()) {
      document.documentElement.dataset.platform = platform.name();
      void finishNativeLaunch().catch(fail);
      if (platform.available("App")) {
        void retain(
          NativeApp.addListener("appStateChange", ({ isActive }) => {
            if (isActive) resume();
          }),
        ).catch(fail);
        if (platform.name() === "android")
          void retain(
            NativeApp.addListener("backButton", () => {
              if (disposed) return;
              if (dismissTopModal()) {
                void hideKeyboard().catch(fail);
                return;
              }
              const action = backAction({
                modal: false,
                keyboard: useRuntime.getState().keyboardOpen,
                index: Number(window.history.state?.idx ?? 0),
                path: latest.current.path,
              });
              if (action === "keyboard") void hideKeyboard().catch(fail);
              else if (action === "back") latest.current.navigate(-1);
              else if (action === "home")
                latest.current.navigate("/dashboard", { replace: true });
              else if (action === "minimize")
                void NativeApp.minimizeApp().catch(fail);
            }),
          ).catch(fail);
      }
      if (platform.available("Keyboard")) {
        const setKeyboard = (open: boolean) => {
          if (disposed) return;
          useRuntime.setState({ keyboardOpen: open });
          document.documentElement.dataset.keyboard = open ? "open" : "closed";
        };
        void retain(
          Keyboard.addListener("keyboardWillShow", () => setKeyboard(true)),
        ).catch(fail);
        void retain(
          Keyboard.addListener("keyboardDidHide", () => setKeyboard(false)),
        ).catch(fail);
      }
      if (platform.available("LocalNotifications")) {
        void retain(
          LocalNotifications.addListener(
            "localNotificationActionPerformed",
            ({ notification }) => {
              if (disposed) return;
              const path = notification.extra?.path;
              if (path === "/maintenance" || path === "/renewals")
                latest.current.navigate(path);
            },
          ),
        ).catch(fail);
      }
      sync();
    }
    return () => {
      disposed = true;
      clearInterval(timer);
      if (syncTimer) clearTimeout(syncTimer);
      unsubscribe();
      document.removeEventListener("visibilitychange", visibility);
      viewport?.removeEventListener("resize", resized);
      document.removeEventListener("focusout", resized);
      for (const handle of handles) void handle.remove().catch(() => {});
    };
  }, []);
}
