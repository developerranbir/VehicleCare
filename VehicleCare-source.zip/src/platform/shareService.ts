import { Share } from "@capacitor/share";
export interface SharePort {
  canShare: () => Promise<{ value: boolean }>;
  share: (options: {
    title: string;
    files: string[];
    dialogTitle: string;
  }) => Promise<unknown>;
}
export async function shareLocalFile(uri: string, share: SharePort = Share) {
  if (!(await share.canShare()).value)
    throw new Error(
      "Native sharing is unavailable. An external backup has not been created.",
    );
  await share.share({
    title: "VehicleCare export",
    files: [uri],
    dialogTitle: "Save or share your VehicleCare file",
  });
}
