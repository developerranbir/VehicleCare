const modals: { id: symbol; dismiss: () => void }[] = [];
export function registerModal(dismiss: () => void) {
  const modal = { id: Symbol("modal"), dismiss };
  modals.push(modal);
  return () => {
    const index = modals.findIndex((m) => m.id === modal.id);
    if (index >= 0) modals.splice(index, 1);
  };
}
export function dismissTopModal() {
  const modal = modals.at(-1);
  if (!modal) return false;
  modal.dismiss();
  return true;
}
export type BackAction = "modal" | "keyboard" | "back" | "home" | "minimize";
export function backAction({
  modal,
  keyboard,
  index,
  path,
}: {
  modal: boolean;
  keyboard: boolean;
  index: number;
  path: string;
}): BackAction {
  if (modal) return "modal";
  if (keyboard) return "keyboard";
  if (index > 0) return "back";
  return path === "/" || path === "/dashboard" ? "minimize" : "home";
}
