import { Capacitor } from "@capacitor/core";
export type PlatformName = "web" | "android" | "ios";
export interface PlatformPort {
  getPlatform: () => string;
  isNativePlatform: () => boolean;
  isPluginAvailable: (name: string) => boolean;
}
export function createPlatform(port: PlatformPort = Capacitor) {
  const name = () => port.getPlatform() as PlatformName;
  const native = () =>
    port.isNativePlatform() && (name() === "android" || name() === "ios");
  return {
    name,
    native,
    available: (plugin: string) => native() && port.isPluginAvailable(plugin),
  };
}
export const platform = createPlatform();
