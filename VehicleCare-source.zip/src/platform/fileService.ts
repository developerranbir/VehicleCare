import { Directory, Encoding, Filesystem } from "@capacitor/filesystem";
import { platform } from "./platform";
import { shareLocalFile } from "./shareService";
export const safeFilename = (filename: string) => {
  const sanitized = filename.replace(/[^a-zA-Z0-9._-]/g, "_");
  const extension = sanitized.match(/\.[a-zA-Z0-9]{1,8}$/)?.[0] ?? "";
  return (
    (sanitized
      .slice(0, extension ? -extension.length : undefined)
      .slice(0, 120) || "vehiclecare-export") + extension
  );
};
export interface FilePort {
  writeFile: (options: {
    path: string;
    data: string;
    directory: Directory;
    encoding: Encoding;
    recursive: boolean;
  }) => Promise<{ uri: string }>;
  readdir: typeof Filesystem.readdir;
  deleteFile: typeof Filesystem.deleteFile;
}
export type ExportResult = { kind: "download" | "shared"; message: string };
export async function exportText(
  content: string,
  filename: string,
  type: string,
  dependencies: {
    native?: boolean;
    files?: FilePort;
    share?: (uri: string) => Promise<void>;
  } = {},
): Promise<ExportResult> {
  const native = dependencies.native ?? platform.native();
  const safe = safeFilename(filename);
  if (!native) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = safe;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return {
      kind: "download",
      message:
        "Download requested. Check your browser downloads and keep the file somewhere safe.",
    };
  }
  const files = dependencies.files ?? Filesystem;
  // Only short-lived export files use Cache. Business records stay in localStorage.
  try {
    const old = await files.readdir({
      path: "vehiclecare-exports",
      directory: Directory.Cache,
    });
    for (const file of old.files) {
      if (
        file.type === "file" &&
        file.mtime &&
        file.mtime < Date.now() - 86400000
      )
        await files.deleteFile({
          path: `vehiclecare-exports/${file.name}`,
          directory: Directory.Cache,
        });
    }
  } catch {
    /* The export directory may not exist yet. */
  }
  const written = await files.writeFile({
    path: `vehiclecare-exports/${new Date().toISOString().replace(/[:.]/g, "-")}-${safe}`,
    data: content,
    directory: Directory.Cache,
    encoding: Encoding.UTF8,
    recursive: true,
  });
  await (dependencies.share ?? shareLocalFile)(written.uri);
  return {
    kind: "shared",
    message:
      "Share sheet closed. Confirm that you saved the file outside VehicleCare before relying on this backup.",
  };
}
export function reportFileResult(result: ExportResult | { error: string }) {
  window.dispatchEvent(
    new CustomEvent("vehiclecare:file-result", { detail: result }),
  );
}
