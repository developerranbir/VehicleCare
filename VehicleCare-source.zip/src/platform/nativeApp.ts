import { SystemBars, SystemBarsStyle } from "@capacitor/core";
import { StatusBar, Style } from "@capacitor/status-bar";
import { Keyboard, KeyboardStyle } from "@capacitor/keyboard";
import { SplashScreen } from "@capacitor/splash-screen";
import { platform } from "./platform";
export async function setNativeAppearance(dark: boolean) {
  if (!platform.native()) return;
  const results = await Promise.allSettled([
    platform.available("SystemBars")
      ? SystemBars.setStyle({
          style: dark ? SystemBarsStyle.Dark : SystemBarsStyle.Light,
        })
      : Promise.resolve(),
    platform.available("StatusBar")
      ? StatusBar.setStyle({ style: dark ? Style.Light : Style.Dark })
      : Promise.resolve(),
    platform.name() === "ios" && platform.available("Keyboard")
      ? Keyboard.setStyle({
          style: dark ? KeyboardStyle.Dark : KeyboardStyle.Light,
        })
      : Promise.resolve(),
  ]);
  const rejected = results.find(
    (result): result is PromiseRejectedResult => result.status === "rejected",
  );
  if (rejected)
    throw new Error(
      `System appearance could not be updated: ${String(rejected.reason)}`,
    );
}
export async function finishNativeLaunch() {
  if (platform.available("SplashScreen")) {
    await new Promise<void>((resolve) =>
      requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
    );
    await SplashScreen.hide();
  }
}
export async function hideKeyboard() {
  if (platform.available("Keyboard")) await Keyboard.hide();
}
