import { beforeEach, describe, expect, it, vi } from "vitest";
import { Directory, Encoding } from "@capacitor/filesystem";
import { exportText, safeFilename, type FilePort } from "./fileService";
import { shareLocalFile } from "./shareService";
const files = (): FilePort => ({
  writeFile: vi.fn(async () => ({ uri: "file:///cache/backup.json" })),
  readdir: vi.fn(async () => ({ files: [] })),
  deleteFile: vi.fn(async () => {}),
});
beforeEach(() => vi.restoreAllMocks());
describe("device export without a business filesystem database", () => {
  it("writes UTF-8 to private Cache, then opens the external share sheet", async () => {
    const port = files(),
      share = vi.fn(async () => {});
    const result = await exportText(
      '{"schemaVersion":1}',
      "backup.json",
      "application/json",
      { native: true, files: port, share },
    );
    expect(port.writeFile).toHaveBeenCalledWith(
      expect.objectContaining({
        directory: Directory.Cache,
        encoding: Encoding.UTF8,
        data: '{"schemaVersion":1}',
        recursive: true,
      }),
    );
    expect(share).toHaveBeenCalledWith("file:///cache/backup.json");
    expect(result.kind).toBe("shared");
    expect(result.message).toContain("Confirm");
  });
  it("does not claim a successful external backup if sharing fails", async () => {
    const port = files();
    await expect(
      exportText("{}", "backup.json", "application/json", {
        native: true,
        files: port,
        share: async () => {
          throw new Error("User cancelled");
        },
      }),
    ).rejects.toThrow("User cancelled");
    expect(port.writeFile).toHaveBeenCalledOnce();
  });
  it("does not attempt sharing if the file write failed", async () => {
    const port = files();
    vi.mocked(port.writeFile).mockRejectedValue(new Error("Disk full"));
    const share = vi.fn();
    await expect(
      exportText("{}", "backup.json", "application/json", {
        native: true,
        files: port,
        share,
      }),
    ).rejects.toThrow("Disk full");
    expect(share).not.toHaveBeenCalled();
  });
  it("rejects unavailable native sharing without a success result", async () => {
    const share = {
      canShare: vi.fn(async () => ({ value: false })),
      share: vi.fn(),
    };
    await expect(shareLocalFile("file:///cache/a.json", share)).rejects.toThrow(
      "external backup",
    );
    expect(share.share).not.toHaveBeenCalled();
  });
  it("bounds filenames and neutralizes path separators while keeping extension", () => {
    expect(safeFilename("../../secret?.json")).not.toContain("/");
    expect(safeFilename("x".repeat(200) + ".json")).toHaveLength(125);
    expect(safeFilename("x".repeat(200) + ".json")).toMatch(/\.json$/);
  });
  it("uses a browser download without calling native plugins", async () => {
    Object.defineProperty(URL, "createObjectURL", {
      configurable: true,
      value: vi.fn(() => "blob:download"),
    });
    Object.defineProperty(URL, "revokeObjectURL", {
      configurable: true,
      value: vi.fn(),
    });
    const click = vi
        .spyOn(HTMLAnchorElement.prototype, "click")
        .mockImplementation(() => {}),
      port = files();
    const result = await exportText("{}", "backup.json", "application/json", {
      native: false,
      files: port,
    });
    expect(click).toHaveBeenCalledOnce();
    expect(port.writeFile).not.toHaveBeenCalled();
    expect(result.kind).toBe("download");
  });
});
