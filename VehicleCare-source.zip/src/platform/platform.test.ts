import { describe, expect, it, vi } from "vitest";
import { createPlatform } from "./platform";
import { backAction, dismissTopModal, registerModal } from "./modalStack";
describe("platform capabilities and back decisions", () => {
  it("never advertises native plugins on the web", () => {
    const available = vi.fn(() => true);
    const p = createPlatform({
      getPlatform: () => "web",
      isNativePlatform: () => false,
      isPluginAvailable: available,
    });
    expect(p.native()).toBe(false);
    expect(p.available("Filesystem")).toBe(false);
    expect(available).not.toHaveBeenCalled();
  });
  it.each(["android", "ios"])(
    "detects %s only with a real native bridge",
    (name) => {
      const p = createPlatform({
        getPlatform: () => name,
        isNativePlatform: () => true,
        isPluginAvailable: (plugin) => plugin === "App",
      });
      expect(p.native()).toBe(true);
      expect(p.available("App")).toBe(true);
      expect(p.available("Share")).toBe(false);
    },
  );
  it("dismisses the most recently opened modal first and unregisters cleanly", () => {
    const first = vi.fn(),
      second = vi.fn();
    const a = registerModal(first),
      b = registerModal(second);
    expect(dismissTopModal()).toBe(true);
    expect(second).toHaveBeenCalledOnce();
    expect(first).not.toHaveBeenCalled();
    b();
    dismissTopModal();
    expect(first).toHaveBeenCalledOnce();
    a();
    expect(dismissTopModal()).toBe(false);
  });
  it("prioritizes modal, keyboard, history, nested-root fallback and task minimize", () => {
    const root = {
      modal: false,
      keyboard: false,
      index: 0,
      path: "/dashboard",
    };
    expect(backAction({ ...root, modal: true, keyboard: true, index: 3 })).toBe(
      "modal",
    );
    expect(backAction({ ...root, keyboard: true, index: 3 })).toBe("keyboard");
    expect(backAction({ ...root, index: 3 })).toBe("back");
    expect(backAction({ ...root, path: "/garage/new" })).toBe("home");
    expect(backAction(root)).toBe("minimize");
  });
});
