import {
  LocalNotifications,
  type LocalNotificationSchema,
  type LocalNotificationsPlugin,
} from "@capacitor/local-notifications";
import { addDays, format, parseISO } from "date-fns";
import { type Snapshot } from "../lib/model";
import { maintenanceStatus } from "../lib/calculations";
import { platform } from "./platform";
export const MAX_SCHEDULED_REMINDERS = 60;
const OWNER = "vehiclecare";
export function notificationId(key: string) {
  let hash = 2166136261;
  for (const c of key) {
    hash ^= c.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return ((hash >>> 0) % 2147483646) + 1;
}
export function planNotifications(snapshot: Snapshot, now = new Date()) {
  const sources: {
    key: string;
    title: string;
    vehicle: string;
    dueDate: string;
    warningDays: number;
    path: string;
  }[] = [];
  const vehicles = new Map(
    snapshot.vehicles.filter((v) => !v.archived).map((v) => [v.id, v]),
  );
  for (const rule of snapshot.maintenanceRules) {
    const vehicle = vehicles.get(rule.vehicleId);
    if (!vehicle || !rule.intervalDays) continue;
    const status = maintenanceStatus(rule, vehicle);
    if (status.dueDate)
      sources.push({
        key: `maintenance:${rule.id}`,
        title: rule.title,
        vehicle: vehicle.name,
        dueDate: status.dueDate,
        warningDays: rule.warningDays,
        path: "/maintenance",
      });
  }
  for (const renewal of snapshot.renewals) {
    const vehicle = vehicles.get(renewal.vehicleId);
    if (vehicle)
      sources.push({
        key: `renewal:${renewal.id}`,
        title: renewal.title,
        vehicle: vehicle.name,
        dueDate: renewal.dueDate!,
        warningDays: renewal.warningDays,
        path: "/renewals",
      });
  }
  const candidates: LocalNotificationSchema[] = [];
  const used = new Set<number>();
  for (const source of sources.sort((a, b) => a.key.localeCompare(b.key))) {
    for (const phase of ["warning", "due"] as const) {
      if (phase === "warning" && !source.warningDays) continue;
      const date =
        phase === "warning"
          ? format(
              addDays(parseISO(source.dueDate), -source.warningDays),
              "yyyy-MM-dd",
            )
          : source.dueDate;
      const at = parseISO(date);
      at.setHours(9, 0, 0, 0);
      if (at.valueOf() <= now.valueOf()) continue;
      const key = `${source.key}:${phase}`;
      let notification = notificationId(key);
      while (used.has(notification))
        notification = notification === 2147483647 ? 1 : notification + 1;
      used.add(notification);
      const title =
        snapshot.settings.language === "hi"
          ? phase === "warning"
            ? "VehicleCare · जल्द ध्यान दें"
            : "VehicleCare · आज देय"
          : phase === "warning"
            ? "VehicleCare · Coming up"
            : "VehicleCare · Due today";
      const body = `${source.vehicle} · ${source.title} · ${source.dueDate}`;
      candidates.push({
        id: notification,
        title,
        body,
        channelId: "vehiclecare-reminders",
        smallIcon: "ic_stat_vehiclecare",
        schedule: { at, allowWhileIdle: false },
        isExactNotification: false,
        extra: {
          owner: OWNER,
          key,
          sourceKey: source.key,
          path: source.path,
          dueDate: source.dueDate,
          fingerprint: JSON.stringify([title, body, at.toISOString()]),
        },
      });
    }
  }
  candidates.sort(
    (a, b) =>
      a.schedule!.at!.valueOf() - b.schedule!.at!.valueOf() || a.id - b.id,
  );
  return {
    notifications: candidates.slice(0, MAX_SCHEDULED_REMINDERS),
    omitted: Math.max(0, candidates.length - MAX_SCHEDULED_REMINDERS),
    dueDates: new Map(sources.map((s) => [s.key, s.dueDate])),
  };
}
export type NotificationPort = Pick<
  LocalNotificationsPlugin,
  | "checkPermissions"
  | "requestPermissions"
  | "getPending"
  | "cancel"
  | "schedule"
  | "createChannel"
  | "getDeliveredNotifications"
  | "removeDeliveredNotifications"
>;
type Result = {
  permission: string;
  scheduled: number;
  omitted: number;
  error: string | null;
};
function extraData(value: unknown): {
  owner?: string;
  fingerprint?: string;
  sourceKey?: string;
  dueDate?: string;
} {
  return typeof value === "object" && value !== null ? value : {};
}
export function createNotificationService(
  plugin: NotificationPort = LocalNotifications,
  device = platform,
) {
  let queue: Promise<unknown> = Promise.resolve();
  async function reconcile(snapshot: Snapshot, now: Date): Promise<Result> {
    if (!device.available("LocalNotifications"))
      return { permission: "web", scheduled: 0, omitted: 0, error: null };
    const permission = await plugin.checkPermissions();
    const pending = await plugin.getPending();
    const owned = pending.notifications.filter(
      (n) => extraData(n.extra).owner === OWNER,
    );
    const enabled =
      snapshot.settings.nativeRemindersEnabled &&
      permission.display === "granted";
    const plan = planNotifications(snapshot, now);
    const desired = enabled ? plan.notifications : [];
    const ids = new Map(desired.map((n) => [n.id, n]));
    const obsolete = owned.filter(
      (n) =>
        !ids.has(n.id) ||
        extraData(n.extra).fingerprint !==
          extraData(ids.get(n.id)?.extra).fingerprint,
    );
    if (obsolete.length)
      await plugin.cancel({
        notifications: obsolete.map((n) => ({ id: n.id })),
      });
    if (enabled) {
      if (device.name() === "android")
        await plugin.createChannel({
          id: "vehiclecare-reminders",
          name: "Vehicle care reminders",
          description: "Optional service and document reminders",
          importance: 3,
          visibility: 0,
        });
      const previous = new Map(owned.map((n) => [n.id, n]));
      const added = desired.filter(
        (n) =>
          extraData(previous.get(n.id)?.extra).fingerprint !==
          extraData(n.extra).fingerprint,
      );
      // The explicit grant check prevents schedule() from requesting permission on startup.
      if (
        added.length &&
        (await plugin.checkPermissions()).display === "granted"
      )
        await plugin.schedule({ notifications: added });
    }
    const delivered = await plugin.getDeliveredNotifications();
    const stale = delivered.notifications.filter((n) => {
      const extra = extraData(n.extra);
      return (
        extra.owner === OWNER &&
        (!enabled ||
          !extra.sourceKey ||
          plan.dueDates.get(extra.sourceKey) !== extra.dueDate)
      );
    });
    if (stale.length)
      await plugin.removeDeliveredNotifications({ notifications: stale });
    return {
      permission: permission.display,
      scheduled: desired.length,
      omitted: enabled ? plan.omitted : 0,
      error: null,
    };
  }
  return {
    async requestPermission() {
      if (!device.available("LocalNotifications"))
        return { display: "denied" as const };
      return plugin.requestPermissions();
    },
    sync(snapshot: Snapshot, now = new Date()): Promise<Result> {
      const job = queue
        .catch(() => {})
        .then(() => reconcile(snapshot, now))
        .catch((error) => ({
          permission: "unknown",
          scheduled: 0,
          omitted: 0,
          error:
            error instanceof Error
              ? error.message
              : "Notification scheduling failed",
        }));
      queue = job;
      return job;
    },
  };
}
export const notificationService = createNotificationService();
