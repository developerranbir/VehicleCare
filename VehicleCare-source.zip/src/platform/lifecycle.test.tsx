import { useState } from "react";
import { act, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { demoSnapshot } from "../lib/demo";
import { STORAGE_KEY } from "../lib/model";
import { useApp } from "../lib/store";
import { useRuntime } from "./runtime";
import { registerModal } from "./modalStack";
const mocks = vi.hoisted(() => ({
  navigate: vi.fn(),
  path: "/dashboard",
  listeners: new Map<string, (event: Record<string, unknown>) => void>(),
  removers: [] as ReturnType<typeof vi.fn>[],
  minimize: vi.fn(async () => {}),
  hide: vi.fn(async () => {}),
  sync: vi.fn(async () => ({
    permission: "granted",
    scheduled: 2,
    omitted: 0,
    error: null,
  })),
}));
const addListener = vi.hoisted(() =>
  vi.fn(
    async (
      name: string,
      callback: (event: Record<string, unknown>) => void,
    ) => {
      mocks.listeners.set(name, callback);
      const remove = vi.fn(async () => {
        if (mocks.listeners.get(name) === callback)
          mocks.listeners.delete(name);
      });
      mocks.removers.push(remove);
      return { remove };
    },
  ),
);
vi.mock("react-router-dom", () => ({
  useNavigate: () => mocks.navigate,
  useLocation: () => ({ pathname: mocks.path }),
}));
vi.mock("@capacitor/app", () => ({
  App: { addListener, minimizeApp: mocks.minimize },
}));
vi.mock("@capacitor/keyboard", () => ({ Keyboard: { addListener } }));
vi.mock("@capacitor/local-notifications", () => ({
  LocalNotifications: { addListener },
}));
vi.mock("./platform", () => ({
  platform: {
    native: () => true,
    name: () => "android",
    available: () => true,
  },
}));
vi.mock("./nativeApp", () => ({
  finishNativeLaunch: async () => {},
  hideKeyboard: mocks.hide,
}));
vi.mock("./notificationService", () => ({
  notificationService: { sync: mocks.sync },
}));
import { refreshSavedState, useAppLifecycle } from "./lifecycle";
function Draft() {
  useAppLifecycle();
  const [draft, setDraft] = useState("");
  return (
    <input
      aria-label="Draft title"
      value={draft}
      onChange={(e) => setDraft(e.target.value)}
    />
  );
}
async function flush() {
  await act(async () => {
    await Promise.resolve();
    await Promise.resolve();
  });
}
beforeEach(() => {
  vi.useFakeTimers();
  vi.clearAllMocks();
  mocks.listeners.clear();
  mocks.removers.length = 0;
  mocks.path = "/dashboard";
  const data = demoSnapshot();
  data.revision = 1;
  const raw = JSON.stringify(data);
  localStorage.setItem(STORAGE_KEY, raw);
  useApp.setState({
    data,
    raw,
    dirty: false,
    blocked: false,
    conflict: false,
    error: null,
  });
  useRuntime.setState({ keyboardOpen: false, nativeError: null, now: 0 });
  window.history.replaceState({ idx: 0 }, "");
});
afterEach(() => vi.useRealTimers());
describe("native lifecycle with mocked device listeners", () => {
  it("dismisses a modal before keyboard, history, nested home and root minimize", async () => {
    const view = render(<Draft />);
    await flush();
    const dismiss = vi.fn();
    const release = registerModal(dismiss);
    act(() => mocks.listeners.get("backButton")!({}));
    expect(dismiss).toHaveBeenCalledOnce();
    expect(mocks.navigate).not.toHaveBeenCalled();
    release();
    useRuntime.setState({ keyboardOpen: true });
    act(() => mocks.listeners.get("backButton")!({}));
    expect(mocks.hide).toHaveBeenCalledTimes(2);
    expect(mocks.minimize).not.toHaveBeenCalled();
    useRuntime.setState({ keyboardOpen: false });
    window.history.replaceState({ idx: 2 }, "");
    act(() => mocks.listeners.get("backButton")!({}));
    expect(mocks.navigate).toHaveBeenLastCalledWith(-1);
    window.history.replaceState({ idx: 0 }, "");
    mocks.path = "/garage/new";
    view.rerender(<Draft />);
    act(() => mocks.listeners.get("backButton")!({}));
    expect(mocks.navigate).toHaveBeenLastCalledWith("/dashboard", {
      replace: true,
    });
    mocks.path = "/dashboard";
    view.rerender(<Draft />);
    act(() => mocks.listeners.get("backButton")!({}));
    expect(mocks.minimize).toHaveBeenCalledOnce();
  });
  it("refreshes on resume without losing a partially entered form", async () => {
    render(<Draft />);
    await flush();
    fireEvent.change(screen.getByLabelText("Draft title"), {
      target: { value: "Unsubmitted service" },
    });
    const saved = structuredClone(useApp.getState().data);
    saved.revision++;
    saved.vehicles[0].name = "Updated externally";
    localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
    act(() => mocks.listeners.get("appStateChange")!({ isActive: true }));
    expect(useApp.getState().data.vehicles[0].name).toBe("Updated externally");
    expect(screen.getByLabelText("Draft title")).toHaveValue(
      "Unsubmitted service",
    );
    expect(useRuntime.getState().now).toBeGreaterThan(0);
    await act(async () => {
      await vi.advanceTimersByTimeAsync(250);
    });
    expect(mocks.sync).toHaveBeenCalledOnce();
    expect(mocks.sync).toHaveBeenCalledWith(useApp.getState().data);
  });
  it("keeps unsaved memory on resume and reports conflicting storage", () => {
    const memory = useApp.getState().data;
    useApp.setState({ dirty: true });
    const saved = structuredClone(memory);
    saved.revision++;
    saved.vehicles[0].name = "Remote branch";
    localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
    refreshSavedState();
    expect(useApp.getState().data).toBe(memory);
    expect(useApp.getState().conflict).toBe(true);
  });
  it("preserves records when the saved container has disappeared", () => {
    const memory = useApp.getState().data;
    localStorage.removeItem(STORAGE_KEY);
    refreshSavedState();
    expect(useApp.getState().data).toBe(memory);
    expect(useApp.getState().dirty).toBe(true);
    expect(useApp.getState().error).toContain("missing");
  });
  it("updates keyboard state, routes owned reminders and removes every listener", async () => {
    const view = render(<Draft />);
    await flush();
    expect(mocks.listeners.size).toBe(5);
    act(() => mocks.listeners.get("keyboardWillShow")!({}));
    expect(document.documentElement.dataset.keyboard).toBe("open");
    act(() => mocks.listeners.get("keyboardDidHide")!({}));
    expect(useRuntime.getState().keyboardOpen).toBe(false);
    act(() =>
      mocks.listeners.get("localNotificationActionPerformed")!({
        notification: { extra: { path: "/renewals" } },
      }),
    );
    expect(mocks.navigate).toHaveBeenLastCalledWith("/renewals");
    mocks.navigate.mockClear();
    act(() =>
      mocks.listeners.get("localNotificationActionPerformed")!({
        notification: { extra: { path: "https://outside.example" } },
      }),
    );
    expect(mocks.navigate).not.toHaveBeenCalled();
    view.unmount();
    await flush();
    expect(
      mocks.removers.every((remove) => remove.mock.calls.length === 1),
    ).toBe(true);
    expect(mocks.listeners.size).toBe(0);
    await vi.advanceTimersByTimeAsync(1000);
    expect(mocks.sync).not.toHaveBeenCalled();
  });
  it("removes a listener that finishes attaching after unmount", async () => {
    let finish!: (value: Awaited<ReturnType<typeof addListener>>) => void;
    addListener.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          finish = resolve;
        }),
    );
    const view = render(<Draft />);
    view.unmount();
    const remove = vi.fn(async () => {});
    await act(async () => {
      finish({ remove });
    });
    expect(remove).toHaveBeenCalledOnce();
  });
});
