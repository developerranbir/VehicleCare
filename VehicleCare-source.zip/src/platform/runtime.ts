import { create } from "zustand";
export type ReminderRuntime = {
  permission: string;
  scheduled: number;
  omitted: number;
  error: string | null;
};
export const useRuntime = create<{
  now: number;
  keyboardOpen: boolean;
  nativeError: string | null;
  reminders: ReminderRuntime;
  refresh: () => void;
}>((set) => ({
  now: Date.now(),
  keyboardOpen: false,
  nativeError: null,
  reminders: { permission: "unknown", scheduled: 0, omitted: 0, error: null },
  refresh: () => set({ now: Date.now() }),
}));
