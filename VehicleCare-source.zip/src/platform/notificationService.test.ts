import { describe, expect, it, vi } from "vitest";
import type { PendingLocalNotificationSchema } from "@capacitor/local-notifications";
import { demoSnapshot } from "../lib/demo";
import { entrySchema } from "../lib/model";
import {
  createNotificationService,
  notificationId,
  planNotifications,
  type NotificationPort,
  MAX_SCHEDULED_REMINDERS,
} from "./notificationService";
import { createPlatform } from "./platform";
const native = createPlatform({
  getPlatform: () => "android",
  isNativePlatform: () => true,
  isPluginAvailable: () => true,
});
function fixture() {
  const s = demoSnapshot();
  s.maintenanceRules = [
    {
      ...s.maintenanceRules[0],
      baselineDate: "2026-10-01",
      intervalDays: 30,
      warningDays: 7,
    },
  ];
  s.renewals = [];
  s.settings.nativeRemindersEnabled = true;
  return s;
}
const now = () => new Date(2026, 9, 10, 12);
function port(permission: "granted" | "denied" = "granted") {
  let pending: PendingLocalNotificationSchema[] = [];
  const plugin: NotificationPort = {
    checkPermissions: vi.fn(async () => ({ display: permission })),
    requestPermissions: vi.fn(async () => ({ display: permission })),
    getPending: vi.fn(async () => ({ notifications: pending })),
    cancel: vi.fn(
      async ({ notifications }: Parameters<NotificationPort["cancel"]>[0]) => {
        pending = pending.filter(
          (n) => !notifications.some((v) => v.id === n.id),
        );
      },
    ),
    schedule: vi.fn(
      async ({
        notifications,
      }: Parameters<NotificationPort["schedule"]>[0]) => {
        pending.push(...notifications);
        return { notifications: notifications.map((n) => ({ id: n.id })) };
      },
    ),
    createChannel: vi.fn(async () => {}),
    getDeliveredNotifications: vi.fn(async () => ({ notifications: [] })),
    removeDeliveredNotifications: vi.fn(async () => {}),
  };
  return plugin;
}
describe("optional inexact native notifications", () => {
  it("plans warning and due events at 9 AM, with deterministic IDs and inexact alarms", () => {
    const s = fixture(),
      plan = planNotifications(s, now());
    expect(plan.notifications).toHaveLength(2);
    expect(plan.notifications.map((n) => n.id)).toEqual(
      planNotifications(s, now()).notifications.map((n) => n.id),
    );
    expect(
      plan.notifications.every(
        (n) =>
          n.schedule!.at!.getHours() === 9 && n.isExactNotification === false,
      ),
    ).toBe(true);
    expect(notificationId("record:due")).toBeGreaterThan(0);
    expect(notificationId("record:due")).toBeLessThan(2147483648);
  });
  it("does not replay past times or invent odometer monitoring", () => {
    const s = fixture();
    s.maintenanceRules[0].intervalDays = undefined;
    expect(planNotifications(s, now()).notifications).toEqual([]);
    s.maintenanceRules[0].intervalDays = 1;
    expect(planNotifications(s, now()).notifications).toEqual([]);
  });
  it("includes insurance, PUC, warranty and custom dates but excludes archived vehicles", () => {
    const s = fixture();
    s.maintenanceRules = [];
    s.renewals = ["Insurance", "PUC", "Warranty", "Custom"].map((type, index) =>
      entrySchema.parse({
        id: `renewal-${index}`,
        vehicleId: s.vehicles[0].id,
        title: type,
        date: "2026-10-01",
        dueDate: "2026-11-20",
        renewalType: type,
        warningDays: 10,
      }),
    );
    expect(planNotifications(s, now()).notifications).toHaveLength(8);
    s.vehicles[0].archived = true;
    expect(planNotifications(s, now()).notifications).toHaveLength(0);
  });
  it("limits pending events and prioritizes the nearest dates", () => {
    const s = fixture();
    s.maintenanceRules = [];
    s.renewals = Array.from({ length: 40 }, (_, i) =>
      entrySchema.parse({
        id: `r-${i}`,
        vehicleId: s.vehicles[0].id,
        title: "Expiry",
        date: "2026-10-01",
        dueDate: "2026-11-30",
        warningDays: 10,
      }),
    );
    const plan = planNotifications(s, now());
    expect(plan.notifications).toHaveLength(MAX_SCHEDULED_REMINDERS);
    expect(plan.omitted).toBe(20);
  });
  it("never asks permission from automatic scheduling and respects denial", async () => {
    const plugin = port("denied");
    const service = createNotificationService(plugin, native);
    const result = await service.sync(fixture(), now());
    expect(result.scheduled).toBe(0);
    expect(plugin.schedule).not.toHaveBeenCalled();
    expect(plugin.requestPermissions).not.toHaveBeenCalled();
    await service.requestPermission();
    expect(plugin.requestPermissions).toHaveBeenCalledOnce();
  });
  it("does not duplicate schedules on repeat or concurrent resyncs", async () => {
    const plugin = port();
    const service = createNotificationService(plugin, native),
      s = fixture();
    await Promise.all([service.sync(s, now()), service.sync(s, now())]);
    expect(plugin.schedule).toHaveBeenCalledOnce();
  });
  it("cancels deleted or disabled records and reschedules changed/completed dates", async () => {
    const plugin = port(),
      service = createNotificationService(plugin, native);
    const s = fixture();
    await service.sync(s, now());
    s.maintenanceRules[0].lastCompletedDate = "2026-10-09";
    s.maintenanceRules[0].lastCompletedOdometer = s.vehicles[0].odometer;
    await service.sync(s, now());
    expect(plugin.cancel).toHaveBeenCalledOnce();
    expect(plugin.schedule).toHaveBeenCalledTimes(2);
    s.settings.nativeRemindersEnabled = false;
    await service.sync(s, now());
    expect(plugin.cancel).toHaveBeenCalledTimes(2);
    expect((await plugin.getPending()).notifications).toEqual([]);
  });
  it("returns errors without discarding business records", async () => {
    const plugin = port();
    vi.mocked(plugin.schedule).mockRejectedValue(
      new Error("OS refused scheduling"),
    );
    const s = fixture(),
      before = structuredClone(s);
    const result = await createNotificationService(plugin, native).sync(
      s,
      now(),
    );
    expect(result.error).toContain("OS refused");
    expect(s).toEqual(before);
  });
  it("retains the web fallback and avoids all device calls", async () => {
    const plugin = port(),
      web = createPlatform({
        getPlatform: () => "web",
        isNativePlatform: () => false,
        isPluginAvailable: () => true,
      });
    const result = await createNotificationService(plugin, web).sync(
      fixture(),
      now(),
    );
    expect(result.permission).toBe("web");
    expect(plugin.checkPermissions).not.toHaveBeenCalled();
    expect(plugin.schedule).not.toHaveBeenCalled();
  });
});
