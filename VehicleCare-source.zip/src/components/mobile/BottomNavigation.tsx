import { NavLink } from "react-router-dom";
import { House, Car, Plus, Bell, Ellipsis } from "lucide-react";
import { copy } from "../../lib/i18n";
export function BottomNavigation({ onAdd }: { onAdd: () => void }) {
  return (
    <nav className="mobile-nav" aria-label={copy("Mobile navigation")}>
      <NavLink
        className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
        to="/dashboard"
      >
        <House size={21} />
        <span>{copy("Home")}</span>
      </NavLink>
      <NavLink
        className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
        to="/garage"
      >
        <Car size={21} />
        <span>{copy("Garage")}</span>
      </NavLink>
      <button
        className="nav-item central-add"
        aria-label={copy("Add")}
        onClick={onAdd}
      >
        <span className="add-circle">
          <Plus size={26} />
        </span>
        <span>{copy("Add")}</span>
      </button>
      <NavLink
        className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
        to="/reminders"
      >
        <Bell size={21} />
        <span>{copy("Reminders")}</span>
      </NavLink>
      <NavLink
        className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
        to="/more"
      >
        <Ellipsis size={21} />
        <span>{copy("More")}</span>
      </NavLink>
    </nav>
  );
}
