import { useState } from "react";
import { Link } from "react-router-dom";
import { Car, Fuel, Zap, Wrench, Wallet, Route, Gauge } from "lucide-react";
import { useApp } from "../../lib/store";
import { type Collection } from "../../lib/model";
import { displayToKm, kmToDisplay } from "../../lib/calculations";
import { copy } from "../../lib/i18n";
import { useT } from "../shared";
import { Dialog } from "../ui/dialog";
import { Button } from "../ui/button";
import { RecordForm } from "../../features/records/RecordForm";
import { configs } from "../../features/records/config";
export function QuickActionSheet({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [kind, setKind] = useState<Collection | "odometer" | null>(null);
  const data = useApp((s) => s.data);
  const t = useT();
  const close = () => {
    setKind(null);
    onOpenChange(false);
  };
  const actions: [Collection, string, typeof Car][] = [
    ["fuelLogs", "Add Fuel", Fuel],
    ["chargingLogs", "Add Charging Session", Zap],
    ["services", "Add Service", Wrench],
    ["expenses", "Add Expense", Wallet],
    ["trips", "Add Trip", Route],
  ];
  return (
    <Dialog
      open={open}
      onOpenChange={(value) => {
        if (!value) close();
        else onOpenChange(value);
      }}
      sheet
      title={
        kind === "odometer"
          ? copy("Update Odometer")
          : kind
            ? `${copy("Add")} ${copy(configs[kind].singular.toLowerCase())}`
            : t("quickAdd")
      }
      wide={!!kind}
    >
      {kind === "odometer" ? (
        <OdometerForm onDone={close} />
      ) : kind ? (
        <RecordForm kind={kind} onDone={close} />
      ) : (
        <>
          <p className="form-note">
            {data.vehicles.some((v) => !v.archived)
              ? copy("Choose an action. You can select a vehicle in the form.")
              : copy("Add your first vehicle to unlock tracking actions.")}
          </p>
          <div className="quick-grid">
            <Link to="/garage/new" onClick={close}>
              <Car size={23} />
              <span>{t("addVehicle")}</span>
            </Link>
            {actions.map(([key, title, Icon]) => (
              <button
                key={key}
                disabled={!data.vehicles.some((v) => !v.archived)}
                onClick={() => setKind(key)}
              >
                <Icon size={23} />
                <span>{copy(title)}</span>
              </button>
            ))}
            <button
              disabled={!data.vehicles.some((v) => !v.archived)}
              onClick={() => setKind("odometer")}
            >
              <Gauge size={23} />
              <span>{copy("Update Odometer")}</span>
            </button>
          </div>
        </>
      )}
    </Dialog>
  );
}
function OdometerForm({ onDone }: { onDone: () => void }) {
  const { data, saveVehicle } = useApp();
  const vehicles = data.vehicles.filter((v) => !v.archived);
  const selected = data.settings.selectedVehicleId || vehicles[0]?.id || "";
  const [vehicleId, setVehicleId] = useState(selected);
  const [reading, setReading] = useState(
    String(
      kmToDisplay(
        vehicles.find((v) => v.id === selected)?.odometer ?? 0,
        data.settings.distanceUnit,
      ),
    ),
  );
  const [error, setError] = useState("");
  const [correction, setCorrection] = useState(false);
  const t = useT();
  return (
    <form
      className="form-grid"
      onSubmit={(e) => {
        e.preventDefault();
        const vehicle = vehicles.find((v) => v.id === vehicleId);
        if (!vehicle) return;
        const odometer = displayToKm(
          Number(reading),
          data.settings.distanceUnit,
        );
        if (saveVehicle({ ...vehicle, odometer }, correction)) onDone();
        else setError(useApp.getState().error ?? "Could not update reading");
      }}
    >
      <div className="field field-full">
        <label htmlFor="quick-vehicle">{t("vehicle")}</label>
        <select
          id="quick-vehicle"
          value={vehicleId}
          onChange={(e) => {
            setVehicleId(e.target.value);
            setReading(
              String(
                kmToDisplay(
                  vehicles.find((v) => v.id === e.target.value)!.odometer,
                  data.settings.distanceUnit,
                ),
              ),
            );
            setCorrection(false);
          }}
        >
          {vehicles.map((v) => (
            <option key={v.id} value={v.id}>
              {v.name}
            </option>
          ))}
        </select>
      </div>
      <div className="field field-full">
        <label htmlFor="quick-odometer">
          {t("odometer")} ({data.settings.distanceUnit})
        </label>
        <input
          id="quick-odometer"
          type="number"
          inputMode="decimal"
          min="0"
          step="any"
          required
          value={reading}
          onChange={(e) => setReading(e.target.value)}
        />
      </div>
      <label className="checkbox-row field-full">
        <input
          type="checkbox"
          checked={correction}
          onChange={(e) => setCorrection(e.target.checked)}
        />
        {copy(
          "I am correcting an incorrect current reading. A lower value than recorded history will be rejected.",
        )}
      </label>
      {error && (
        <p className="field-error field-full" role="alert">
          {error}
        </p>
      )}
      <div className="dialog-actions field-full">
        <Button type="button" variant="outline" onClick={onDone}>
          {t("cancel")}
        </Button>
        <Button type="submit">{t("save")}</Button>
      </div>
    </form>
  );
}
