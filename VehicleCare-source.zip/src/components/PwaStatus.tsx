import { useRegisterSW } from "virtual:pwa-register/react";
import { ShieldCheck, RefreshCw, X } from "lucide-react";
import { copy } from "../lib/i18n";
import { useApp } from "../lib/store";
import { Button } from "./ui/button";
export function PwaStatus() {
  const dirty = useApp((s) => s.dirty);
  const {
    needRefresh: [needRefresh, setNeedRefresh],
    offlineReady: [offlineReady, setOfflineReady],
    updateServiceWorker,
  } = useRegisterSW();
  if (!needRefresh && !offlineReady) return null;
  return (
    <div className="pwa-toast" role="status">
      <ShieldCheck size={21} />
      <div>
        <strong>
          {copy(
            needRefresh ? "A fresh version is ready" : "Ready to go offline",
          )}
        </strong>
        <p>
          {copy(
            needRefresh
              ? "Saved vehicle records are kept when the app updates."
              : "The app shell is cached on this device.",
          )}
        </p>
      </div>
      {needRefresh && (
        <Button
          size="sm"
          disabled={dirty}
          onClick={() => {
            void updateServiceWorker(true);
          }}
        >
          <RefreshCw size={14} />
          {copy("Update")}
        </Button>
      )}
      <button
        className="icon-button"
        aria-label={copy("Dismiss update notice")}
        onClick={() => {
          setNeedRefresh(false);
          setOfflineReady(false);
        }}
      >
        <X size={18} />
      </button>
    </div>
  );
}
