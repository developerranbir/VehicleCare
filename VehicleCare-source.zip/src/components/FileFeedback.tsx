import { useEffect, useState } from "react";
import { X, Download, AlertTriangle } from "lucide-react";
import { copy } from "../lib/i18n";
import type { ExportResult } from "../platform/fileService";
export function FileFeedback() {
  const [result, setResult] = useState<ExportResult | { error: string } | null>(
    null,
  );
  useEffect(() => {
    const receive = (event: Event) =>
      setResult(
        (event as CustomEvent<ExportResult | { error: string }>).detail,
      );
    window.addEventListener("vehiclecare:file-result", receive);
    return () => window.removeEventListener("vehiclecare:file-result", receive);
  }, []);
  if (!result) return null;
  const error = "error" in result;
  return (
    <div
      className={`pwa-toast file-feedback ${error ? "export-error" : ""}`}
      role={error ? "alert" : "status"}
    >
      {error ? <AlertTriangle size={22} /> : <Download size={22} />}
      <p>{copy(error ? result.error : result.message)}</p>
      <button
        className="icon-button"
        aria-label={copy("Close")}
        onClick={() => setResult(null)}
      >
        <X size={20} />
      </button>
    </div>
  );
}
