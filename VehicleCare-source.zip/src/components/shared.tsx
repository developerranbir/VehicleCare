import { copy } from "../lib/i18n";
import {
  Car,
  Bike,
  ArrowUpRight,
  Plus,
  CircleCheck,
  Inbox,
} from "lucide-react";
import { Link } from "react-router-dom";
import type { ReactNode } from "react";
import { useApp } from "../lib/store";
import { labels, type Label } from "../lib/i18n";
import { formatDistance } from "../lib/calculations";
import { type Vehicle } from "../lib/model";
import { Button } from "./ui/button";
export function useT() {
  const language = useApp((s) => s.data.settings.language);
  return (key: Label) => labels[language][key];
}
export function PageHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {action}
    </div>
  );
}
export function Empty({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty">
      <span className="empty-icon">
        <Inbox size={30} />
      </span>
      <h3>{copy(title)}</h3>
      <p>{copy(description)}</p>
      {action}
    </div>
  );
}
export function Badge({ status }: { status: string }) {
  const t = useT();
  const key =
    status === "On track"
      ? "onTrack"
      : status === "Upcoming"
        ? "upcoming"
        : status === "Overdue"
          ? "overdue"
          : undefined;
  return (
    <span
      className={`badge ${status === "Overdue" || status === "Attention" ? "badge-red" : status === "Upcoming" || status === "Unchecked" ? "badge-amber" : "badge-teal"}`}
    >
      <span />
      {key ? t(key) : copy(status)}
    </span>
  );
}
export function VehicleArt({ vehicle }: { vehicle: Vehicle }) {
  const scooter = vehicle.type === "Scooter" || vehicle.type === "Motorcycle";
  return (
    <div className={`vehicle-art art-${vehicle.color}`} aria-hidden="true">
      <svg viewBox="0 0 420 160">
        {scooter ? (
          <>
            <ellipse
              cx="216"
              cy="138"
              rx="127"
              ry="8"
              fill="currentColor"
              opacity=".08"
            />
            <circle cx="123" cy="115" r="27" fill="#243746" />
            <circle cx="312" cy="115" r="27" fill="#243746" />
            <circle cx="123" cy="115" r="14" fill="#cbd5df" />
            <circle cx="312" cy="115" r="14" fill="#cbd5df" />
            <path
              d="M117 94q20-33 56-21l29 26h55l-6-46 38-6 22 56-37 17H156z"
              fill="currentColor"
            />
            <path d="M177 72h-35q-11-2-7-13h56q18 0 23 13z" fill="#253a45" />
            <path
              d="m252 53-7-25h29"
              stroke="#253a45"
              strokeWidth="9"
              strokeLinecap="round"
            />
            <path d="M260 38h22l9 16h-37z" fill="currentColor" />
            <path d="M184 93h37" stroke="white" strokeWidth="4" opacity=".65" />
          </>
        ) : (
          <>
            <ellipse
              cx="211"
              cy="143"
              rx="167"
              ry="9"
              fill="#243746"
              opacity=".09"
            />
            <path
              d="m51 92 29-15 40-45q12-12 32-12h99q20 0 40 18l42 37 34 13q13 5 14 19v24H46v-24q0-10 5-15z"
              fill="currentColor"
            />
            <path
              d="m105 76 33-38h44v38zm87-38h50q14 0 27 13l27 25H192z"
              fill="#253a45"
              opacity=".85"
            />
            <path d="M58 103h28l-7-15H59zm288-14-9 17h30V94z" fill="#e6f5f6" />
            <path
              d="M155 91h19m54 0h19"
              stroke="#253a45"
              strokeWidth="5"
              strokeLinecap="round"
              opacity=".45"
            />
            <path d="M49 126h328" stroke="#253a45" strokeWidth="9" />
            <circle cx="113" cy="128" r="27" fill="#25333d" />
            <circle cx="309" cy="128" r="27" fill="#25333d" />
            <circle cx="113" cy="128" r="15" fill="#dae4e9" />
            <circle cx="309" cy="128" r="15" fill="#dae4e9" />
            <circle cx="113" cy="128" r="6" fill="#5c7580" />
            <circle cx="309" cy="128" r="6" fill="#5c7580" />
          </>
        )}
      </svg>
    </div>
  );
}
export function VehicleCard({ vehicle }: { vehicle: Vehicle }) {
  const settings = useApp((s) => s.data.settings);
  const t = useT();
  return (
    <Link className="vehicle-card" to={`/garage/${vehicle.id}`}>
      <div className="vehicle-card-top">
        <span className={`vehicle-icon art-${vehicle.color}`}>
          {vehicle.type === "Car" ? <Car size={19} /> : <Bike size={19} />}
        </span>
        <span className="small muted">{copy(vehicle.fuelType)}</span>
        <ArrowUpRight size={18} className="muted" />
      </div>
      <VehicleArt vehicle={vehicle} />
      <div className="vehicle-card-name">
        <h3>{vehicle.name}</h3>
        <span className="registration">{vehicle.registration || "—"}</span>
      </div>
      <div className="vehicle-card-footer">
        <span>
          <span className="small muted">{t("odometer")}</span>
          <strong>{formatDistance(vehicle.odometer, settings)}</strong>
        </span>
        <span className="small vehicle-state">
          <CircleCheck size={14} />
          {vehicle.archived ? t("archived") : t("active")}
        </span>
      </div>
    </Link>
  );
}
export function AddVehicleCard() {
  const t = useT();
  return (
    <Link className="add-vehicle-card" to="/garage/new">
      <span>
        <Plus size={26} />
      </span>
      <strong>{t("addVehicle")}</strong>
      <p>{copy("Make room for your next journey")}</p>
    </Link>
  );
}
export function Confirm({
  title,
  description,
  confirmLabel = "Confirm",
  onConfirm,
  onCancel,
}: {
  title: string;
  description: string;
  confirmLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <>
      <h3>{copy(title)}</h3>
      <p className="muted">{copy(description)}</p>
      <div className="dialog-actions">
        <Button variant="outline" onClick={onCancel}>
          {copy("Cancel")}
        </Button>
        <Button variant="destructive" onClick={onConfirm}>
          {copy(confirmLabel)}
        </Button>
      </div>
    </>
  );
}
