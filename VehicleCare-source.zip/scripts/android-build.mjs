import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
const task = process.argv[2];
if (!["assembleDebug", "assembleRelease", "bundleRelease"].includes(task)) {
  console.error("Use assembleDebug, assembleRelease or bundleRelease.");
  process.exit(1);
}
const android = path.resolve("android");
const java = process.env.JAVA_HOME
  ? path.join(
      process.env.JAVA_HOME,
      "bin",
      process.platform === "win32" ? "java.exe" : "java",
    )
  : "java";
const version = spawnSync(java, ["-version"], { encoding: "utf8" });
if (version.error || version.status !== 0) {
  console.error(
    "Android build not performed: install JDK 21 and set JAVA_HOME. See ANDROID_BUILD.md.",
  );
  process.exit(1);
}
const output = version.stderr + version.stdout;
const major = Number(output.match(/version "?(\d+)/)?.[1] ?? 0);
if (major < 21) {
  console.error("Android build not performed: JDK 21 or newer is required.");
  process.exit(1);
}
const sdk = process.env.ANDROID_HOME ?? process.env.ANDROID_SDK_ROOT;
const local = path.join(android, "local.properties");
if ((!sdk || !fs.existsSync(sdk)) && !fs.existsSync(local)) {
  console.error(
    "Android build not performed: configure Android SDK 36 using ANDROID_HOME or Android Studio local.properties.",
  );
  process.exit(1);
}
const wrapper = process.platform === "win32" ? "gradlew.bat" : "./gradlew";
const result = spawnSync(wrapper, [task], {
  cwd: android,
  stdio: "inherit",
  shell: process.platform === "win32",
});
if (result.error) {
  console.error("Gradle could not start. Check your native toolchain.");
  process.exit(1);
}
process.exit(result.status ?? 1);
