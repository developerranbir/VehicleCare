import { readFileSync, writeFileSync } from "node:fs";
const manifest = JSON.parse(readFileSync("package.json", "utf8"));
for (const group of ["dependencies", "devDependencies"])
  for (const name of Object.keys(manifest[group])) {
    manifest[group][name] = JSON.parse(
      readFileSync(`node_modules/${name}/package.json`, "utf8"),
    ).version;
  }
manifest.packageManager = "pnpm@11.25.0";
manifest.engines = { node: ">=22.12.0" };
writeFileSync("package.json", JSON.stringify(manifest, null, 2) + "\n");
