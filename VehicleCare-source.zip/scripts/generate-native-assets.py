"""Generate native brand assets from the same original vector geometry as icon.svg."""
from pathlib import Path
import json
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
def icon(size, transparent=False):
    image = Image.new('RGBA', (1024,1024), (0,0,0,0) if transparent else '#0D9488')
    draw = ImageDraw.Draw(image)
    def points(values): return [(x*2,y*2) for x,y in values]
    draw.polygon(points([(117,273),(152,172),(360,172),(395,273),(395,354),(355,354),(355,329),(157,329),(157,354),(117,354)]),fill='white')
    cutout=(0,0,0,0) if transparent else '#0D9488'
    draw.polygon(points([(170,204),(147,267),(365,267),(342,204)]),fill=cutout)
    for x in (169,342): draw.ellipse(((x-16)*2,574,(x+16)*2,638),fill=cutout)
    return image.resize((size,size),Image.Resampling.LANCZOS)

def splash(size,dark=False):
    image=Image.new('RGB',size,'#0F172A' if dark else '#F8FAFC')
    width=max(64,int(min(size)*0.19))
    badge=icon(width)
    mask=Image.new('L',(width,width));ImageDraw.Draw(mask).rounded_rectangle((0,0,width-1,width-1),radius=width//5,fill=255)
    image.paste(badge,(int((size[0]-width)/2),int((size[1]-width)/2)),mask)
    return image

android=ROOT/'android/app/src/main/res'
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    directory=android/f'mipmap-{density}';directory.mkdir(parents=True,exist_ok=True)
    icon(size).convert('RGB').save(directory/'ic_launcher.png')
    round_icon=icon(size);mask=Image.new('L',(size,size));ImageDraw.Draw(mask).ellipse((0,0,size-1,size-1),fill=255);round_icon.putalpha(mask);round_icon.save(directory/'ic_launcher_round.png')
    icon(int(size*108/48),True).save(directory/'ic_launcher_foreground.png')

for file in list(android.glob('drawable*/splash.png')):
    if '-night' in file.parent.name: continue
    with Image.open(file) as existing: size=existing.size
    splash(size).save(file)
    qualifiers=file.parent.name.split('-')
    if qualifiers[-1].endswith('dpi'): qualifiers.insert(len(qualifiers)-1,'night')
    else: qualifiers.append('night')
    night=android/'-'.join(qualifiers);night.mkdir(exist_ok=True);splash(size,True).save(night/'splash.png')

assets=ROOT/'ios/App/App/Assets.xcassets'
icon(1024).convert('RGB').save(assets/'AppIcon.appiconset/AppIcon-512@2x.png')
images=[]
for scale,name in [('1x','splash-2732x2732-2.png'),('2x','splash-2732x2732-1.png'),('3x','splash-2732x2732.png')]:
    splash((2732,2732)).save(assets/'Splash.imageset'/name)
    images.append({'idiom':'universal','filename':name,'scale':scale})
    dark_name=f'vehiclecare-dark-{scale}.png';splash((2732,2732),True).save(assets/'Splash.imageset'/dark_name)
    images.append({'idiom':'universal','filename':dark_name,'scale':scale,'appearances':[{'appearance':'luminosity','value':'dark'}]})
(assets/'Splash.imageset/Contents.json').write_text(json.dumps({'images':images,'info':{'version':1,'author':'xcode'}},indent=2)+'\n')
print('Generated Android launcher/adaptive/splash assets and iOS icon/light/dark splash assets.')
