import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
const cliRequire = createRequire(
  fs.realpathSync("node_modules/@capacitor/cli/package.json"),
);
const platforms = process.argv[2] ? [process.argv[2]] : ["android", "ios"];
const appId = fs
  .readFileSync("capacitor.config.ts", "utf8")
  .match(/appId:\s*["']([^"']+)["']/)?.[1];
const required = [
  "app",
  "filesystem",
  "keyboard",
  "local-notifications",
  "share",
  "splash-screen",
  "status-bar",
];
let failures = 0;
function check(condition, message) {
  if (!condition) {
    failures++;
    console.error(`FAIL: ${message}`);
  }
}
for (const name of ["core", "cli", "android", "ios", ...required]) {
  const meta = JSON.parse(
    fs.readFileSync(`node_modules/@capacitor/${name}/package.json`, "utf8"),
  );
  check(
    meta.version.startsWith("8."),
    `@capacitor/${name} major must match Capacitor 8`,
  );
}
for (const platform of platforms) {
  const root =
    platform === "android" ? "android/app/src/main/assets" : "ios/App/App";
  const config = JSON.parse(
    fs.readFileSync(path.join(root, "capacitor.config.json"), "utf8"),
  );
  check(
    config.appId === appId &&
      /^[a-zA-Z]\w*(\.[a-zA-Z]\w*){2,}$/.test(appId ?? ""),
    "Native app ID matches Capacitor configuration",
  );
  check(config.appName === "VehicleCare", "Native app display name");
  check(!config.server?.url, "No production live reload URL");
  check(
    config.server?.hostname === "localhost",
    "Stable native storage origin",
  );
  check(config.server?.cleartext === false, "Cleartext disabled");
  check(
    fs.existsSync(path.join(root, "public/index.html")),
    `${platform} embedded app shell`,
  );
  check(
    !fs.existsSync(path.join(root, "public/sw.js")),
    `${platform} assets must use the native build without a web service worker`,
  );
  for (const name of required) {
    const file =
      platform === "android"
        ? "android/capacitor.settings.gradle"
        : "ios/App/CapApp-SPM/Package.swift";
    check(
      fs.readFileSync(file, "utf8").includes(`@capacitor/${name}`) ||
        fs.readFileSync(file, "utf8").includes(`@capacitor+${name}`),
      `${platform} links ${name}`,
    );
  }
  if (platform === "android") {
    check(
      fs
        .readFileSync("android/app/build.gradle", "utf8")
        .includes(`applicationId "${appId}"`),
      "Android application ID matches configuration",
    );
    const xml = fs.readFileSync(
      "android/app/src/main/AndroidManifest.xml",
      "utf8",
    );
    check(
      xml.includes('android:allowBackup="false"'),
      "Android automatic backups disabled",
    );
    check(
      xml.includes('android:usesCleartextTraffic="false"'),
      "Android cleartext disabled",
    );
    for (const permission of [
      "INTERNET",
      "SCHEDULE_EXACT_ALARM",
      "USE_EXACT_ALARM",
      "READ_EXTERNAL_STORAGE",
      "WRITE_EXTERNAL_STORAGE",
    ])
      check(
        xml.includes(`android.permission.${permission}" tools:node="remove"`),
        `${permission} is removed from merged permissions`,
      );
    check(
      fs.existsSync(
        "android/app/src/main/res/drawable/ic_stat_vehiclecare.xml",
      ),
      "Notification icon exists",
    );
    check(
      fs
        .readFileSync("android/variables.gradle", "utf8")
        .includes("targetSdkVersion = 36"),
      "Android target 36",
    );
  } else {
    try {
      const parsed = cliRequire("xcode").project(
        "ios/App/App.xcodeproj/project.pbxproj",
      );
      parsed.parseSync();
      const objects = parsed.hash.project.objects;
      check(
        Object.values(objects.PBXResourcesBuildPhase).some((phase) =>
          phase.files?.some(
            (file) =>
              objects.PBXBuildFile[file.value]?.fileRef_comment ===
              "PrivacyInfo.xcprivacy",
          ),
        ),
        "Parsed iOS project bundles the privacy manifest",
      );
      const privacy = cliRequire("plist").parse(
        fs.readFileSync("ios/App/App/PrivacyInfo.xcprivacy", "utf8"),
      );
      check(
        privacy.NSPrivacyTracking === false &&
          privacy.NSPrivacyCollectedDataTypes?.length === 0,
        "iOS privacy declarations have no tracking/collection",
      );
      const info = cliRequire("plist").parse(
        fs.readFileSync("ios/App/App/Info.plist", "utf8"),
      );
      check(info.CFBundleDisplayName === "VehicleCare", "iOS display name");
    } catch (error) {
      check(false, `iOS project/plist parse: ${error.message}`);
    }
    const project = fs.readFileSync(
      "ios/App/App.xcodeproj/project.pbxproj",
      "utf8",
    );
    check(
      project.includes(`PRODUCT_BUNDLE_IDENTIFIER = ${appId};`),
      "iOS bundle identifier matches configuration",
    );
    check(
      project.includes("PrivacyInfo.xcprivacy in Resources"),
      "iOS privacy manifest is bundled",
    );
    check(
      fs.existsSync("ios/App/App/PrivacyInfo.xcprivacy"),
      "iOS privacy manifest exists",
    );
    check(
      !fs
        .readFileSync("ios/App/App/Info.plist", "utf8")
        .includes("NSAllowsArbitraryLoads"),
      "iOS insecure transport not enabled",
    );
  }
}
if (failures) {
  console.error(`${failures} native source checks failed.`);
  process.exit(1);
}
console.log(
  `Native source/configuration checks passed (${platforms.join(", ")}). This does not build or verify an APK/AAB/IPA or device runtime.`,
);
