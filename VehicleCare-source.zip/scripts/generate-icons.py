from PIL import Image, ImageDraw
from pathlib import Path

root = Path(__file__).resolve().parent.parent / 'public'
for size in (192, 512):
    image = Image.new('RGB', (512, 512), '#0d9488')
    d = ImageDraw.Draw(image)
    d.polygon([(117, 273), (152, 172), (360, 172), (395, 273), (395, 354), (355, 354), (355, 329), (157, 329), (157, 354), (117, 354)], fill='white')
    d.polygon([(170, 204), (147, 267), (365, 267), (342, 204)], fill='#0d9488')
    for x in (169, 342):
        d.ellipse((x-16, 287, x+16, 319), fill='#0d9488')
    image.resize((size, size), Image.Resampling.LANCZOS).save(root / f'icon-{size}.png')
