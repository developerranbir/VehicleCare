import { chromium } from "@playwright/test";
import { mkdir } from "node:fs/promises";
const browser = await chromium.launch({ channel: "chrome", headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 1200 } });
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));
await mkdir("artifacts", { recursive: true });
await page.goto("http://127.0.0.1:4173");
await page.getByRole("heading", { name: "Your vehicle. Your care." }).waitFor();
await page.evaluate(() => document.fonts.ready);
await page.screenshot({
  path: "artifacts/welcome-desktop.png",
  fullPage: true,
});
await page.getByRole("button", { name: "Explore with demo data" }).click();
await page
  .getByRole("heading", { name: "A little care. A better journey." })
  .waitFor();
await page.evaluate(async () => {
  await navigator.serviceWorker.ready;
});
if (
  await page.getByRole("button", { name: "Dismiss update notice" }).isVisible()
)
  await page.getByRole("button", { name: "Dismiss update notice" }).click();
await page.screenshot({
  path: "artifacts/dashboard-desktop.png",
  fullPage: true,
  animations: "disabled",
});
await page.setViewportSize({ width: 390, height: 844 });
await page.screenshot({
  path: "artifacts/dashboard-mobile.png",
  fullPage: true,
  animations: "disabled",
});
await page.goto("http://127.0.0.1:4173/settings");
await page.getByRole("button", { name: "Dark", exact: true }).click();
await page.goto("http://127.0.0.1:4173/dashboard");
await page
  .getByRole("heading", { name: "A little care. A better journey." })
  .waitFor();
await page.screenshot({
  path: "artifacts/dashboard-dark-mobile.png",
  fullPage: true,
  animations: "disabled",
});
await page.setViewportSize({ width: 1440, height: 1000 });
await page.screenshot({
  path: "artifacts/dashboard-dark-desktop.png",
  fullPage: true,
  animations: "disabled",
});
await page.goto("http://127.0.0.1:4173/reports");
await page.getByRole("heading", { name: "Reports", exact: true }).waitFor();
await page.screenshot({
  path: "artifacts/reports-dark-desktop.png",
  fullPage: true,
  animations: "disabled",
});
await page.goto("http://127.0.0.1:4173/settings");
await page.getByLabel("Language", { exact: true }).selectOption("hi");
await page.goto("http://127.0.0.1:4173/dashboard");
await page.getByRole("heading", { name: "थोड़ी देखभाल। बेहतर सफर।" }).waitFor();
await page.screenshot({
  path: "artifacts/dashboard-hindi-desktop.png",
  fullPage: true,
  animations: "disabled",
});
await page.setViewportSize({ width: 375, height: 812 });
await page.goto("http://127.0.0.1:4173/more");
await page.getByRole("heading", { name: "और", exact: true }).waitFor();
await page.screenshot({
  path: "artifacts/more-hindi-mobile.png",
  fullPage: true,
  animations: "disabled",
});
await page.goto("http://127.0.0.1:4173/settings");
await page.getByLabel("भाषा", { exact: true }).selectOption("en");
await page.getByRole("button", { name: "Light", exact: true }).click();
await page.setViewportSize({ width: 320, height: 700 });
await page.goto("http://127.0.0.1:4173/settings/backup");
await page
  .getByRole("heading", { name: "Backup & restore", exact: true })
  .waitFor();
await page.screenshot({
  path: "artifacts/backup-320.png",
  fullPage: true,
  animations: "disabled",
});
await page
  .getByRole("navigation", { name: "Mobile navigation" })
  .getByRole("button", { name: "Add", exact: true })
  .click();
await page.getByRole("dialog").waitFor();
await page.screenshot({
  path: "artifacts/add-sheet-320.png",
  animations: "disabled",
});
console.log(JSON.stringify({ pageErrors: errors }));
await browser.close();
