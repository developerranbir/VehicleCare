"""Package source and the verified web build; never include private build/signing files."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent.parent
DIRECTORIES = ('src', 'public', 'scripts', 'e2e', 'android', 'ios')
FILES = ('package.json', 'pnpm-lock.yaml', 'vehiclecare.cmd', 'capacitor.config.ts',
         'vite.config.ts', 'playwright.config.ts', 'tsconfig.json', 'eslint.config.js',
         'components.json', 'vercel.json', 'index.html', '.gitignore', 'README.md',
         'QUALITY.md', 'MOBILE_SETUP.md', 'ANDROID_BUILD.md', 'IOS_BUILD.md',
         'RELEASE_CHECKLIST.md')
EXCLUDE_PARTS = {'node_modules', '.gradle', 'build', 'DerivedData', 'xcuserdata',
                 '__pycache__', '.git', '.idea'}
EXCLUDE_NAMES = {'local.properties', 'gradle.properties.local', '.DS_Store'}
EXCLUDE_EXTENSIONS = {'.jks', '.keystore', '.p12', '.mobileprovision', '.ipa', '.apk', '.aab', '.pyc'}

def allowed(file):
    relative = file.relative_to(ROOT)
    if not file.is_file() or file.is_symlink() or not file.resolve().is_relative_to(ROOT):
        return False
    if EXCLUDE_PARTS.intersection(relative.parts) or file.name in EXCLUDE_NAMES:
        return False
    if file.name.startswith('.env') or file.suffix in EXCLUDE_EXTENSIONS:
        return False
    if file.name == 'gradle.properties':
        text = file.read_text(encoding='utf-8').lower()
        if 'vehiclecarestorepassword' in text or 'vehiclecarekeypassword' in text:
            return False
    return True

def archive(name, entries):
    target = ROOT / name
    assert target.resolve().parent == ROOT
    with ZipFile(target, 'w', ZIP_DEFLATED) as output:
        for file, relative in entries:
            output.write(file, relative.as_posix())
    with ZipFile(target) as output:
        assert output.testzip() is None
        print(f'{name}: {len(output.namelist())} files, {target.stat().st_size:,} bytes; ZIP integrity passed')

source = [(ROOT / name, Path(name)) for name in FILES if (ROOT / name).is_file()]
for name in DIRECTORIES:
    source.extend((file, file.relative_to(ROOT)) for file in sorted((ROOT / name).rglob('*')) if allowed(file))
archive('VehicleCare-source.zip', source)
assert (ROOT / 'dist/sw.js').is_file(), 'Run the WEB build before creating the static package'
archive('VehicleCare-static.zip', [(file, file.relative_to(ROOT / 'dist')) for file in sorted((ROOT / 'dist').rglob('*')) if file.is_file()])
