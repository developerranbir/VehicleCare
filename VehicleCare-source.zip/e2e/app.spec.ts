import { test, expect, type Page } from "@playwright/test";
import { demoSnapshot } from "../src/lib/demo";
import { STORAGE_KEY } from "../src/lib/model";
const demo = async (page: Page) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Explore with demo data" }).click();
  await expect(
    page.getByRole("heading", { name: "A little care. A better journey." }),
  ).toBeVisible();
};
test("completes a maintenance schedule and records service cost once", async ({
  page,
}) => {
  await demo(page);
  await page.goto("/maintenance");
  await page
    .getByRole("button", { name: "Complete", exact: true })
    .first()
    .click();
  await page.getByLabel("Parts cost (INR)").fill("1000");
  await page.getByLabel("Labour cost (INR)").fill("500");
  await page.getByRole("button", { name: "Save", exact: true }).click();
  const saved = await page.evaluate(
    (key) => JSON.parse(localStorage.getItem(key)!),
    STORAGE_KEY,
  );
  expect(saved.services.at(-1).partsCost).toBe(100000);
  expect(saved.services.at(-1).labourCost).toBe(50000);
  expect(
    saved.maintenanceRules.some(
      (r: { lastCompletedDate?: string }) => !!r.lastCompletedDate,
    ),
  ).toBe(true);
  await page.goto("/services");
  await expect(page.getByText("₹1,500.00", { exact: true })).toBeVisible();
});
test("full-data deletion requires confirmation and returns to onboarding", async ({
  page,
}) => {
  await demo(page);
  await page.goto("/settings");
  await page
    .getByRole("button", { name: "Delete all data", exact: true })
    .click();
  await page.getByRole("button", { name: "Cancel", exact: true }).click();
  expect(
    await page.evaluate(
      (key) => JSON.parse(localStorage.getItem(key)!).vehicles.length,
      STORAGE_KEY,
    ),
  ).toBe(2);
  await page
    .getByRole("button", { name: "Delete all data", exact: true })
    .click();
  await page.getByRole("button", { name: "Delete everything" }).click();
  await expect(
    page.getByRole("heading", { name: "Your vehicle. Your care." }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      (key) => JSON.parse(localStorage.getItem(key)!).vehicles.length,
      STORAGE_KEY,
    ),
  ).toBe(0);
});
test("system theme follows browser preference and explicit light overrides it", async ({
  page,
}) => {
  await page.emulateMedia({ colorScheme: "dark" });
  await demo(page);
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.goto("/settings");
  await page.getByRole("button", { name: "Light", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  await page.getByRole("button", { name: "System", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
});
test("quick-add is a mobile sheet and dialogs support keyboard dismissal", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await demo(page);
  await page
    .getByRole("navigation", { name: "Mobile navigation" })
    .getByRole("button", { name: "Add", exact: true })
    .click();
  await expect(page.getByRole("dialog")).toHaveClass(/dialog-sheet/);
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Add Fuel", exact: true })
    .click();
  await expect(page.getByLabel("Litres *")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).toHaveCount(0);
});
test("onboards and persists two independent vehicles across a reload", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Set up my garage" }).click();
  await page.getByRole("button", { name: "Add my first vehicle" }).click();
  await page.getByLabel("Name *", { exact: true }).fill("My Civic");
  await page.getByLabel("Make *", { exact: true }).fill("Honda");
  await page.getByLabel("Model *", { exact: true }).fill("Civic");
  await page.getByLabel("Current odometer (km) *").fill("12000");
  await page.getByRole("button", { name: "Add vehicle", exact: true }).click();
  await expect(page.getByRole("heading", { name: "My Civic" })).toBeVisible();
  await page.reload();
  await expect(page.getByRole("heading", { name: "My Civic" })).toBeVisible();
  await page.goto("/garage/new");
  await page.getByLabel("Name *", { exact: true }).fill("My scooter");
  await page.getByLabel("Make *", { exact: true }).fill("Honda");
  await page.getByLabel("Model *", { exact: true }).fill("Activa");
  await page.getByRole("button", { name: "Add vehicle", exact: true }).click();
  await page.goto("/garage");
  await expect(page.getByRole("heading", { name: "My Civic" })).toBeVisible();
  await expect(page.getByRole("heading", { name: "My scooter" })).toBeVisible();
});
test("creates, edits, and deletes a vehicle record with confirmation", async ({
  page,
}) => {
  await demo(page);
  await page.goto("/expenses");
  await page.getByRole("button", { name: "Add expense", exact: true }).click();
  await page.getByLabel("Title *", { exact: true }).fill("Test parking");
  await page.getByLabel("Cost (INR) *").fill("75");
  await page.getByRole("button", { name: "Save", exact: true }).click();
  await expect(page.getByText("Test parking", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Edit Test parking" }).click();
  await page.getByLabel("Cost (INR) *").fill("95");
  await page.getByRole("button", { name: "Save", exact: true }).click();
  await page.getByRole("button", { name: "Delete Test parking" }).click();
  await page.getByRole("button", { name: "Cancel", exact: true }).click();
  await expect(page.getByText("Test parking", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Delete Test parking" }).click();
  await page
    .getByRole("button", { name: "Delete record", exact: true })
    .click();
  await expect(page.getByText("Test parking", { exact: true })).toHaveCount(0);
});
test("archive and restore preserve vehicle records", async ({ page }) => {
  await demo(page);
  await page.goto("/garage");
  await page
    .getByRole("link")
    .filter({ has: page.getByRole("heading", { name: "Hyundai Creta" }) })
    .click();
  await page.getByRole("button", { name: "Archive vehicle" }).click();
  await page.getByRole("button", { name: "Confirm", exact: true }).click();
  await expect(
    page.getByText("Archived", { exact: true }).first(),
  ).toBeVisible();
  await page.getByRole("button", { name: "Restore vehicle" }).click();
  await page.getByRole("button", { name: "Confirm", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Archive vehicle" }),
  ).toBeVisible();
});
test("validates imports and supports complete export and merge preview", async ({
  page,
}) => {
  await demo(page);
  await page.goto("/settings/backup");
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Download JSON backup" }).click();
  expect((await download).suggestedFilename()).toMatch(/vehiclecare-backup/);
  await page.locator("#backup-file").setInputFiles({
    name: "bad.json",
    mimeType: "application/json",
    buffer: Buffer.from("{bad"),
  });
  await expect(page.getByRole("alert")).toContainText(
    "Existing data was not changed",
  );
  await page.locator("#backup-file").setInputFiles({
    name: "demo.json",
    mimeType: "application/json",
    buffer: Buffer.from(JSON.stringify(demoSnapshot())),
  });
  await expect(
    page.getByRole("heading", { name: "Import preview" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Import and merge" }).click();
  await page.getByRole("button", { name: "Merge data" }).click();
  await expect(
    page.getByRole("status").filter({ hasText: "Backup imported" }),
  ).toBeVisible();
  await page.goto("/garage");
  await expect(
    page.getByRole("heading", { name: "Hyundai Creta" }),
  ).toHaveCount(2);
});
test("shows corrupted storage recovery without replacing original", async ({
  page,
}) => {
  await page.addInitScript(
    (key) => localStorage.setItem(key, "{bad"),
    STORAGE_KEY,
  );
  await page.goto("/dashboard");
  await expect(page.getByRole("alert")).toContainText(
    "Original data is preserved",
  );
  await page.getByRole("link", { name: "Backup & recovery" }).click();
  await expect(
    page.getByRole("button", { name: "Download original unreadable data" }),
  ).toBeVisible();
  expect(
    await page.evaluate((key) => localStorage.getItem(key), STORAGE_KEY),
  ).toBe("{bad");
});
test("dark theme and Hindi preferences survive refresh", async ({ page }) => {
  await demo(page);
  await page.goto("/settings");
  await page.getByRole("button", { name: "Dark", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.getByLabel("Language", { exact: true }).selectOption("hi");
  await expect(page.getByRole("heading", { name: "सेटिंग्स" })).toBeVisible();
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("lang", "hi");
  await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
  await page.getByLabel("भाषा", { exact: true }).selectOption("en");
});
test("mobile navigation and forms have no horizontal overflow", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await demo(page);
  await expect(
    page.getByRole("navigation", { name: "Mobile navigation" }),
  ).toBeVisible();
  await page.getByRole("link", { name: "More", exact: true }).click();
  await page.locator("main").getByRole("link", { name: "Maintenance" }).click();
  await expect(
    page.getByRole("heading", { name: "Maintenance", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Add maintenance schedule" }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
});
test("app shell reloads offline and records can be saved offline", async ({
  page,
  context,
}) => {
  await demo(page);
  await page.evaluate(async () => {
    await navigator.serviceWorker.ready;
  });
  await expect
    .poll(() => page.evaluate(() => !!navigator.serviceWorker.controller))
    .toBe(true);
  await page.goto("/expenses");
  await context.setOffline(true);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Expenses", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Add expense", exact: true }).click();
  await page.getByLabel("Title *", { exact: true }).fill("Offline parking");
  await page.getByLabel("Cost (INR) *").fill("40");
  await page.getByRole("button", { name: "Save", exact: true }).click();
  await page.reload();
  await expect(
    page.getByText("Offline parking", { exact: true }),
  ).toBeVisible();
  await context.setOffline(false);
});
test("cross-tab edits refresh clean tabs without lost records", async ({
  page,
  context,
}) => {
  await demo(page);
  const other = await context.newPage();
  await other.goto("/garage");
  await page.goto("/garage/new");
  await page.getByLabel("Name *", { exact: true }).fill("Cross tab car");
  await page.getByLabel("Make *", { exact: true }).fill("Tata");
  await page.getByLabel("Model *", { exact: true }).fill("Nexon");
  await page.getByRole("button", { name: "Add vehicle", exact: true }).click();
  await expect(
    other.getByRole("heading", { name: "Cross tab car" }),
  ).toBeVisible();
});
test("every feature route renders and empty charts are honest", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Set up my garage" }).click();
  await page.getByRole("button", { name: "I’ll add a vehicle later" }).click();
  await page.goto("/reports");
  await expect(page.getByText("Your spending story starts here")).toBeVisible();
  await expect(page.getByText("Unavailable", { exact: true })).toBeVisible();
  for (const route of [
    "fuel",
    "charging",
    "services",
    "maintenance",
    "expenses",
    "renewals",
    "trips",
    "checklists",
    "emergency",
    "settings",
    "about",
  ]) {
    await page.goto(`/${route}`);
    await expect(page.locator("main h1")).toBeVisible();
  }
  await page.goto("/does-not-exist");
  await expect(page.getByText("That road doesn’t lead anywhere")).toBeVisible();
});
