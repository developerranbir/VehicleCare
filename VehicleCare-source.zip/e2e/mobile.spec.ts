import { test, expect, type Page } from "@playwright/test";
import { STORAGE_KEY, today } from "../src/lib/model";
import { routeCollection, configs } from "../src/features/records/config";
import { demoSnapshot } from "../src/lib/demo";
import { createBackup } from "../src/storage/backupService";
async function demo(page: Page) {
  await page.goto("/");
  await page.getByRole("button", { name: "Explore with demo data" }).click();
  await expect(page.locator("main h1")).toBeVisible();
}
async function fits(page: Page) {
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
}
for (const width of [320, 375, 390, 430, 768])
  test(`all populated mobile modules and forms fit ${width}px`, async ({
    page,
  }) => {
    const errors: string[] = [];
    page.on("pageerror", (e) => errors.push(e.message));
    await page.setViewportSize({ width, height: 844 });
    await demo(page);
    const vehicleId = await page.evaluate(
      (key) => JSON.parse(localStorage.getItem(key)!).vehicles[0].id,
      STORAGE_KEY,
    );
    for (const route of [
      "dashboard",
      "garage",
      `garage/${vehicleId}`,
      `garage/${vehicleId}/edit`,
      "garage/new",
      ...Object.keys(routeCollection),
      "emergency",
      "reports",
      "settings",
      "settings/backup",
      "reminders",
      "more",
      "about",
    ]) {
      await page.goto(`/${route}`);
      await expect(page.locator("main h1")).toBeVisible();
      await fits(page);
      await expect(page.locator(".sidebar")).toBeHidden();
      await expect(
        page.getByRole("navigation", { name: "Mobile navigation" }),
      ).toBeVisible();
      if (routeCollection[route]) {
        await page
          .locator("main .page-heading")
          .getByRole("button", { name: /^Add / })
          .click();
        await expect(page.getByRole("dialog")).toBeVisible();
        await fits(page);
        expect(
          await page
            .getByRole("dialog")
            .evaluate(
              (el) =>
                el.getBoundingClientRect().right <= innerWidth &&
                el.getBoundingClientRect().left >= 0,
            ),
        ).toBe(true);
        await page.keyboard.press("Escape");
      }
    }
    expect(errors).toEqual([]);
  });
test("bottom navigation, all add actions, odometer corrections and tablet/desktop switch", async ({
  page,
}) => {
  await page.setViewportSize({ width: 375, height: 812 });
  await demo(page);
  const nav = page.getByRole("navigation", { name: "Mobile navigation" });
  await nav.getByRole("link", { name: "Garage", exact: true }).click();
  await expect(page.locator("main h1")).toHaveText("My garage");
  await nav.getByRole("link", { name: "Reminders", exact: true }).click();
  await expect(page.locator("main h1")).toHaveText("Reminders");
  await nav.getByRole("link", { name: "More", exact: true }).click();
  await page
    .locator("main")
    .getByRole("link", { name: "Service history" })
    .click();
  await expect(page.locator("main h1")).toHaveText("Service history");
  await nav.getByRole("button", { name: "Add", exact: true }).click();
  for (const action of [
    "Add Fuel",
    "Add Charging Session",
    "Add Service",
    "Add Expense",
    "Add Trip",
    "Update Odometer",
  ])
    await expect(
      page
        .getByRole("dialog")
        .getByRole("button", { name: action, exact: true }),
    ).toBeEnabled();
  await expect(
    page.getByRole("dialog").getByRole("link", { name: "Add vehicle" }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Update Odometer", exact: true })
    .click();
  const current = Number(await page.locator("#quick-odometer").inputValue());
  await page.locator("#quick-odometer").fill(String(current - 1));
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Save", exact: true })
    .click();
  await expect(page.getByRole("dialog").getByRole("alert")).toContainText(
    "cannot be below a recorded reading",
  );
  await page.locator("#quick-odometer").fill(String(current + 100));
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Save", exact: true })
    .click();
  await expect(page.getByRole("dialog")).toHaveCount(0);
  await page.reload();
  expect(
    await page.evaluate(
      (key) => JSON.parse(localStorage.getItem(key)!).vehicles[0].odometer,
      STORAGE_KEY,
    ),
  ).toBe(current + 100);
  await page.setViewportSize({ width: 1024, height: 900 });
  await expect(nav).toBeHidden();
  await expect(page.locator(".sidebar")).toBeVisible();
});
test("an empty garage keeps vehicle creation available and tracking actions disabled", async ({
  page,
}) => {
  await page.setViewportSize({ width: 320, height: 700 });
  await page.goto("/");
  await page.getByRole("button", { name: "Set up my garage" }).click();
  await page.getByRole("button", { name: "I’ll add a vehicle later" }).click();
  await page
    .getByRole("navigation", { name: "Mobile navigation" })
    .getByRole("button", { name: "Add", exact: true })
    .click();
  await expect(
    page.getByRole("dialog").getByRole("link", { name: "Add vehicle" }),
  ).toBeVisible();
  for (const action of [
    "Add Fuel",
    "Add Charging Session",
    "Add Service",
    "Add Expense",
    "Add Trip",
    "Update Odometer",
  ])
    await expect(
      page
        .getByRole("dialog")
        .getByRole("button", { name: action, exact: true }),
    ).toBeDisabled();
  await fits(page);
});
for (const route of [
  "fuel",
  "charging",
  "services",
  "maintenance",
  "renewals",
  "trips",
  "checklists",
])
  test(`touch-sized ${route} form validates, saves, edits, reloads and deletes`, async ({
    page,
  }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await demo(page);
    const kind = routeCollection[route],
      title = `Mobile ${route} test`;
    const odo = await page.evaluate(
      (key) => JSON.parse(localStorage.getItem(key)!).vehicles[0].odometer,
      STORAGE_KEY,
    );
    await page.goto(`/${route}`);
    await page
      .getByRole("button", {
        name: `Add ${configs[kind].singular.toLowerCase()}`,
        exact: true,
      })
      .click();
    await page
      .getByRole("dialog")
      .getByRole("button", { name: "Save", exact: true })
      .click();
    await expect(
      page.getByRole("dialog").getByRole("alert").first(),
    ).toBeVisible();
    await page.locator("#entry-title").fill(title);
    if (route === "fuel") {
      await page.locator("#entry-odometer").fill(String(odo));
      await page.locator("#entry-litres").fill("10");
      await page.locator("#entry-cost").fill("1000");
    }
    if (route === "charging") {
      await page.locator("#entry-kwh").fill("12");
      await page.locator("#entry-cost").fill("120");
    }
    if (route === "services") {
      await page.locator("#entry-odometer").fill(String(odo));
      await page.locator("#entry-tasks").fill("Inspection");
      await page.locator("#entry-partsCost").fill("100");
    }
    if (route === "maintenance") {
      await page.locator("#entry-intervalDays").fill("30");
      await page.locator("#entry-baselineDate").fill(today());
    }
    if (route === "renewals")
      await page.locator("#entry-dueDate").fill("2027-01-01");
    if (route === "trips") {
      await page.locator("#entry-startOdometer").fill(String(odo));
      await page.locator("#entry-endOdometer").fill(String(odo + 5));
    }
    await page
      .getByRole("dialog")
      .getByRole("button", { name: "Save", exact: true })
      .click();
    await expect(page.getByRole("dialog")).toHaveCount(0);
    await expect(page.getByText(title, { exact: true })).toBeVisible();
    await page
      .getByRole("button", { name: `Edit ${title}`, exact: true })
      .click();
    await page.locator("#entry-notes").fill("Edited on a small screen");
    await page
      .getByRole("dialog")
      .getByRole("button", { name: "Save", exact: true })
      .click();
    await page.reload();
    expect(
      await page.evaluate(
        ({ key, kind, title }) =>
          JSON.parse(localStorage.getItem(key)!)[kind].find(
            (e: { title: string }) => e.title === title,
          ).notes,
        { key: STORAGE_KEY, kind, title },
      ),
    ).toBe("Edited on a small screen");
    await page
      .getByRole("button", { name: `Delete ${title}`, exact: true })
      .click();
    await page
      .getByRole("button", { name: "Delete record", exact: true })
      .click();
    await expect(page.getByText(title, { exact: true })).toHaveCount(0);
    await fits(page);
  });
test("shared native backup format restores on web with preview, replace confirmation and persistence", async ({
  page,
}) => {
  await page.setViewportSize({ width: 320, height: 700 });
  await demo(page);
  await page.goto("/settings/backup");
  const incoming = demoSnapshot();
  incoming.vehicles[0].name = "Transferred from native format";
  await page.locator("#backup-file").setInputFiles({
    name: "vehiclecare-transfer.json",
    mimeType: "application/json",
    buffer: Buffer.from(createBackup(incoming)),
  });
  await expect(
    page.getByRole("heading", { name: "Import preview" }),
  ).toBeVisible();
  await page.getByText("Replace all local data", { exact: true }).click();
  await page.getByRole("button", { name: "Import and replace" }).click();
  await page.getByRole("button", { name: "Cancel", exact: true }).click();
  expect(
    await page.evaluate(
      (key) => JSON.parse(localStorage.getItem(key)!).vehicles[0].name,
      STORAGE_KEY,
    ),
  ).toBe("Hyundai Creta");
  await page.getByRole("button", { name: "Import and replace" }).click();
  await page.getByRole("button", { name: "Replace data", exact: true }).click();
  await page.reload();
  expect(
    await page.evaluate(
      (key) => JSON.parse(localStorage.getItem(key)!).vehicles[0].name,
      STORAGE_KEY,
    ),
  ).toBe("Transferred from native format");
  await fits(page);
});
